#SKD101|peru|132|2012.03.12 15:55:38|1461|1|5|2|2|1|1|3|437|29|11|239|1|1|2|1|2|4|1|1|1|1|6|197|27|3|3|3|2|2|2|3|81|2|384

DROP table IF EXISTS `address_book`;
CREATE TABLE `address_book` (
  `address_book_id` int(11) NOT NULL AUTO_INCREMENT,
  `customers_id` int(11) NOT NULL,
  `entry_gender` char(1) NOT NULL,
  `entry_company` varchar(255) DEFAULT NULL,
  `entry_firstname` varchar(255) NOT NULL,
  `entry_secondname` varchar(255) NOT NULL,
  `entry_lastname` varchar(255) NOT NULL,
  `entry_street_address` varchar(255) NOT NULL,
  `entry_suburb` varchar(255) DEFAULT NULL,
  `entry_postcode` varchar(10) NOT NULL,
  `entry_city` varchar(255) NOT NULL,
  `entry_state` varchar(255) DEFAULT NULL,
  `entry_country_id` int(11) NOT NULL DEFAULT '0',
  `entry_zone_id` int(11) NOT NULL DEFAULT '0',
  `address_date_added` datetime DEFAULT '0000-00-00 00:00:00',
  `address_last_modified` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`address_book_id`),
  KEY `idx_address_book_customers_id` (`customers_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `address_book` VALUES
(1, 1, '', 'COMPANY', 'Admin', '', 'aDMIN', 'STREET_ADRESS', NULL, 'POST_CODE', 'CITY', 'Воронежская область', 176, 0, '2012-03-10 22:56:36', '2012-03-10 22:56:36');

DROP table IF EXISTS `address_format`;
CREATE TABLE `address_format` (
  `address_format_id` int(11) NOT NULL AUTO_INCREMENT,
  `address_format` varchar(255) NOT NULL,
  `address_summary` varchar(255) NOT NULL,
  PRIMARY KEY (`address_format_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `address_format` VALUES
(1, '$firstname $secondname $lastname$cr$streets$cr$city, $postcode$cr$statecomma$country', '$city / $country'),
(2, '$firstname $secondname $lastname$cr$streets$cr$city, $state    $postcode$cr$country', '$city, $state / $country'),
(3, '$firstname $secondname $lastname$cr$streets$cr$city$cr$postcode - $statecomma$country', '$state / $country'),
(4, '$firstname $secondname $lastname$cr$streets$cr$city ($postcode)$cr$country', '$postcode / $country'),
(5, '$firstname $secondname $lastname$cr$streets$cr$postcode $city$cr$country', '$city / $country');

DROP table IF EXISTS `admin_access`;
CREATE TABLE `admin_access` (
  `customers_id` varchar(255) NOT NULL DEFAULT '0',
  `configuration` int(1) NOT NULL DEFAULT '0',
  `modules` int(1) NOT NULL DEFAULT '0',
  `countries` int(1) NOT NULL DEFAULT '0',
  `currencies` int(1) NOT NULL DEFAULT '0',
  `zones` int(1) NOT NULL DEFAULT '0',
  `geo_zones` int(1) NOT NULL DEFAULT '0',
  `tax_classes` int(1) NOT NULL DEFAULT '0',
  `tax_rates` int(1) NOT NULL DEFAULT '0',
  `accounting` int(1) NOT NULL DEFAULT '0',
  `backup` int(1) NOT NULL DEFAULT '0',
  `cache` int(1) NOT NULL DEFAULT '0',
  `server_info` int(1) NOT NULL DEFAULT '0',
  `whos_online` int(1) NOT NULL DEFAULT '0',
  `languages` int(1) NOT NULL DEFAULT '0',
  `define_language` int(1) NOT NULL DEFAULT '0',
  `orders_status` int(1) NOT NULL DEFAULT '0',
  `shipping_status` int(1) NOT NULL DEFAULT '0',
  `module_export` int(1) NOT NULL DEFAULT '0',
  `customers` int(1) NOT NULL DEFAULT '0',
  `create_account` int(1) NOT NULL DEFAULT '0',
  `customers_status` int(1) NOT NULL DEFAULT '0',
  `orders` int(1) NOT NULL DEFAULT '0',
  `campaigns` int(1) NOT NULL DEFAULT '0',
  `print_packingslip` int(1) NOT NULL DEFAULT '0',
  `print_order` int(1) NOT NULL DEFAULT '0',
  `popup_memo` int(1) NOT NULL DEFAULT '0',
  `coupon_admin` int(1) NOT NULL DEFAULT '0',
  `listcategories` int(1) NOT NULL DEFAULT '0',
  `gv_queue` int(1) NOT NULL DEFAULT '0',
  `gv_mail` int(1) NOT NULL DEFAULT '0',
  `gv_sent` int(1) NOT NULL DEFAULT '0',
  `validproducts` int(1) NOT NULL DEFAULT '0',
  `validcategories` int(1) NOT NULL DEFAULT '0',
  `mail` int(1) NOT NULL DEFAULT '0',
  `categories` int(1) NOT NULL DEFAULT '0',
  `new_attributes` int(1) NOT NULL DEFAULT '0',
  `products_attributes` int(1) NOT NULL DEFAULT '0',
  `manufacturers` int(1) NOT NULL DEFAULT '0',
  `reviews` int(1) NOT NULL DEFAULT '0',
  `specials` int(1) NOT NULL DEFAULT '0',
  `stats_products_expected` int(1) NOT NULL DEFAULT '0',
  `stats_products_viewed` int(1) NOT NULL DEFAULT '0',
  `stats_products_purchased` int(1) NOT NULL DEFAULT '0',
  `stats_customers` int(1) NOT NULL DEFAULT '0',
  `stats_sales_report` int(1) NOT NULL DEFAULT '0',
  `stats_campaigns` int(1) NOT NULL DEFAULT '0',
  `banner_manager` int(1) NOT NULL DEFAULT '0',
  `banner_statistics` int(1) NOT NULL DEFAULT '0',
  `module_newsletter` int(1) NOT NULL DEFAULT '0',
  `start` int(1) NOT NULL DEFAULT '0',
  `content_manager` int(1) NOT NULL DEFAULT '0',
  `content_preview` int(1) NOT NULL DEFAULT '0',
  `credits` int(1) NOT NULL DEFAULT '0',
  `blacklist` int(1) NOT NULL DEFAULT '0',
  `orders_edit` int(1) NOT NULL DEFAULT '0',
  `popup_image` int(1) NOT NULL DEFAULT '0',
  `csv_backend` int(1) NOT NULL DEFAULT '0',
  `products_vpe` int(1) NOT NULL DEFAULT '0',
  `cross_sell_groups` int(1) NOT NULL DEFAULT '0',
  `fck_wrapper` int(1) NOT NULL DEFAULT '0',
  `easypopulate` int(1) NOT NULL DEFAULT '0',
  `quick_updates` int(1) NOT NULL DEFAULT '0',
  `latest_news` int(1) NOT NULL DEFAULT '0',
  `recover_cart_sales` int(1) NOT NULL DEFAULT '0',
  `featured` int(1) NOT NULL DEFAULT '0',
  `cip_manager` int(1) NOT NULL DEFAULT '0',
  `authors` int(1) NOT NULL DEFAULT '0',
  `articles` int(1) NOT NULL DEFAULT '0',
  `articles_config` int(1) NOT NULL DEFAULT '0',
  `stats_sales_report2` int(1) NOT NULL DEFAULT '0',
  `chart_data` int(1) NOT NULL DEFAULT '0',
  `articles_xsell` int(1) NOT NULL DEFAULT '0',
  `email_manager` int(1) NOT NULL DEFAULT '0',
  `category_specials` int(1) NOT NULL DEFAULT '0',
  `products_options` int(1) NOT NULL DEFAULT '0',
  `product_extra_fields` int(1) NOT NULL DEFAULT '0',
  `ship2pay` int(1) NOT NULL DEFAULT '0',
  `faq` int(1) NOT NULL DEFAULT '0',
  `affiliate_affiliates` int(1) NOT NULL DEFAULT '0',
  `affiliate_banners` int(1) NOT NULL DEFAULT '0',
  `affiliate_clicks` int(1) NOT NULL DEFAULT '0',
  `affiliate_contact` int(1) NOT NULL DEFAULT '0',
  `affiliate_invoice` int(1) NOT NULL DEFAULT '0',
  `affiliate_payment` int(1) NOT NULL DEFAULT '0',
  `affiliate_popup_image` int(1) NOT NULL DEFAULT '0',
  `affiliate_sales` int(1) NOT NULL DEFAULT '0',
  `affiliate_statistics` int(1) NOT NULL DEFAULT '0',
  `affiliate_summary` int(1) NOT NULL DEFAULT '0',
  `customer_extra_fields` int(1) NOT NULL DEFAULT '0',
  `parameters` int(1) NOT NULL DEFAULT '0',
  `parameters_export` int(1) NOT NULL DEFAULT '0',
  `select_featured` int(1) NOT NULL DEFAULT '0',
  `select_special` int(1) NOT NULL DEFAULT '0',
  `yml_import` int(1) NOT NULL DEFAULT '0',
  `customer_export` int(1) NOT NULL DEFAULT '0',
  `exportorders` int(1) NOT NULL DEFAULT '0',
  `pin_loader` int(1) NOT NULL DEFAULT '0',
  `edit_orders` int(1) DEFAULT NULL,
  `edit_orders_add_product` int(1) DEFAULT NULL,
  `edit_orders_ajax` int(1) DEFAULT NULL,
  `products_specifications` int(1) DEFAULT NULL,
  PRIMARY KEY (`customers_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `admin_access` VALUES
('1', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1),
('groups', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 2, 4, 2, 2, 2, 2, 5, 5, 5, 5, 5, 5, 5, 5, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, NULL, NULL, NULL, NULL);

DROP table IF EXISTS `affiliate_affiliate`;
CREATE TABLE `affiliate_affiliate` (
  `affiliate_id` int(11) NOT NULL AUTO_INCREMENT,
  `affiliate_lft` int(11) NOT NULL,
  `affiliate_rgt` int(11) NOT NULL,
  `affiliate_root` int(11) NOT NULL,
  `affiliate_gender` char(1) NOT NULL DEFAULT '',
  `affiliate_firstname` varchar(32) NOT NULL DEFAULT '',
  `affiliate_lastname` varchar(32) NOT NULL DEFAULT '',
  `affiliate_dob` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `affiliate_email_address` varchar(96) NOT NULL DEFAULT '',
  `affiliate_telephone` varchar(32) NOT NULL DEFAULT '',
  `affiliate_fax` varchar(32) NOT NULL DEFAULT '',
  `affiliate_password` varchar(40) NOT NULL DEFAULT '',
  `affiliate_homepage` varchar(96) NOT NULL DEFAULT '',
  `affiliate_street_address` varchar(64) NOT NULL DEFAULT '',
  `affiliate_suburb` varchar(64) NOT NULL DEFAULT '',
  `affiliate_city` varchar(32) NOT NULL DEFAULT '',
  `affiliate_postcode` varchar(10) NOT NULL DEFAULT '',
  `affiliate_state` varchar(32) NOT NULL DEFAULT '',
  `affiliate_country_id` int(11) NOT NULL DEFAULT '0',
  `affiliate_zone_id` int(11) NOT NULL DEFAULT '0',
  `affiliate_agb` tinyint(4) NOT NULL DEFAULT '0',
  `affiliate_company` varchar(60) NOT NULL DEFAULT '',
  `affiliate_company_taxid` varchar(64) NOT NULL DEFAULT '',
  `affiliate_commission_percent` decimal(4,2) NOT NULL DEFAULT '0.00',
  `affiliate_payment_check` varchar(100) NOT NULL DEFAULT '',
  `affiliate_payment_paypal` varchar(64) NOT NULL DEFAULT '',
  `affiliate_payment_bank_name` varchar(64) NOT NULL DEFAULT '',
  `affiliate_payment_bank_branch_number` varchar(64) NOT NULL DEFAULT '',
  `affiliate_payment_bank_swift_code` varchar(64) NOT NULL DEFAULT '',
  `affiliate_payment_bank_account_name` varchar(64) NOT NULL DEFAULT '',
  `affiliate_payment_bank_account_number` varchar(64) NOT NULL DEFAULT '',
  `affiliate_date_of_last_logon` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `affiliate_number_of_logons` int(11) NOT NULL DEFAULT '0',
  `affiliate_date_account_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `affiliate_date_account_last_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`affiliate_id`),
  KEY `affiliate_root` (`affiliate_root`),
  KEY `affiliate_rgt` (`affiliate_rgt`),
  KEY `affiliate_lft` (`affiliate_lft`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `affiliate_banners`;
CREATE TABLE `affiliate_banners` (
  `affiliate_banners_id` int(11) NOT NULL AUTO_INCREMENT,
  `affiliate_banners_title` varchar(64) NOT NULL DEFAULT '',
  `affiliate_products_id` int(11) NOT NULL DEFAULT '0',
  `affiliate_banners_image` varchar(64) NOT NULL DEFAULT '',
  `affiliate_banners_group` varchar(10) NOT NULL DEFAULT '',
  `affiliate_banners_html_text` text,
  `affiliate_expires_impressions` int(7) DEFAULT '0',
  `affiliate_expires_date` datetime DEFAULT NULL,
  `affiliate_date_scheduled` datetime DEFAULT NULL,
  `affiliate_date_added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `affiliate_date_status_change` datetime DEFAULT NULL,
  `affiliate_status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`affiliate_banners_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `affiliate_banners_history`;
CREATE TABLE `affiliate_banners_history` (
  `affiliate_banners_history_id` int(11) NOT NULL AUTO_INCREMENT,
  `affiliate_banners_products_id` int(11) NOT NULL DEFAULT '0',
  `affiliate_banners_id` int(11) NOT NULL DEFAULT '0',
  `affiliate_banners_affiliate_id` int(11) NOT NULL DEFAULT '0',
  `affiliate_banners_shown` int(11) NOT NULL DEFAULT '0',
  `affiliate_banners_clicks` tinyint(4) NOT NULL DEFAULT '0',
  `affiliate_banners_history_date` date NOT NULL DEFAULT '0000-00-00',
  PRIMARY KEY (`affiliate_banners_history_id`,`affiliate_banners_products_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `affiliate_clickthroughs`;
CREATE TABLE `affiliate_clickthroughs` (
  `affiliate_clickthrough_id` int(11) NOT NULL AUTO_INCREMENT,
  `affiliate_id` int(11) NOT NULL DEFAULT '0',
  `affiliate_clientdate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `affiliate_clientbrowser` varchar(200) DEFAULT 'Нет данных',
  `affiliate_clientip` varchar(50) DEFAULT 'Нет данных',
  `affiliate_clientreferer` varchar(200) DEFAULT 'не определено (возможно прямая ссылка)',
  `affiliate_products_id` int(11) DEFAULT '0',
  `affiliate_banner_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`affiliate_clickthrough_id`),
  KEY `refid` (`affiliate_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `affiliate_payment`;
CREATE TABLE `affiliate_payment` (
  `affiliate_payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `affiliate_id` int(11) NOT NULL DEFAULT '0',
  `affiliate_payment` decimal(15,2) NOT NULL DEFAULT '0.00',
  `affiliate_payment_tax` decimal(15,2) NOT NULL DEFAULT '0.00',
  `affiliate_payment_total` decimal(15,2) NOT NULL DEFAULT '0.00',
  `affiliate_payment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `affiliate_payment_last_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `affiliate_payment_status` int(5) NOT NULL DEFAULT '0',
  `affiliate_firstname` varchar(32) NOT NULL DEFAULT '',
  `affiliate_lastname` varchar(32) NOT NULL DEFAULT '',
  `affiliate_street_address` varchar(64) NOT NULL DEFAULT '',
  `affiliate_suburb` varchar(64) NOT NULL DEFAULT '',
  `affiliate_city` varchar(32) NOT NULL DEFAULT '',
  `affiliate_postcode` varchar(10) NOT NULL DEFAULT '',
  `affiliate_country` varchar(32) NOT NULL DEFAULT '0',
  `affiliate_company` varchar(60) NOT NULL DEFAULT '',
  `affiliate_state` varchar(32) NOT NULL DEFAULT '0',
  `affiliate_address_format_id` int(5) NOT NULL DEFAULT '0',
  `affiliate_last_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`affiliate_payment_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `affiliate_payment_status`;
CREATE TABLE `affiliate_payment_status` (
  `affiliate_payment_status_id` int(11) NOT NULL DEFAULT '0',
  `affiliate_language_id` int(11) NOT NULL DEFAULT '1',
  `affiliate_payment_status_name` varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`affiliate_payment_status_id`,`affiliate_language_id`),
  KEY `idx_affiliate_payment_status_name` (`affiliate_payment_status_name`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `affiliate_payment_status` VALUES
(0, 1, 'Ожидает оплаты'),
(1, 1, 'Оплачен');

DROP table IF EXISTS `affiliate_payment_status_history`;
CREATE TABLE `affiliate_payment_status_history` (
  `affiliate_status_history_id` int(11) NOT NULL AUTO_INCREMENT,
  `affiliate_payment_id` int(11) NOT NULL DEFAULT '0',
  `affiliate_new_value` int(5) NOT NULL DEFAULT '0',
  `affiliate_old_value` int(5) DEFAULT NULL,
  `affiliate_date_added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `affiliate_notified` int(1) DEFAULT '0',
  PRIMARY KEY (`affiliate_status_history_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `affiliate_sales`;
CREATE TABLE `affiliate_sales` (
  `affiliate_id` int(11) NOT NULL DEFAULT '0',
  `affiliate_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `affiliate_browser` varchar(100) NOT NULL DEFAULT '',
  `affiliate_ipaddress` varchar(20) NOT NULL DEFAULT '',
  `affiliate_orders_id` int(11) NOT NULL DEFAULT '0',
  `affiliate_value` decimal(15,2) NOT NULL DEFAULT '0.00',
  `affiliate_payment` decimal(15,2) NOT NULL DEFAULT '0.00',
  `affiliate_clickthroughs_id` int(11) NOT NULL DEFAULT '0',
  `affiliate_billing_status` int(5) NOT NULL DEFAULT '0',
  `affiliate_payment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `affiliate_payment_id` int(11) NOT NULL DEFAULT '0',
  `affiliate_percent` decimal(4,2) NOT NULL DEFAULT '0.00',
  `affiliate_salesman` int(11) NOT NULL DEFAULT '0',
  `affiliate_level` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`affiliate_id`,`affiliate_orders_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `articles`;
CREATE TABLE `articles` (
  `articles_id` int(11) NOT NULL AUTO_INCREMENT,
  `articles_date_added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `articles_last_modified` datetime DEFAULT NULL,
  `articles_date_available` datetime DEFAULT NULL,
  `articles_status` tinyint(1) NOT NULL DEFAULT '0',
  `authors_id` int(11) DEFAULT NULL,
  `articles_page_url` varchar(255) DEFAULT NULL,
  `sort_order` int(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`articles_id`),
  KEY `idx_articles_date_added` (`articles_date_added`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `articles_description`;
CREATE TABLE `articles_description` (
  `articles_id` int(11) NOT NULL AUTO_INCREMENT,
  `language_id` int(11) NOT NULL DEFAULT '1',
  `articles_name` varchar(255) NOT NULL DEFAULT '',
  `articles_description` text,
  `articles_url` varchar(255) DEFAULT NULL,
  `articles_viewed` int(5) DEFAULT '0',
  `articles_head_title_tag` varchar(80) DEFAULT NULL,
  `articles_head_desc_tag` text,
  `articles_head_keywords_tag` text,
  PRIMARY KEY (`articles_id`,`language_id`),
  KEY `articles_name` (`articles_name`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `articles_to_topics`;
CREATE TABLE `articles_to_topics` (
  `articles_id` int(11) NOT NULL DEFAULT '0',
  `topics_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`articles_id`,`topics_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `articles_xsell`;
CREATE TABLE `articles_xsell` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `articles_id` int(10) unsigned NOT NULL DEFAULT '1',
  `xsell_id` int(10) unsigned NOT NULL DEFAULT '1',
  `sort_order` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `authors`;
CREATE TABLE `authors` (
  `authors_id` int(11) NOT NULL AUTO_INCREMENT,
  `authors_name` varchar(255) NOT NULL DEFAULT '',
  `authors_image` varchar(64) DEFAULT NULL,
  `date_added` datetime DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`authors_id`),
  KEY `IDX_AUTHORS_NAME` (`authors_name`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `authors_info`;
CREATE TABLE `authors_info` (
  `authors_id` int(11) NOT NULL DEFAULT '0',
  `languages_id` int(11) NOT NULL DEFAULT '0',
  `authors_description` text,
  `authors_url` varchar(255) NOT NULL DEFAULT '',
  `url_clicked` int(5) NOT NULL DEFAULT '0',
  `date_last_click` datetime DEFAULT NULL,
  PRIMARY KEY (`authors_id`,`languages_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `banktransfer`;
CREATE TABLE `banktransfer` (
  `orders_id` int(11) NOT NULL DEFAULT '0',
  `banktransfer_owner` varchar(255) DEFAULT NULL,
  `banktransfer_number` varchar(24) DEFAULT NULL,
  `banktransfer_bankname` varchar(255) DEFAULT NULL,
  `banktransfer_blz` varchar(8) DEFAULT NULL,
  `banktransfer_status` int(11) DEFAULT NULL,
  `banktransfer_prz` char(2) DEFAULT NULL,
  `banktransfer_fax` char(2) DEFAULT NULL,
  KEY `orders_id` (`orders_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `banners`;
CREATE TABLE `banners` (
  `banners_id` int(11) NOT NULL AUTO_INCREMENT,
  `banners_title` varchar(255) NOT NULL,
  `banners_url` varchar(255) NOT NULL,
  `banners_image` varchar(255) NOT NULL,
  `banners_group` varchar(10) NOT NULL,
  `banners_html_text` text,
  `expires_impressions` int(7) DEFAULT '0',
  `expires_date` datetime DEFAULT NULL,
  `date_scheduled` datetime DEFAULT NULL,
  `date_added` datetime NOT NULL,
  `date_status_change` datetime DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`banners_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `banners_history`;
CREATE TABLE `banners_history` (
  `banners_history_id` int(11) NOT NULL AUTO_INCREMENT,
  `banners_id` int(11) NOT NULL,
  `banners_shown` int(5) NOT NULL DEFAULT '0',
  `banners_clicked` int(5) NOT NULL DEFAULT '0',
  `banners_history_date` datetime NOT NULL,
  PRIMARY KEY (`banners_history_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `campaigns`;
CREATE TABLE `campaigns` (
  `campaigns_id` int(11) NOT NULL AUTO_INCREMENT,
  `campaigns_name` varchar(255) NOT NULL DEFAULT '',
  `campaigns_refID` varchar(255) DEFAULT NULL,
  `campaigns_leads` int(11) NOT NULL DEFAULT '0',
  `date_added` datetime DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`campaigns_id`),
  KEY `IDX_CAMPAIGNS_NAME` (`campaigns_name`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `campaigns_ip`;
CREATE TABLE `campaigns_ip` (
  `user_ip` varchar(15) NOT NULL,
  `time` datetime NOT NULL,
  `campaign` varchar(32) NOT NULL
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `card_blacklist`;
CREATE TABLE `card_blacklist` (
  `blacklist_id` int(5) NOT NULL AUTO_INCREMENT,
  `blacklist_card_number` varchar(20) NOT NULL DEFAULT '',
  `date_added` datetime DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  KEY `blacklist_id` (`blacklist_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `categories`;
CREATE TABLE `categories` (
  `categories_id` int(11) NOT NULL AUTO_INCREMENT,
  `categories_image` varchar(255) DEFAULT NULL,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `categories_status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `categories_template` varchar(255) DEFAULT NULL,
  `group_permission_0` tinyint(1) NOT NULL,
  `group_permission_1` tinyint(1) NOT NULL,
  `group_permission_2` tinyint(1) NOT NULL,
  `group_permission_3` tinyint(1) NOT NULL,
  `listing_template` varchar(255) DEFAULT NULL,
  `sort_order` int(3) NOT NULL DEFAULT '0',
  `products_sorting` varchar(255) DEFAULT NULL,
  `products_sorting2` varchar(255) DEFAULT NULL,
  `date_added` datetime DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  `yml_bid` varchar(4) NOT NULL DEFAULT '0',
  `yml_cbid` varchar(4) NOT NULL DEFAULT '0',
  `categories_url` varchar(255) DEFAULT NULL,
  `yml_enable` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`categories_id`),
  KEY `idx_categories_parent_id` (`parent_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `categories` VALUES
(1, NULL, 0, 1, 'default', 0, 0, 0, 0, 'default', 0, 'p.products_price', 'ASC', '2012-03-12 09:33:25', NULL, '', '', '', 1);

DROP table IF EXISTS `categories_description`;
CREATE TABLE `categories_description` (
  `categories_id` int(11) NOT NULL DEFAULT '0',
  `language_id` int(11) NOT NULL DEFAULT '1',
  `categories_name` varchar(255) NOT NULL,
  `categories_heading_title` varchar(255) NOT NULL,
  `categories_description` text,
  `categories_meta_title` varchar(255) NOT NULL,
  `categories_meta_description` varchar(255) NOT NULL,
  `categories_meta_keywords` varchar(255) NOT NULL,
  PRIMARY KEY (`categories_id`,`language_id`),
  KEY `idx_categories_name` (`categories_name`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `categories_description` VALUES
(1, 1, 'ggfe', 'gffd', 'g rts fg dfh', '', '', '');

DROP table IF EXISTS `cip`;
CREATE TABLE `cip` (
  `cip_id` int(11) NOT NULL AUTO_INCREMENT,
  `cip_folder_name` varchar(255) NOT NULL,
  `cip_downloads` int(11) NOT NULL DEFAULT '0',
  `cip_uploader_id` int(11) NOT NULL DEFAULT '0',
  `cip_installed` int(1) NOT NULL DEFAULT '0',
  `cip_ident` varchar(255) NOT NULL,
  `cip_version` varchar(255) NOT NULL,
  PRIMARY KEY (`cip_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `cip_depend`;
CREATE TABLE `cip_depend` (
  `cip_ident` varchar(255) NOT NULL,
  `cip_ident_req` varchar(255) NOT NULL,
  `cip_req_type` int(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cip_ident`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `cm_file_flags`;
CREATE TABLE `cm_file_flags` (
  `file_flag` int(11) NOT NULL,
  `file_flag_name` varchar(255) NOT NULL,
  PRIMARY KEY (`file_flag`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `cm_file_flags` VALUES
(0, 'information'),
(1, 'content'),
(2, 'affiliate');

DROP table IF EXISTS `companies`;
CREATE TABLE `companies` (
  `orders_id` int(11) NOT NULL DEFAULT '0',
  `customers_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `inn` varchar(255) DEFAULT NULL,
  `kpp` varchar(255) DEFAULT NULL,
  `ogrn` varchar(255) DEFAULT NULL,
  `okpo` varchar(255) DEFAULT NULL,
  `rs` varchar(255) DEFAULT NULL,
  `bank_name` varchar(255) DEFAULT NULL,
  `bik` varchar(255) DEFAULT NULL,
  `ks` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `yur_address` varchar(255) DEFAULT NULL,
  `fakt_address` varchar(255) DEFAULT NULL,
  `telephone` varchar(255) DEFAULT NULL,
  `fax` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `director` varchar(255) DEFAULT NULL,
  `accountant` varchar(255) DEFAULT NULL,
  KEY `orders_id` (`orders_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `configuration`;
CREATE TABLE `configuration` (
  `configuration_id` int(11) NOT NULL AUTO_INCREMENT,
  `configuration_key` varchar(255) NOT NULL DEFAULT '',
  `configuration_value` text,
  `configuration_group_id` int(11) NOT NULL DEFAULT '0',
  `sort_order` int(5) DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  `date_added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `use_function` varchar(255) DEFAULT NULL,
  `set_function` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`configuration_id`),
  KEY `idx_configuration_group_id` (`configuration_group_id`)
) ENGINE=MyISAM AUTO_INCREMENT=438 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `configuration` VALUES
(1, 'STORE_NAME', 'STORE_NAME', 1, 1, NULL, '0000-00-00 00:00:00', NULL, NULL),
(2, 'STORE_OWNER', 'COMPANY', 1, 2, NULL, '0000-00-00 00:00:00', NULL, NULL),
(3, 'STORE_OWNER_EMAIL_ADDRESS', 'example@example.com', 1, 3, NULL, '0000-00-00 00:00:00', NULL, NULL),
(4, 'STORE_TELEPHONE', '', 1, 3, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_textarea('),
(5, 'STORE_ICQ', '', 1, 3, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_textarea('),
(6, 'STORE_SKYPE', '', 1, 3, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_textarea('),
(7, 'EMAIL_FROM', 'example@example.com', 1, 4, NULL, '0000-00-00 00:00:00', NULL, NULL),
(8, 'STORE_COUNTRY', '176', 1, 6, NULL, '0000-00-00 00:00:00', 'vam_get_country_name', 'vam_cfg_pull_down_country_list('),
(9, 'STORE_ZONE', '98', 1, 7, NULL, '0000-00-00 00:00:00', 'vam_cfg_get_zone_name', 'vam_cfg_pull_down_zone_list('),
(10, 'EXPECTED_PRODUCTS_SORT', 'desc', 1, 8, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'asc\', \'desc\'),'),
(11, 'EXPECTED_PRODUCTS_FIELD', 'date_expected', 1, 9, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'products_name\', \'date_expected\'),'),
(12, 'USE_DEFAULT_LANGUAGE_CURRENCY', 'false', 1, 10, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(13, 'SEARCH_ENGINE_FRIENDLY_URLS', 'false', 16, 12, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(14, 'DISPLAY_CART', 'true', 1, 13, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(15, 'ADVANCED_SEARCH_DEFAULT_OPERATOR', 'and', 1, 15, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'and\', \'or\'),'),
(16, 'STORE_NAME_ADDRESS', 'Store Name\r\nAddress\r\nCountry\r\nPhone', 1, 16, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_textarea('),
(17, 'SHOW_COUNTS', 'false', 1, 17, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(18, 'DEFAULT_CUSTOMERS_STATUS_ID_ADMIN', '0', 1, 20, NULL, '0000-00-00 00:00:00', 'vam_get_customers_status_name', 'vam_cfg_pull_down_customers_status_list('),
(19, 'DEFAULT_CUSTOMERS_STATUS_ID_GUEST', '1', 1, 21, NULL, '0000-00-00 00:00:00', 'vam_get_customers_status_name', 'vam_cfg_pull_down_customers_status_list('),
(20, 'DEFAULT_CUSTOMERS_STATUS_ID', '2', 1, 23, NULL, '0000-00-00 00:00:00', 'vam_get_customers_status_name', 'vam_cfg_pull_down_customers_status_list('),
(21, 'ALLOW_ADD_TO_CART', 'false', 1, 24, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(22, 'CURRENT_TEMPLATE', 'vamshopq', 1, 26, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_pull_down_template_sets('),
(23, 'PRICE_IS_BRUTTO', 'false', 1, 27, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(24, 'PRICE_PRECISION', '4', 1, 28, NULL, '0000-00-00 00:00:00', NULL, ''),
(25, 'CC_KEYCHAIN', 'changeme', 1, 29, NULL, '0000-00-00 00:00:00', NULL, ''),
(26, 'ADMIN_DROP_DOWN_NAVIGATION', 'true', 1, 30, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(27, 'AJAX_CART', 'false', 1, 31, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(28, 'ENABLE_TABS', 'true', 1, 32, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(29, 'MASTER_PASS', '', 1, 33, NULL, '0000-00-00 00:00:00', NULL, ''),
(30, 'ENTRY_FIRST_NAME_MIN_LENGTH', '2', 2, 1, NULL, '0000-00-00 00:00:00', NULL, NULL),
(31, 'ENTRY_LAST_NAME_MIN_LENGTH', '2', 2, 2, NULL, '0000-00-00 00:00:00', NULL, NULL),
(32, 'ENTRY_DOB_MIN_LENGTH', '10', 2, 3, NULL, '0000-00-00 00:00:00', NULL, NULL),
(33, 'ENTRY_EMAIL_ADDRESS_MIN_LENGTH', '6', 2, 4, NULL, '0000-00-00 00:00:00', NULL, NULL),
(34, 'ENTRY_STREET_ADDRESS_MIN_LENGTH', '5', 2, 5, NULL, '0000-00-00 00:00:00', NULL, NULL),
(35, 'ENTRY_COMPANY_MIN_LENGTH', '2', 2, 6, NULL, '0000-00-00 00:00:00', NULL, NULL),
(36, 'ENTRY_POSTCODE_MIN_LENGTH', '4', 2, 7, NULL, '0000-00-00 00:00:00', NULL, NULL),
(37, 'ENTRY_CITY_MIN_LENGTH', '3', 2, 8, NULL, '0000-00-00 00:00:00', NULL, NULL),
(38, 'ENTRY_STATE_MIN_LENGTH', '2', 2, 9, NULL, '0000-00-00 00:00:00', NULL, NULL),
(39, 'ENTRY_TELEPHONE_MIN_LENGTH', '3', 2, 10, NULL, '0000-00-00 00:00:00', NULL, NULL),
(40, 'ENTRY_PASSWORD_MIN_LENGTH', '5', 2, 11, NULL, '0000-00-00 00:00:00', NULL, NULL),
(41, 'CC_OWNER_MIN_LENGTH', '3', 2, 12, NULL, '0000-00-00 00:00:00', NULL, NULL),
(42, 'CC_NUMBER_MIN_LENGTH', '10', 2, 13, NULL, '0000-00-00 00:00:00', NULL, NULL),
(43, 'REVIEW_TEXT_MIN_LENGTH', '10', 2, 14, NULL, '0000-00-00 00:00:00', NULL, NULL),
(44, 'MIN_DISPLAY_BESTSELLERS', '1', 2, 15, NULL, '0000-00-00 00:00:00', NULL, NULL),
(45, 'MIN_DISPLAY_ALSO_PURCHASED', '1', 2, 16, NULL, '0000-00-00 00:00:00', NULL, NULL),
(46, 'MAX_ADDRESS_BOOK_ENTRIES', '5', 3, 1, NULL, '0000-00-00 00:00:00', NULL, NULL),
(47, 'MAX_DISPLAY_SEARCH_RESULTS', '20', 3, 2, NULL, '0000-00-00 00:00:00', NULL, NULL),
(48, 'MAX_DISPLAY_ADMIN_PAGE', '20', 3, 3, NULL, '0000-00-00 00:00:00', NULL, NULL),
(49, 'MAX_DISPLAY_PAGE_LINKS', '5', 3, 4, NULL, '0000-00-00 00:00:00', NULL, NULL),
(50, 'MAX_DISPLAY_SPECIAL_PRODUCTS', '9', 3, 5, NULL, '0000-00-00 00:00:00', NULL, NULL),
(51, 'MAX_DISPLAY_NEW_PRODUCTS', '9', 3, 6, NULL, '0000-00-00 00:00:00', NULL, NULL),
(52, 'MAX_DISPLAY_UPCOMING_PRODUCTS', '10', 3, 7, NULL, '0000-00-00 00:00:00', NULL, NULL),
(53, 'MAX_DISPLAY_MANUFACTURERS_IN_A_LIST', '0', 3, 8, NULL, '0000-00-00 00:00:00', NULL, NULL),
(54, 'MAX_MANUFACTURERS_LIST', '1', 3, 9, NULL, '0000-00-00 00:00:00', NULL, NULL),
(55, 'MAX_DISPLAY_MANUFACTURER_NAME_LEN', '15', 3, 10, NULL, '0000-00-00 00:00:00', NULL, NULL),
(56, 'MAX_DISPLAY_NEW_REVIEWS', '6', 3, 11, NULL, '0000-00-00 00:00:00', NULL, NULL),
(57, 'MAX_RANDOM_SELECT_REVIEWS', '10', 3, 12, NULL, '0000-00-00 00:00:00', NULL, NULL),
(58, 'MAX_RANDOM_SELECT_NEW', '10', 3, 13, NULL, '0000-00-00 00:00:00', NULL, NULL),
(59, 'MAX_RANDOM_SELECT_SPECIALS', '10', 3, 14, NULL, '0000-00-00 00:00:00', NULL, NULL),
(60, 'MAX_DISPLAY_CATEGORIES_PER_ROW', '3', 3, 15, NULL, '0000-00-00 00:00:00', NULL, NULL),
(61, 'MAX_DISPLAY_PRODUCTS_NEW', '10', 3, 16, NULL, '0000-00-00 00:00:00', NULL, NULL),
(62, 'MAX_DISPLAY_BESTSELLERS', '10', 3, 17, NULL, '0000-00-00 00:00:00', NULL, NULL),
(63, 'MAX_DISPLAY_ALSO_PURCHASED', '6', 3, 18, NULL, '0000-00-00 00:00:00', NULL, NULL),
(64, 'MAX_DISPLAY_PRODUCTS_IN_ORDER_HISTORY_BOX', '6', 3, 19, NULL, '0000-00-00 00:00:00', NULL, NULL),
(65, 'MAX_DISPLAY_ORDER_HISTORY', '10', 3, 20, NULL, '0000-00-00 00:00:00', NULL, NULL),
(66, 'PRODUCT_REVIEWS_VIEW', '5', 3, 21, NULL, '0000-00-00 00:00:00', NULL, NULL),
(67, 'MAX_PRODUCTS_QTY', '1000', 3, 22, '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, NULL),
(68, 'MAX_DISPLAY_NEW_PRODUCTS_DAYS', '30', 3, 23, '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, NULL),
(69, 'MAX_RANDOM_SELECT_FEATURED', '10', 3, 24, NULL, '0000-00-00 00:00:00', NULL, NULL),
(70, 'MAX_DISPLAY_FEATURED_PRODUCTS', '9', 3, 25, NULL, '0000-00-00 00:00:00', NULL, NULL),
(71, 'MAX_DISPLAY_FAQ', '2', 3, 26, '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, NULL),
(72, 'MAX_DISPLAY_FAQ_PAGE', '20', 3, 27, '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, NULL),
(73, 'MAX_DISPLAY_FAQ_ANSWER', '150', 3, 28, '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, NULL),
(74, 'MAX_DISPLAY_LATEST_NEWS', '2', 3, 23, '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, NULL),
(75, 'MAX_DISPLAY_LATEST_NEWS_PAGE', '20', 3, 24, '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, NULL),
(76, 'MAX_DISPLAY_LATEST_NEWS_CONTENT', '150', 3, 25, '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, NULL),
(77, 'MAX_DISPLAY_CART', '50', 3, 26, '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, NULL),
(78, 'MAX_DISPLAY_SHORT_DESCRIPTION', '80', 3, 27, '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, NULL),
(79, 'CONFIG_CALCULATE_IMAGE_SIZE', 'true', 4, 1, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(80, 'IMAGE_QUALITY', '80', 4, 2, '2003-12-15 12:10:45', '0000-00-00 00:00:00', NULL, NULL),
(81, 'PRODUCT_IMAGE_THUMBNAIL_WIDTH', '120', 4, 7, '2003-12-15 12:10:45', '0000-00-00 00:00:00', NULL, NULL),
(82, 'PRODUCT_IMAGE_THUMBNAIL_HEIGHT', '80', 4, 8, NULL, '0000-00-00 00:00:00', NULL, NULL),
(83, 'PRODUCT_IMAGE_INFO_WIDTH', '240', 4, 9, NULL, '0000-00-00 00:00:00', NULL, NULL),
(84, 'PRODUCT_IMAGE_INFO_HEIGHT', '160', 4, 10, NULL, '0000-00-00 00:00:00', NULL, NULL),
(85, 'PRODUCT_IMAGE_POPUP_WIDTH', '600', 4, 11, '2003-12-15 12:11:00', '0000-00-00 00:00:00', NULL, NULL),
(86, 'PRODUCT_IMAGE_POPUP_HEIGHT', '480', 4, 12, '2003-12-15 12:11:09', '0000-00-00 00:00:00', NULL, NULL),
(87, 'PRODUCT_IMAGE_THUMBNAIL_BEVEL', '', 4, 13, '2003-12-15 13:14:39', '0000-00-00 00:00:00', '', ''),
(88, 'PRODUCT_IMAGE_THUMBNAIL_ACTIVE', 'true', 4, 14, '2003-12-15 13:14:39', '0000-00-00 00:00:00', '', 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(89, 'PRODUCT_IMAGE_THUMBNAIL_GREYSCALE', '', 4, 15, '2003-12-15 13:13:37', '0000-00-00 00:00:00', NULL, NULL),
(90, 'PRODUCT_IMAGE_THUMBNAIL_ELLIPSE', '', 4, 16, '2003-12-15 13:14:57', '0000-00-00 00:00:00', NULL, NULL),
(91, 'PRODUCT_IMAGE_THUMBNAIL_ROUND_EDGES', '', 4, 17, '2003-12-15 13:19:45', '0000-00-00 00:00:00', NULL, NULL),
(92, 'PRODUCT_IMAGE_THUMBNAIL_MERGE', '', 4, 18, '2003-12-15 12:01:43', '0000-00-00 00:00:00', NULL, NULL),
(93, 'PRODUCT_IMAGE_THUMBNAIL_FRAME', '', 4, 19, '2003-12-15 13:19:37', '0000-00-00 00:00:00', NULL, NULL),
(94, 'PRODUCT_IMAGE_THUMBNAIL_DROP_SHADDOW', '', 4, 20, '2003-12-15 13:15:14', '0000-00-00 00:00:00', NULL, NULL),
(95, 'PRODUCT_IMAGE_THUMBNAIL_MOTION_BLUR', '', 4, 21, '2003-12-15 12:02:19', '0000-00-00 00:00:00', NULL, NULL),
(96, 'PRODUCT_IMAGE_INFO_ACTIVE', 'true', 4, 22, '2003-12-15 13:14:39', '0000-00-00 00:00:00', '', 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(97, 'PRODUCT_IMAGE_INFO_BEVEL', '', 4, 23, '2003-12-15 13:42:09', '0000-00-00 00:00:00', NULL, NULL),
(98, 'PRODUCT_IMAGE_INFO_GREYSCALE', '', 4, 24, '2003-12-15 13:18:00', '0000-00-00 00:00:00', NULL, NULL),
(99, 'PRODUCT_IMAGE_INFO_ELLIPSE', '', 4, 25, '2003-12-15 13:41:53', '0000-00-00 00:00:00', NULL, NULL),
(100, 'PRODUCT_IMAGE_INFO_ROUND_EDGES', '', 4, 26, '2003-12-15 13:21:55', '0000-00-00 00:00:00', NULL, NULL),
(101, 'PRODUCT_IMAGE_INFO_MERGE', '(overlay.gif,10,-50,60,FF0000)', 4, 27, NULL, '0000-00-00 00:00:00', NULL, NULL),
(102, 'PRODUCT_IMAGE_INFO_FRAME', '', 4, 28, NULL, '0000-00-00 00:00:00', NULL, NULL),
(103, 'PRODUCT_IMAGE_INFO_DROP_SHADDOW', '(0,FFFFFF,FFFFFF)', 4, 29, NULL, '0000-00-00 00:00:00', NULL, NULL),
(104, 'PRODUCT_IMAGE_INFO_MOTION_BLUR', '', 4, 30, '2003-12-15 13:21:18', '0000-00-00 00:00:00', NULL, NULL),
(105, 'PRODUCT_IMAGE_POPUP_BEVEL', '(0,FFFFFF,FFFFFF)', 4, 31, NULL, '0000-00-00 00:00:00', NULL, NULL),
(106, 'PRODUCT_IMAGE_POPUP_ACTIVE', 'true', 4, 32, '2003-12-15 13:14:39', '0000-00-00 00:00:00', '', 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(107, 'PRODUCT_IMAGE_POPUP_GREYSCALE', '', 4, 33, '2003-12-15 13:22:58', '0000-00-00 00:00:00', NULL, NULL),
(108, 'PRODUCT_IMAGE_POPUP_ELLIPSE', '', 4, 34, '2003-12-15 13:22:51', '0000-00-00 00:00:00', NULL, NULL),
(109, 'PRODUCT_IMAGE_POPUP_ROUND_EDGES', '', 4, 35, '2003-12-15 13:23:17', '0000-00-00 00:00:00', NULL, NULL),
(110, 'PRODUCT_IMAGE_POPUP_MERGE', '(overlay.gif,10,-50,60,FF0000)', 4, 36, NULL, '0000-00-00 00:00:00', NULL, NULL),
(111, 'PRODUCT_IMAGE_POPUP_FRAME', '', 4, 37, '2003-12-15 13:22:43', '0000-00-00 00:00:00', NULL, NULL),
(112, 'PRODUCT_IMAGE_POPUP_DROP_SHADDOW', '', 4, 38, '2003-12-15 13:22:26', '0000-00-00 00:00:00', NULL, NULL),
(113, 'PRODUCT_IMAGE_POPUP_MOTION_BLUR', '', 4, 39, '2003-12-15 13:22:32', '0000-00-00 00:00:00', NULL, NULL),
(114, 'CATEGORIES_IMAGE_THUMBNAIL_ACTIVE', 'true', 4, 40, '2003-12-15 13:14:39', '0000-00-00 00:00:00', '', 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(115, 'CATEGORIES_IMAGE_THUMBNAIL_WIDTH', '120', 4, 41, '2003-12-15 12:10:45', '0000-00-00 00:00:00', NULL, NULL),
(116, 'CATEGORIES_IMAGE_THUMBNAIL_HEIGHT', '80', 4, 42, NULL, '0000-00-00 00:00:00', NULL, NULL),
(117, 'CATEGORIES_IMAGE_THUMBNAIL_BEVEL', '', 4, 43, '2003-12-15 13:14:39', '0000-00-00 00:00:00', '', ''),
(118, 'CATEGORIES_IMAGE_THUMBNAIL_GREYSCALE', '', 4, 44, '2003-12-15 13:13:37', '0000-00-00 00:00:00', NULL, NULL),
(119, 'CATEGORIES_IMAGE_THUMBNAIL_ELLIPSE', '', 4, 45, '2003-12-15 13:14:57', '0000-00-00 00:00:00', NULL, NULL),
(120, 'CATEGORIES_IMAGE_THUMBNAIL_ROUND_EDGES', '', 4, 46, '2003-12-15 13:19:45', '0000-00-00 00:00:00', NULL, NULL),
(121, 'CATEGORIES_IMAGE_THUMBNAIL_MERGE', '', 4, 47, '2003-12-15 12:01:43', '0000-00-00 00:00:00', NULL, NULL),
(122, 'CATEGORIES_IMAGE_THUMBNAIL_FRAME', '', 4, 48, '2003-12-15 13:19:37', '0000-00-00 00:00:00', NULL, NULL),
(123, 'CATEGORIES_IMAGE_THUMBNAIL_DROP_SHADDOW', '', 4, 49, '2003-12-15 13:15:14', '0000-00-00 00:00:00', NULL, NULL),
(124, 'CATEGORIES_IMAGE_THUMBNAIL_MOTION_BLUR', '', 4, 50, '2003-12-15 12:02:19', '0000-00-00 00:00:00', NULL, NULL),
(125, 'USE_EP_IMAGE_MANIPULATOR', 'false', 4, 51, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(126, 'MO_PICS', '0', 4, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, NULL),
(127, 'IMAGE_MANIPULATOR', 'image_manipulator_GD2.php', 4, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'image_manipulator_GD2.php\', \'image_manipulator_GD1.php\'),'),
(128, 'MAX_THUMB_WIDTH', '120', 4, 52, '2003-12-15 12:10:45', '0000-00-00 00:00:00', NULL, NULL),
(129, 'MAX_THUMB_HEIGHT', '100', 4, 53, '2003-12-15 12:10:45', '0000-00-00 00:00:00', NULL, NULL),
(130, 'MAX_ADMIN_WIDTH', '100', 4, 54, '2003-12-15 12:10:45', '0000-00-00 00:00:00', NULL, NULL),
(131, 'MAX_ADMIN_HEIGHT', '80', 4, 55, '2003-12-15 12:10:45', '0000-00-00 00:00:00', NULL, NULL),
(132, 'MAX_BYTE_SIZE', '1000000', 4, 56, '2003-12-15 12:10:45', '0000-00-00 00:00:00', NULL, NULL),
(133, 'ACCOUNT_SECOND_NAME', 'false', 5, 1, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(134, 'ACCOUNT_GENDER', 'false', 5, 2, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(135, 'ACCOUNT_DOB', 'false', 5, 3, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(136, 'ACCOUNT_COMPANY', 'false', 5, 4, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(137, 'ACCOUNT_STREET_ADDRESS', 'true', 5, 5, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(138, 'ACCOUNT_CITY', 'true', 5, 6, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(139, 'ACCOUNT_POSTCODE', 'true', 5, 7, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(140, 'ACCOUNT_COUNTRY', 'true', 5, 8, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(141, 'ACCOUNT_TELE', 'true', 5, 9, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(142, 'ACCOUNT_FAX', 'true', 5, 10, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(143, 'ACCOUNT_SUBURB', 'false', 5, 11, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(144, 'ACCOUNT_STATE', 'true', 5, 12, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(145, 'ACCOUNT_OPTIONS', 'both', 5, 13, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'account\', \'guest\', \'both\'),'),
(146, 'DELETE_GUEST_ACCOUNT', 'false', 5, 14, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(147, 'MODULE_PAYMENT_INSTALLED', 'cod.php', 6, 0, '2012-03-12 09:32:58', '0000-00-00 00:00:00', NULL, NULL),
(148, 'MODULE_ORDER_TOTAL_INSTALLED', 'ot_subtotal.php;ot_discount.php;ot_shipping.php;ot_subtotal_no_tax.php;ot_tax.php;ot_total.php', 6, 0, '2012-03-12 12:49:46', '0000-00-00 00:00:00', NULL, NULL),
(149, 'MODULE_SHIPPING_INSTALLED', 'flat.php', 6, 0, '2012-03-12 09:33:11', '0000-00-00 00:00:00', NULL, NULL),
(150, 'DEFAULT_CURRENCY', 'RUR', 6, 0, NULL, '0000-00-00 00:00:00', NULL, NULL),
(151, 'DEFAULT_LANGUAGE', 'ru', 6, 0, NULL, '0000-00-00 00:00:00', NULL, NULL),
(152, 'DEFAULT_ORDERS_STATUS_ID', '1', 6, 0, NULL, '0000-00-00 00:00:00', NULL, NULL),
(153, 'DEFAULT_PRODUCTS_VPE_ID', '', 6, 0, NULL, '0000-00-00 00:00:00', NULL, NULL),
(154, 'DEFAULT_SHIPPING_STATUS_ID', '1', 6, 0, NULL, '0000-00-00 00:00:00', NULL, NULL),
(155, 'MODULE_ORDER_TOTAL_SHIPPING_STATUS', 'true', 6, 1, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(156, 'MODULE_ORDER_TOTAL_SHIPPING_SORT_ORDER', '30', 6, 2, NULL, '0000-00-00 00:00:00', NULL, NULL),
(157, 'MODULE_ORDER_TOTAL_SHIPPING_FREE_SHIPPING', 'false', 6, 3, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(158, 'MODULE_ORDER_TOTAL_SHIPPING_FREE_SHIPPING_OVER', '50', 6, 4, NULL, '0000-00-00 00:00:00', 'currencies->format', NULL),
(159, 'MODULE_ORDER_TOTAL_SHIPPING_DESTINATION', 'national', 6, 5, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'national\', \'international\', \'both\'),'),
(160, 'MODULE_ORDER_TOTAL_SUBTOTAL_STATUS', 'true', 6, 1, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(161, 'MODULE_ORDER_TOTAL_SUBTOTAL_SORT_ORDER', '10', 6, 2, NULL, '0000-00-00 00:00:00', NULL, NULL),
(162, 'MODULE_ORDER_TOTAL_TAX_STATUS', 'true', 6, 1, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(163, 'MODULE_ORDER_TOTAL_TAX_SORT_ORDER', '50', 6, 2, NULL, '0000-00-00 00:00:00', NULL, NULL),
(164, 'MODULE_ORDER_TOTAL_TOTAL_STATUS', 'true', 6, 1, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(165, 'MODULE_ORDER_TOTAL_TOTAL_SORT_ORDER', '99', 6, 2, NULL, '0000-00-00 00:00:00', NULL, NULL),
(166, 'MODULE_ORDER_TOTAL_DISCOUNT_STATUS', 'true', 6, 1, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(167, 'MODULE_ORDER_TOTAL_DISCOUNT_SORT_ORDER', '20', 6, 2, NULL, '0000-00-00 00:00:00', NULL, NULL),
(168, 'MODULE_ORDER_TOTAL_SUBTOTAL_NO_TAX_STATUS', 'true', 6, 1, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(169, 'MODULE_ORDER_TOTAL_SUBTOTAL_NO_TAX_SORT_ORDER', '40', 6, 2, NULL, '0000-00-00 00:00:00', NULL, NULL),
(170, 'SHIPPING_ORIGIN_COUNTRY', '176', 7, 1, NULL, '0000-00-00 00:00:00', 'vam_get_country_name', 'vam_cfg_pull_down_country_list('),
(171, 'SHIPPING_ORIGIN_ZIP', 'POST_CODE', 7, 2, NULL, '0000-00-00 00:00:00', NULL, NULL),
(172, 'SHIPPING_MAX_WEIGHT', '50', 7, 3, NULL, '0000-00-00 00:00:00', NULL, NULL),
(173, 'SHIPPING_BOX_WEIGHT', '', 7, 4, NULL, '0000-00-00 00:00:00', NULL, NULL),
(174, 'SHIPPING_BOX_PADDING', '', 7, 5, NULL, '0000-00-00 00:00:00', NULL, NULL),
(175, 'SHOW_SHIPPING', 'true', 7, 6, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(176, 'SHIPPING_INFOS', '1', 7, 7, NULL, '0000-00-00 00:00:00', NULL, NULL),
(177, 'PRODUCT_LIST_FILTER', '1', 8, 1, NULL, '0000-00-00 00:00:00', NULL, NULL),
(178, 'PRODUCT_LIST_RECURSIVE', 'false', 8, 2, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(179, 'STOCK_CHECK', 'false', 9, 1, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(180, 'ATTRIBUTE_STOCK_CHECK', 'false', 9, 2, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(181, 'STOCK_LIMITED', 'false', 9, 3, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(182, 'STOCK_ALLOW_CHECKOUT', 'true', 9, 4, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(183, 'STOCK_MARK_PRODUCT_OUT_OF_STOCK', '***', 9, 5, NULL, '0000-00-00 00:00:00', NULL, NULL),
(184, 'STOCK_REORDER_LEVEL', '5', 9, 6, NULL, '0000-00-00 00:00:00', NULL, NULL),
(185, 'STORE_PAGE_PARSE_TIME', 'false', 10, 1, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(186, 'STORE_PAGE_PARSE_TIME_LOG', '/var/log/www/tep/page_parse_time.log', 10, 2, NULL, '0000-00-00 00:00:00', NULL, NULL),
(187, 'STORE_PARSE_DATE_TIME_FORMAT', '%d/%m/%Y %H:%M:%S', 10, 3, NULL, '0000-00-00 00:00:00', NULL, NULL),
(188, 'DISPLAY_PAGE_PARSE_TIME', 'false', 10, 4, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(189, 'STORE_DB_TRANSACTIONS', 'false', 10, 5, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(190, 'USE_CACHE', 'false', 11, 1, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(191, 'DIR_FS_CACHE', 'cache', 11, 2, NULL, '0000-00-00 00:00:00', NULL, NULL),
(192, 'CACHE_LIFETIME', '3600', 11, 3, NULL, '0000-00-00 00:00:00', NULL, NULL),
(193, 'CACHE_CHECK', 'true', 11, 4, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(194, 'DB_CACHE', 'false', 11, 5, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(195, 'DB_CACHE_EXPIRE', '3600', 11, 6, NULL, '0000-00-00 00:00:00', NULL, NULL),
(196, 'EMAIL_TRANSPORT', 'mail', 12, 1, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'sendmail\', \'smtp\', \'mail\'),'),
(197, 'SENDMAIL_PATH', '/usr/sbin/sendmail', 12, 2, NULL, '0000-00-00 00:00:00', NULL, NULL),
(198, 'SMTP_MAIN_SERVER', 'localhost', 12, 3, NULL, '0000-00-00 00:00:00', NULL, NULL),
(199, 'SMTP_Backup_Server', 'localhost', 12, 4, NULL, '0000-00-00 00:00:00', NULL, NULL),
(200, 'SMTP_PORT', '25', 12, 5, NULL, '0000-00-00 00:00:00', NULL, NULL),
(201, 'SMTP_USERNAME', 'Please Enter', 12, 6, NULL, '0000-00-00 00:00:00', NULL, NULL),
(202, 'SMTP_PASSWORD', 'Please Enter', 12, 7, NULL, '0000-00-00 00:00:00', NULL, NULL),
(203, 'SMTP_AUTH', 'false', 12, 8, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(204, 'EMAIL_LINEFEED', 'LF', 12, 9, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'LF\', \'CRLF\'),'),
(205, 'EMAIL_USE_HTML', 'false', 12, 10, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(206, 'ENTRY_EMAIL_ADDRESS_CHECK', 'false', 12, 11, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(207, 'SEND_EMAILS', 'true', 12, 12, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(208, 'CONTACT_US_EMAIL_ADDRESS', 'example@example.com', 12, 20, NULL, '0000-00-00 00:00:00', NULL, NULL),
(209, 'CONTACT_US_NAME', 'Mail send by Contact_us Form', 12, 21, NULL, '0000-00-00 00:00:00', NULL, NULL),
(210, 'CONTACT_US_REPLY_ADDRESS', '', 12, 22, NULL, '0000-00-00 00:00:00', NULL, NULL),
(211, 'CONTACT_US_REPLY_ADDRESS_NAME', '', 12, 23, NULL, '0000-00-00 00:00:00', NULL, NULL),
(212, 'CONTACT_US_EMAIL_SUBJECT', '', 12, 24, NULL, '0000-00-00 00:00:00', NULL, NULL),
(213, 'CONTACT_US_FORWARDING_STRING', '', 12, 25, NULL, '0000-00-00 00:00:00', NULL, NULL),
(214, 'EMAIL_SUPPORT_ADDRESS', 'example@example.com', 12, 26, NULL, '0000-00-00 00:00:00', NULL, NULL),
(215, 'EMAIL_SUPPORT_NAME', 'Mail send by support systems', 12, 27, NULL, '0000-00-00 00:00:00', NULL, NULL),
(216, 'EMAIL_SUPPORT_REPLY_ADDRESS', '', 12, 28, NULL, '0000-00-00 00:00:00', NULL, NULL),
(217, 'EMAIL_SUPPORT_REPLY_ADDRESS_NAME', '', 12, 29, NULL, '0000-00-00 00:00:00', NULL, NULL),
(218, 'EMAIL_SUPPORT_SUBJECT', '', 12, 30, NULL, '0000-00-00 00:00:00', NULL, NULL),
(219, 'EMAIL_SUPPORT_FORWARDING_STRING', '', 12, 31, NULL, '0000-00-00 00:00:00', NULL, NULL),
(220, 'EMAIL_BILLING_ADDRESS', 'example@example.com', 12, 32, NULL, '0000-00-00 00:00:00', NULL, NULL),
(221, 'EMAIL_BILLING_NAME', 'Mail send by billing systems', 12, 33, NULL, '0000-00-00 00:00:00', NULL, NULL),
(222, 'EMAIL_BILLING_REPLY_ADDRESS', '', 12, 34, NULL, '0000-00-00 00:00:00', NULL, NULL),
(223, 'EMAIL_BILLING_REPLY_ADDRESS_NAME', '', 12, 35, NULL, '0000-00-00 00:00:00', NULL, NULL),
(224, 'EMAIL_BILLING_SUBJECT', 'Ваш заказ номер {$nr}', 12, 36, NULL, '0000-00-00 00:00:00', NULL, NULL),
(225, 'EMAIL_BILLING_FORWARDING_STRING', 'example@example.com', 12, 37, NULL, '0000-00-00 00:00:00', NULL, NULL),
(226, 'EMAIL_BILLING_SUBJECT_ORDER', 'Ваш заказ номер {$nr}', 12, 38, NULL, '0000-00-00 00:00:00', NULL, NULL),
(227, 'DOWNLOAD_ENABLED', 'false', 13, 1, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(228, 'DOWNLOAD_BY_REDIRECT', 'false', 13, 2, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(229, 'DOWNLOAD_UNALLOWED_PAYMENT', 'banktransfer,cod,invoice,moneyorder', 13, 5, NULL, '0000-00-00 00:00:00', NULL, NULL),
(230, 'DOWNLOAD_MIN_ORDERS_STATUS', '4', 13, 5, NULL, '0000-00-00 00:00:00', NULL, NULL),
(231, 'GZIP_COMPRESSION', 'false', 14, 1, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(232, 'GZIP_LEVEL', '5', 14, 2, NULL, '0000-00-00 00:00:00', NULL, NULL),
(233, 'SESSION_WRITE_DIRECTORY', 'tmp', 15, 1, NULL, '0000-00-00 00:00:00', NULL, NULL),
(234, 'SESSION_FORCE_COOKIE_USE', 'True', 15, 2, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'True\', \'False\'),'),
(235, 'SESSION_CHECK_SSL_SESSION_ID', 'False', 15, 3, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'True\', \'False\'),'),
(236, 'SESSION_CHECK_USER_AGENT', 'False', 15, 4, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'True\', \'False\'),'),
(237, 'SESSION_CHECK_IP_ADDRESS', 'False', 15, 5, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'True\', \'False\'),'),
(238, 'SESSION_RECREATE', 'False', 15, 7, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'True\', \'False\'),'),
(239, 'SESSION_TIMEOUT_ADMIN', '14400', 15, 8, NULL, '0000-00-00 00:00:00', NULL, NULL),
(240, 'SESSION_TIMEOUT_CATALOG', '1440', 15, 9, NULL, '0000-00-00 00:00:00', NULL, NULL),
(241, 'META_ROBOTS', 'index,follow', 16, 10, NULL, '0000-00-00 00:00:00', NULL, NULL),
(242, 'META_DESCRIPTION', '', 16, 11, NULL, '0000-00-00 00:00:00', NULL, NULL),
(243, 'META_KEYWORDS', '', 16, 12, NULL, '0000-00-00 00:00:00', NULL, NULL),
(244, 'CHECK_CLIENT_AGENT', 'true', 16, 13, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(245, 'ACTIVATE_GIFT_SYSTEM', 'false', 17, 2, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(246, 'SECURITY_CODE_LENGTH', '10', 17, 3, NULL, '2003-12-05 05:01:41', NULL, NULL),
(247, 'NEW_SIGNUP_GIFT_VOUCHER_AMOUNT', '0', 17, 4, NULL, '2003-12-05 05:01:41', NULL, NULL),
(248, 'NEW_SIGNUP_DISCOUNT_COUPON', '', 17, 5, NULL, '2003-12-05 05:01:41', NULL, NULL),
(249, 'ACTIVATE_SHIPPING_STATUS', 'true', 17, 6, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(250, 'DISPLAY_CONDITIONS_ON_CHECKOUT', 'false', 17, 7, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(251, 'SHOW_IP_LOG', 'false', 17, 8, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(252, 'GROUP_CHECK', 'false', 17, 9, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(253, 'ACTIVATE_NAVIGATOR', 'false', 17, 10, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(254, 'QUICKLINK_ACTIVATED', 'true', 17, 11, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(255, 'ACTIVATE_REVERSE_CROSS_SELLING', 'false', 17, 12, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(256, 'DISPLAY_REVOCATION_ON_CHECKOUT', 'true', 17, 13, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(257, 'REVOCATION_ID', '', 17, 14, NULL, '2003-12-05 05:01:41', NULL, NULL),
(258, 'LOGIN_NUM', '3', 17, 16, NULL, '0000-00-00 00:00:00', NULL, NULL),
(259, 'LOGIN_TIME', '300', 17, 17, NULL, '0000-00-00 00:00:00', NULL, NULL),
(260, 'QUICK_CHECKOUT', 'false', 17, 18, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(261, 'XSELL_CART', 'false', 17, 19, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(262, 'ENABLE_MAP_TAB', 'true', 17, 20, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(263, 'MAP_API_KEY', '', 17, 21, NULL, '0000-00-00 00:00:00', NULL, NULL),
(264, 'AUTOMATIC_SEO_URL', 'false', 17, 22, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(265, 'ACCOUNT_COMPANY_VAT_CHECK', 'false', 18, 4, '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(266, 'STORE_OWNER_VAT_ID', '', 18, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, NULL),
(267, 'DEFAULT_CUSTOMERS_VAT_STATUS_ID', '1', 18, 23, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'vam_get_customers_status_name', 'vam_cfg_pull_down_customers_status_list('),
(268, 'ACCOUNT_COMPANY_VAT_LIVE_CHECK', 'true', 18, 4, '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(269, 'ACCOUNT_COMPANY_VAT_GROUP', 'true', 18, 4, '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(270, 'ACCOUNT_VAT_BLOCK_ERROR', 'true', 18, 4, '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(271, 'DEFAULT_CUSTOMERS_VAT_STATUS_ID_LOCAL', '3', 18, 24, NULL, '0000-00-00 00:00:00', 'vam_get_customers_status_name', 'vam_cfg_pull_down_customers_status_list('),
(272, 'GOOGLE_CONVERSION_ID', 'UA-XXXXXX-X', 19, 2, NULL, '0000-00-00 00:00:00', NULL, NULL),
(273, 'GOOGLE_LANG', 'ru', 19, 3, NULL, '0000-00-00 00:00:00', NULL, NULL),
(274, 'GOOGLE_CONVERSION', 'false', 19, 0, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(275, 'CSV_TEXTSIGN', '\"', 20, 1, NULL, '0000-00-00 00:00:00', NULL, NULL),
(276, 'CSV_SEPERATOR', '', 20, 2, NULL, '0000-00-00 00:00:00', NULL, NULL),
(277, 'COMPRESS_EXPORT', 'false', 20, 3, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(278, 'AFTERBUY_PARTNERID', '', 21, 2, NULL, '0000-00-00 00:00:00', NULL, NULL),
(279, 'AFTERBUY_PARTNERPASS', '', 21, 3, NULL, '0000-00-00 00:00:00', NULL, NULL),
(280, 'AFTERBUY_USERID', '', 21, 4, NULL, '0000-00-00 00:00:00', NULL, NULL),
(281, 'AFTERBUY_ORDERSTATUS', '1', 21, 5, NULL, '0000-00-00 00:00:00', 'vam_get_order_status_name', 'vam_cfg_pull_down_order_statuses('),
(282, 'AFTERBUY_ACTIVATED', 'false', 21, 6, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(283, 'SEARCH_IN_DESC', 'true', 22, 2, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(284, 'SEARCH_IN_ATTR', 'true', 22, 3, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(285, 'YML_NAME', '', 23, 1, NULL, '0000-00-00 00:00:00', NULL, NULL),
(286, 'YML_COMPANY', '', 23, 2, NULL, '0000-00-00 00:00:00', NULL, NULL),
(287, 'YML_DELIVERYINCLUDED', 'false', 23, 3, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(288, 'YML_AVAILABLE', 'stock', 23, 4, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\', \'stock\'),'),
(289, 'YML_AUTH_USER', '', 23, 5, NULL, '0000-00-00 00:00:00', NULL, NULL),
(290, 'YML_AUTH_PW', '', 23, 6, NULL, '0000-00-00 00:00:00', NULL, NULL),
(291, 'YML_REFERER', 'false', 23, 7, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'false\', \'ip\', \'agent\'),'),
(292, 'YML_STRIP_TAGS', 'true', 23, 8, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(293, 'YML_UTF8', 'false', 23, 9, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(294, 'YML_VENDOR', 'false', 23, 10, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(295, 'YML_REF_ID', '&amp;ref=yml', 23, 11, NULL, '0000-00-00 00:00:00', NULL, NULL),
(296, 'YML_REF_IP', 'true', 23, 12, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(297, 'YML_USE_CDATA', 'false', 23, 13, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(298, 'YML_SALES_NOTES', '', 23, 14, NULL, '0000-00-00 00:00:00', NULL, NULL),
(299, 'DISPLAY_MODEL', 'true', 24, 1, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(300, 'MODIFY_MODEL', 'true', 24, 2, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(301, 'MODIFY_NAME', 'true', 24, 3, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(302, 'DISPLAY_STATUT', 'true', 24, 4, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(303, 'DISPLAY_WEIGHT', 'true', 24, 5, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(304, 'DISPLAY_QUANTITY', 'true', 24, 6, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(305, 'DISPLAY_IMAGE', 'false', 24, 7, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(306, 'DISPLAY_XML', 'true', 24, 8, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(307, 'DISPLAY_START_PAGE', 'true', 24, 9, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(308, 'DISPLAY_SORT', 'true', 24, 10, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(309, 'MODIFY_MANUFACTURER', 'true', 24, 11, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(310, 'MODIFY_TAX', 'true', 24, 12, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(311, 'DISPLAY_TVA_OVER', 'true', 24, 13, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(312, 'DISPLAY_TVA_UP', 'true', 24, 14, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(313, 'DISPLAY_PREVIEW', 'true', 24, 15, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(314, 'DISPLAY_EDIT', 'true', 24, 16, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(315, 'DISPLAY_MANUFACTURER', 'true', 24, 17, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(316, 'DISPLAY_TAX', 'true', 24, 18, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(317, 'ACTIVATE_COMMERCIAL_MARGIN', 'true', 24, 19, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(318, 'ALLOW_SQL_BACKUP', 'true', 25, 2, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(319, 'ALLOW_SQL_RESTORE', 'false', 25, 3, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(320, 'ALLOW_FILES_BACKUP', 'true', 25, 4, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(321, 'ALLOW_FILES_RESTORE', 'false', 25, 5, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(322, 'ALLOW_OVERWRITE_MODIFIED', 'false', 25, 6, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(323, 'TEXT_LINK_FORUM', 'http://vamshop.ru/forum/index.php?topic=', 25, 7, NULL, '0000-00-00 00:00:00', NULL, NULL),
(324, 'TEXT_LINK_CONTR', 'http://vamshop.ru/product_info.php?products_id=', 25, 8, NULL, '0000-00-00 00:00:00', NULL, NULL),
(325, 'ALWAYS_DISPLAY_REMOVE_BUTTON', 'false', 25, 9, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(326, 'ALWAYS_DISPLAY_INSTALL_BUTTON', 'false', 25, 10, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(327, 'SHOW_PERMISSIONS_COLUMN', 'false', 25, 11, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(328, 'SHOW_USER_GROUP_COLUMN', 'false', 25, 12, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(329, 'SHOW_UPLOADER_COLUMN', 'false', 25, 13, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(330, 'SHOW_UPLOADED_COLUMN', 'false', 25, 14, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(331, 'SHOW_SIZE_COLUMN', 'false', 25, 15, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(332, 'USE_LOG_SYSTEM', 'false', 25, 16, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(333, 'MAX_UPLOADED_FILESIZE', '2524288', 25, 17, NULL, '0000-00-00 00:00:00', NULL, NULL),
(334, 'DISPLAY_NEW_ARTICLES', 'true', 26, 1, '2012-03-10 22:55:53', '2012-03-10 22:55:53', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(335, 'NEW_ARTICLES_DAYS_DISPLAY', '30', 26, 2, '2012-03-10 22:55:53', '2012-03-10 22:55:53', NULL, NULL),
(336, 'MAX_NEW_ARTICLES_PER_PAGE', '10', 26, 3, '2012-03-10 22:55:53', '2012-03-10 22:55:53', NULL, NULL),
(337, 'DISPLAY_ALL_ARTICLES', 'true', 26, 4, '2012-03-10 22:55:53', '2012-03-10 22:55:53', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(338, 'MAX_ARTICLES_PER_PAGE', '10', 26, 5, '2012-03-10 22:55:53', '2012-03-10 22:55:53', NULL, NULL),
(339, 'SHOW_ARTICLE_COUNTS', 'true', 26, 11, '2012-03-10 22:55:53', '2012-03-10 22:55:53', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(340, 'MAX_DISPLAY_AUTHOR_NAME_LEN', '20', 26, 12, '2012-03-10 22:55:53', '2012-03-10 22:55:53', NULL, NULL),
(341, 'MAX_DISPLAY_AUTHORS_IN_A_LIST', '1', 26, 13, '2012-03-10 22:55:53', '2012-03-10 22:55:53', NULL, NULL),
(342, 'MAX_AUTHORS_LIST', '1', 26, 14, '2012-03-10 22:55:53', '2012-03-10 22:55:53', NULL, NULL),
(343, 'MAX_DISPLAY_ARTICLES_CONTENT', '150', 26, 15, '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, NULL),
(344, 'DOWN_FOR_MAINTENANCE', 'false', 27, 1, NULL, '2012-03-10 22:55:53', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'), '),
(345, 'EXCLUDE_ADMIN_IP_FOR_MAINTENANCE', 'ip-address', 27, 1, NULL, '0000-00-00 00:00:00', NULL, NULL),
(346, 'AFFILIATE_EMAIL_ADDRESS', 'affiliate@localhost.com', 28, 1, NULL, '2012-03-10 22:55:53', NULL, NULL),
(347, 'AFFILIATE_PERCENT', '15.0000', 28, 2, NULL, '2012-03-10 22:55:53', NULL, NULL),
(348, 'AFFILIATE_THRESHOLD', '30.00', 28, 3, NULL, '2012-03-10 22:55:53', NULL, NULL),
(349, 'AFFILIATE_COOKIE_LIFETIME', '7200', 28, 4, NULL, '2012-03-10 22:55:53', NULL, NULL),
(350, 'AFFILIATE_BILLING_TIME', '30', 28, 5, NULL, '2012-03-10 22:55:53', NULL, NULL),
(351, 'AFFILIATE_PAYMENT_ORDER_MIN_STATUS', '3', 28, 6, NULL, '2012-03-10 22:55:53', NULL, NULL),
(352, 'AFFILIATE_USE_CHECK', 'true', 28, 7, NULL, '2012-03-10 22:55:53', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'), '),
(353, 'AFFILIATE_USE_PAYPAL', 'false', 28, 8, NULL, '2012-03-10 22:55:53', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'), '),
(354, 'AFFILIATE_USE_BANK', 'false', 28, 9, NULL, '2012-03-10 22:55:53', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'), '),
(355, 'AFFILATE_INDIVIDUAL_PERCENTAGE', 'true', 28, 10, NULL, '2012-03-10 22:55:53', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'), '),
(356, 'AFFILATE_USE_TIER', 'false', 28, 11, NULL, '2012-03-10 22:55:53', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'), '),
(357, 'AFFILIATE_TIER_LEVELS', '0', 28, 12, NULL, '2012-03-10 22:55:53', NULL, NULL),
(358, 'AFFILIATE_TIER_PERCENTAGE', '8.00;5.00;1.00', 28, 13, NULL, '2012-03-10 22:55:53', NULL, NULL),
(359, 'SET_BOX_CATEGORIES', 'true', 29, 1, NULL, '2012-03-10 22:55:53', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'), '),
(360, 'SET_BOX_FILTERS', 'true', 29, 2, NULL, '2012-03-10 22:55:53', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'), '),
(361, 'SET_BOX_CONTENT', 'true', 29, 3, NULL, '2012-03-10 22:55:53', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'), '),
(362, 'SET_BOX_INFORMATION', 'true', 29, 4, NULL, '2012-03-10 22:55:53', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'), '),
(363, 'SET_BOX_ADD_QUICKIE', 'true', 29, 5, NULL, '2012-03-10 22:55:53', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'), '),
(364, 'SET_BOX_LAST_VIEWED', 'true', 29, 6, NULL, '2012-03-10 22:55:53', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'), '),
(365, 'SET_BOX_REVIEWS', 'true', 29, 7, NULL, '2012-03-10 22:55:53', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'), '),
(366, 'SET_BOX_SEARCH', 'true', 29, 8, NULL, '2012-03-10 22:55:53', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'), '),
(367, 'SET_BOX_SPECIALS', 'true', 29, 9, NULL, '2012-03-10 22:55:53', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'), '),
(368, 'SET_BOX_FEATURED', 'true', 29, 10, NULL, '2012-03-10 22:55:53', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'), '),
(369, 'SET_BOX_LATESTNEWS', 'true', 29, 11, NULL, '2012-03-10 22:55:53', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'), '),
(370, 'SET_BOX_ARTICLES', 'true', 29, 12, NULL, '2012-03-10 22:55:53', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'), '),
(371, 'SET_BOX_ARTICLESNEW', 'true', 29, 13, NULL, '2012-03-10 22:55:53', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'), '),
(372, 'SET_BOX_AUTHORS', 'true', 29, 14, NULL, '2012-03-10 22:55:53', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'), '),
(373, 'SET_BOX_CART', 'true', 29, 15, NULL, '2012-03-10 22:55:53', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'), '),
(374, 'SET_BOX_LOGIN', 'true', 29, 16, NULL, '2012-03-10 22:55:53', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'), '),
(375, 'SET_BOX_ADMIN', 'true', 29, 17, NULL, '2012-03-10 22:55:53', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'), '),
(376, 'SET_BOX_DOWNLOADS', 'true', 29, 18, NULL, '2012-03-10 22:55:53', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'), '),
(377, 'SET_BOX_AFFILIATE', 'true', 29, 19, NULL, '2012-03-10 22:55:53', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'), '),
(378, 'SET_BOX_WHATSNEW', 'true', 29, 20, NULL, '2012-03-10 22:55:53', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'), '),
(379, 'SET_BOX_NEWSLETTER', 'true', 29, 21, NULL, '2012-03-10 22:55:53', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'), '),
(380, 'SET_BOX_BESTSELLERS', 'true', 29, 22, NULL, '2012-03-10 22:55:53', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'), '),
(381, 'SET_BOX_INFOBOX', 'true', 29, 23, NULL, '2012-03-10 22:55:53', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'), '),
(382, 'SET_BOX_CURRENCIES', 'true', 29, 24, NULL, '2012-03-10 22:55:53', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'), '),
(383, 'SET_BOX_LANGUAGES', 'true', 29, 25, NULL, '2012-03-10 22:55:53', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'), '),
(384, 'SET_BOX_MANUFACTURERS', 'true', 29, 26, NULL, '2012-03-10 22:55:53', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'), '),
(385, 'SET_BOX_MANUFACTURERS_INFO', 'true', 29, 27, NULL, '2012-03-10 22:55:53', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'), '),
(386, 'SET_BOX_FAQ', 'true', 29, 28, NULL, '2012-03-10 22:55:53', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'), '),
(387, 'YANDEX_METRIKA_ID', '', 19, 4, NULL, '0000-00-00 00:00:00', NULL, NULL),
(388, 'YANDEX_METRIKA', 'false', 19, 5, NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(389, 'ORDER_EDITOR_PAYMENT_DROPDOWN', 'true', 72, 1, '2012-03-10 22:58:47', '2012-03-10 22:58:47', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(390, 'ORDER_EDITOR_USE_SPPC', 'false', 72, 3, '2012-03-10 22:58:47', '2012-03-10 22:58:47', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(391, 'ORDER_EDITOR_USE_AJAX', 'true', 72, 4, '2012-03-10 22:58:47', '2012-03-10 22:58:47', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),'),
(392, 'ORDER_EDITOR_CREDIT_CARD', 'Credit Card', 72, 5, '2012-03-10 22:58:47', '2012-03-10 22:58:47', NULL, 'vam_cfg_pull_down_payment_methods('),
(393, 'SPECIFICATIONS_PRODUCTS_HEAD', 'Subhead', 1610, 1, '2009-08-25 10:03:37', '2009-06-18 12:07:30', NULL, 'vam_cfg_select_option(array(\'Subhead\'), '),
(394, 'SPECIFICATIONS_MINIMUM_PRODUCTS', '1', 1610, 5, '2009-06-18 12:07:30', '2009-06-18 12:07:30', NULL, NULL),
(395, 'SPECIFICATIONS_SHOW_NAME_PRODUCTS', 'False', 1610, 10, '2009-06-18 12:07:30', '2009-06-18 12:07:30', NULL, 'vam_cfg_select_option(array(\'True\', \'False\'), '),
(396, 'SPECIFICATIONS_SHOW_TITLE_PRODUCTS', 'True', 1610, 15, '2009-06-18 12:07:30', '2009-06-18 12:07:30', NULL, 'vam_cfg_select_option(array(\'True\', \'False\'), '),
(397, 'SPECIFICATIONS_BOX_FRAME_STYLE', 'Plain', 1610, 20, '2009-08-13 21:28:59', '2009-06-18 12:07:30', NULL, 'vam_cfg_select_option(array(\'Stock\', \'Simple\', \'Plain\',\'Tabs\'), '),
(398, 'SPECIFICATIONS_REVIEWS_TAB', 'True', 1610, 21, '2009-06-18 12:07:30', '2009-09-09 12:07:30', NULL, 'vam_cfg_select_option(array(\'True\', \'False\'), '),
(399, 'SPECIFICATIONS_MAX_REVIEWS', '3', 1610, 22, '2009-09-09 12:07:30', '2009-06-18 12:07:30', NULL, NULL),
(400, 'SPECIFICATIONS_QUESTION_TAB', 'True', 1610, 23, '2009-06-18 12:07:30', '2009-09-09 12:07:30', NULL, 'vam_cfg_select_option(array(\'True\', \'False\'), '),
(401, 'SPECIFICATIONS_COMPARISON_HEAD', 'Subhead', 1610, 24, '2009-08-25 10:03:37', '2009-06-18 12:07:30', NULL, 'vam_cfg_select_option(array(\'Subhead\'), '),
(402, 'SPECIFICATIONS_MINIMUM_COMPARISON', '2', 1610, 25, '2009-07-19 19:52:33', '2009-06-18 12:07:30', NULL, NULL),
(403, 'SPECIFICATIONS_COMP_LINK', 'True', 1610, 30, '0000-00-00 00:00:00', '2009-06-26 12:07:30', NULL, 'vam_cfg_select_option(array(\'True\', \'False\'), '),
(404, 'SPECIFICATIONS_COMP_TABLE_ROW', 'both', 1610, 35, '2009-06-26 18:24:00', '2009-06-26 12:07:30', NULL, 'vam_cfg_select_option(array(\'top\', \'bottom\', \'both\', \'none\'), '),
(405, 'SPECIFICATIONS_BOX_COMPARISON', 'True', 1610, 40, '2009-06-18 12:07:30', '2009-06-18 12:07:30', NULL, 'vam_cfg_select_option(array(\'True\', \'False\'), '),
(406, 'SPECIFICATIONS_BOX_COMP_INDEX', 'False', 1610, 45, '2009-06-18 12:07:30', '2009-06-18 12:07:30', NULL, 'vam_cfg_select_option(array(\'True\', \'False\'), '),
(407, 'SPECIFICATIONS_COMP_SUFFIX', 'True', 1610, 50, '2009-07-18 22:11:04', '2009-06-18 12:07:30', NULL, 'vam_cfg_select_option(array(\'True\', \'False\'), '),
(408, 'SPECIFICATIONS_COMPARISON_STYLE', 'Simple', 1610, 52, '2009-07-18 22:11:04', '2009-06-18 12:07:30', NULL, 'vam_cfg_select_option(array(\'Stock\', \'Simple\', \'Plain\'), '),
(409, 'SPECIFICATIONS_COMBO_MFR', '0', 1610, 55, '2009-06-18 12:07:30', '2009-06-18 12:07:30', NULL, NULL),
(410, 'SPECIFICATIONS_COMBO_WEIGHT', '0', 1610, 60, '2009-06-18 12:07:30', '2009-06-18 12:07:30', NULL, NULL),
(411, 'SPECIFICATIONS_COMBO_PRICE', '0', 1610, 65, '2009-06-18 12:07:30', '2009-06-18 12:07:30', NULL, NULL),
(412, 'SPECIFICATIONS_COMBO_MODEL', '2', 1610, 70, '2009-06-18 15:31:23', '2009-06-18 12:07:30', NULL, NULL),
(413, 'SPECIFICATIONS_COMBO_IMAGE', '1', 1610, 75, '2009-06-18 15:31:10', '2009-06-18 12:07:30', NULL, NULL),
(414, 'SPECIFICATIONS_COMBO_NAME', '0', 1610, 80, '2009-06-18 12:07:30', '2009-06-18 12:07:30', NULL, NULL),
(415, 'SPECIFICATIONS_COMBO_BUY_NOW', '0', 1610, 85, '2009-06-18 12:07:30', '2009-06-18 12:07:30', NULL, NULL),
(416, 'SPECIFICATIONS_FILTERS_HEAD', 'Subhead', 1610, 89, '2009-08-25 10:03:37', '2009-06-18 12:07:30', NULL, 'vam_cfg_select_option(array(\'Subhead\'), '),
(417, 'SPECIFICATIONS_FILTERS_MODULE', 'False', 1610, 90, NULL, '2009-09-09 09:09:09', NULL, 'vam_cfg_select_option(array(\'True\', \'False\'), '),
(418, 'SPECIFICATIONS_FILTERS_BOX', 'True', 1610, 95, NULL, '2009-07-06 00:19:30', NULL, 'vam_cfg_select_option(array(\'True\', \'False\'), '),
(419, 'SPECIFICATIONS_FILTER_MINIMUM', '2', 1610, 100, '2009-06-18 12:07:30', '2009-06-18 12:07:30', NULL, NULL),
(420, 'SPECIFICATIONS_FILTER_SUBCATEGORIES', 'True', 1610, 105, '2009-08-12 15:16:55', '2009-06-18 12:07:30', NULL, 'vam_cfg_select_option(array(\'True\', \'False\'), '),
(421, 'SPECIFICATIONS_FILTER_SHOW_COUNT', 'True', 1610, 110, '2009-09-21 00:00:00', '2009-09-21 00:00:00', NULL, 'vam_cfg_select_option(array(\'True\', \'False\'), '),
(422, 'SPECIFICATIONS_FILTER_NO_RESULT', 'grey', 1610, 115, '2009-08-23 22:00:43', '2009-07-15 19:15:14', NULL, 'vam_cfg_select_option(array(\'none\', \'grey\', \'normal\'), '),
(423, 'SPECIFICATIONS_FILTER_BREADCRUMB', 'True', 1610, 120, '2009-07-15 19:15:07', '2009-07-15 19:15:14', NULL, 'vam_cfg_select_option(array(\'True\', \'False\'), '),
(424, 'SPECIFICATIONS_FILTER_IMAGE_WIDTH', '20', 1610, 125, '2009-07-15 18:46:21', '2009-07-15 18:46:30', NULL, NULL),
(425, 'SPECIFICATIONS_FILTER_IMAGE_HEIGHT', '20', 1610, 130, '2009-07-15 18:46:37', '2009-07-15 18:46:45', NULL, NULL),
(426, 'MODULE_PAYMENT_COD_STATUS', 'True', 6, 1, NULL, '2012-03-12 09:32:58', NULL, 'vam_cfg_select_option(array(\'True\', \'False\'), '),
(427, 'MODULE_PAYMENT_COD_ALLOWED', '', 6, 0, NULL, '2012-03-12 09:32:58', NULL, NULL),
(428, 'MODULE_PAYMENT_COD_ZONE', '0', 6, 2, NULL, '2012-03-12 09:32:58', 'vam_get_zone_class_title', 'vam_cfg_pull_down_zone_classes('),
(429, 'MODULE_PAYMENT_COD_SORT_ORDER', '0', 6, 0, NULL, '2012-03-12 09:32:58', NULL, NULL),
(430, 'MODULE_PAYMENT_COD_ORDER_STATUS_ID', '0', 6, 0, NULL, '2012-03-12 09:32:58', 'vam_get_order_status_name', 'vam_cfg_pull_down_order_statuses('),
(431, 'MODULE_SHIPPING_FLAT_STATUS', 'True', 6, 0, NULL, '2012-03-12 09:33:11', NULL, 'vam_cfg_select_option(array(\'True\', \'False\'), '),
(432, 'MODULE_SHIPPING_FLAT_ALLOWED', '', 6, 0, NULL, '2012-03-12 09:33:11', NULL, NULL),
(433, 'MODULE_SHIPPING_FLAT_COST', '5.00', 6, 0, NULL, '2012-03-12 09:33:11', NULL, NULL),
(434, 'MODULE_SHIPPING_FLAT_TAX_CLASS', '0', 6, 0, NULL, '2012-03-12 09:33:11', 'vam_get_tax_class_title', 'vam_cfg_pull_down_tax_classes('),
(435, 'MODULE_SHIPPING_FLAT_ZONE', '0', 6, 0, NULL, '2012-03-12 09:33:11', 'vam_get_zone_class_title', 'vam_cfg_pull_down_zone_classes('),
(436, 'MODULE_SHIPPING_FLAT_SORT_ORDER', '0', 6, 0, NULL, '2012-03-12 09:33:11', NULL, NULL),
(437, 'MODULE_EXPORT_INSTALLED', '', 6, 0, NULL, '2012-03-12 12:49:39', NULL, NULL);

DROP table IF EXISTS `configuration_group`;
CREATE TABLE `configuration_group` (
  `configuration_group_id` int(11) NOT NULL AUTO_INCREMENT,
  `configuration_group_key` varchar(255) NOT NULL,
  `configuration_group_title` varchar(255) NOT NULL,
  `configuration_group_description` varchar(255) NOT NULL,
  `sort_order` int(5) DEFAULT NULL,
  `visible` int(1) DEFAULT '1',
  PRIMARY KEY (`configuration_group_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1611 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `configuration_group` VALUES
(1, 'CG_MY_SHOP', 'My Store', 'General information about my store', 1, 1),
(2, 'CG_MINIMAL_VALUES', 'Minimum Values', 'The minimum values for functions / data', 2, 1),
(3, 'CG_MAXIMAL_VALUES', 'Maximum Values', 'The maximum values for functions / data', 3, 1),
(4, 'CG_PICTURES_PARAMETERS', 'Images', 'Image parameters', 4, 1),
(5, 'CG_CUSTOMERS', 'Customer Details', 'Customer account configuration', 5, 1),
(6, 'CG_MODULES', 'Module Options', 'Hidden from configuration', 6, 0),
(7, 'CG_SHIPPING', 'Shipping/Packaging', 'Shipping options available at my store', 7, 1),
(8, 'CG_PRODUCTS', 'Product Listing', 'Product Listing    configuration options', 8, 1),
(9, 'CG_WAREHOUSE', 'Stock', 'Stock configuration options', 9, 1),
(10, 'CG_LOGGING', 'Logging', 'Logging configuration options', 10, 1),
(11, 'CG_CACHE', 'Cache', 'Caching configuration options', 11, 1),
(12, 'CG_EMAIL', 'E-Mail Options', 'General setting for E-Mail transport and HTML E-Mails', 12, 1),
(13, 'CG_DOWNLOAD', 'Download', 'Downloadable products options', 13, 1),
(14, 'CG_MY_GZIP', 'GZip Compression', 'GZip compression options', 14, 1),
(15, 'CG_MY_SESSIONS', 'Sessions', 'Session options', 15, 1),
(16, 'CG_META_TAGS', 'Meta-Tags/Search engines', 'Meta-tags/Search engines', 16, 1),
(18, 'CG_VAT_ID', 'Vat ID', 'Vat ID', 18, 1),
(19, 'CG_GOOGLE', 'Google Conversion', 'Google Conversion-Tracking', 19, 1),
(20, 'CG_IMPORT_EXPORT', 'Import/Export', 'Import/Export', 20, 1),
(21, 'CG_AFTER_BUY', 'Afterbuy', 'Afterbuy.de', 21, 1),
(22, 'CG_SEARCH', 'Search Options', 'Additional Options for search function', 22, 1),
(23, 'CG_YANDEX_MARKET', 'Яндекс-Маркет', 'Конфигурирование Яндекс-Маркет', 23, 1),
(24, 'CG_QUICK_PRICE_UPDATES', 'Изменение цен', 'Настройки модуля изменения цен', 24, 1),
(25, 'CG_CIP_MANAGER', 'Установка модулей', 'Настройки модуля', 25, 1),
(27, 'CG_MAINTENANCE', 'Site Maintenance', 'Site Maintenance', 27, 1),
(28, 'CG_AFFILIATE_PROGRAM', 'Партнёрская программа', 'Настройки партнёрской программы', 28, 1),
(29, 'CG_BOXES', 'Боксы', 'Боксы', 29, 1),
(72, 'CG_EDIT_ORDERS', 'Order Editor', 'Order Editor Settings', 1, 1),
(1610, 'CG_PRODUCTS_SPECIFICATIONS', 'Products Specifications', 'Products Specifications configuration options', 1610, 1);

DROP table IF EXISTS `content_manager`;
CREATE TABLE `content_manager` (
  `content_id` int(11) NOT NULL AUTO_INCREMENT,
  `categories_id` int(11) NOT NULL DEFAULT '0',
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `group_ids` text,
  `languages_id` int(11) NOT NULL DEFAULT '0',
  `content_title` text,
  `content_heading` text,
  `content_text` text,
  `content_url` text,
  `sort_order` int(4) NOT NULL DEFAULT '0',
  `file_flag` int(1) NOT NULL DEFAULT '0',
  `content_file` varchar(255) NOT NULL DEFAULT '',
  `content_status` int(1) NOT NULL DEFAULT '0',
  `content_group` int(11) NOT NULL,
  `content_delete` int(1) NOT NULL DEFAULT '1',
  `content_meta_title` text,
  `content_meta_description` text,
  `content_meta_keywords` text,
  `content_page_url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`content_id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `content_manager` VALUES
(1, 0, 0, '', 1, 'Доставка', 'Доставка', 'Условия доставки.', '', 0, 1, '', 1, 1, 0, '', '', '', ''),
(2, 0, 0, '', 1, 'Безопасность магазина', 'Безопасность магазина', 'Ваш текст.', '', 0, 1, '', 1, 2, 0, '', '', '', ''),
(3, 0, 0, '', 1, 'Условия использования', 'Условия использования', 'Ваш текст', '', 0, 1, '', 1, 3, 0, '', '', '', ''),
(4, 0, 0, '', 1, 'Информация о магазине', 'Информация о магазине', 'Текст страницы информация о магазине.', '', 0, 1, '', 1, 4, 0, '', '', '', ''),
(5, 0, 0, '', 1, 'Главная страница', 'Добро пожаловать', 'Вы установили интернет-магазин VaM Shop<br /><br />Данный текст можно изменить в Админке - Разное - Инструменты - Информационные страницы<br /><br />', '', 0, 1, '', 0, 5, 0, '', '', '', ''),
(6, 0, 0, '', 1, 'Пример страницы', 'Пример страницы', 'Текст страницы', '', 0, 1, '', 0, 6, 1, '', '', '', ''),
(7, 0, 0, '', 1, 'Свяжитесь с нами', 'Свяжитесь с нами', 'Форма обратной связи', '', 0, 1, '', 1, 7, 0, '', '', '', ''),
(8, 0, 0, '', 1, 'Карта сайта', 'Карта сайта', '', '', 0, 0, 'sitemap.php', 1, 8, 0, '', '', '', ''),
(9, 0, 0, '', 1, 'Правила партнёрской программы', 'Правила и условия партнёрской программы', '<b>1. Участники партнёрской программы.</b>\r\n<br />\r\nУчастниками партнёрской программы могут быть физические лица. Под физическими лицами понимаются граждане РФ, иностранные граждане, лица без гражданства, а так же предприниматели без образования юридического лица.\r\n<br />\r\n<br />\r\n<b>2. Оплата услуг партнёра.</b>\r\n<br />\r\nМы будем выплачивать Вам комиссию, установленную в размере <b>15%</b> от стоимости <b>оплаченного</b> заказа.\r\n<br />\r\n<br />\r\n<b>3. Способы оплаты.</b>\r\n<br />\r\nВсе партнёрские выплаты производятся в доларах США через электронную платёжную систему <b>WebMoney</b>, Вы можете ознакомиться с данной системой по адресу <b><a href=\"http://www.webmoney.ru\" target=\"_blank\">http://www.webmoney.ru</a></b>\r\n<br />\r\n<br />\r\n<b>4. Минимальная сумма к оплате.</b>\r\n<br />\r\nМинимальная сумма к оплате установлена в размере <b>30$</b>. В случае, если заработанная Вами партнёрская комиссия не превышает <b>30$</b>, деньги остаются на Вашем аккаунте до тех пор, пока сумма комиссии не достигнет по крайней мере <b>30$</b>. Оплата партнёрских комиссий производится каждые <b>2 недели</b>.\r\n<br />\r\n<br />\r\n<b>5. Партнёрская комиссия.</b>\r\n<br />\r\nПартнёрская комиссия будет выплачена только если заказ оформлен и оплачен покупателем, которого привели Вы.\r\n<br /><br />\r\nПартнёрская комиссия начисляется только за <b>оплаченные заказы.</b>\r\n<br /><br />\r\nПартнёрская комиссия не будет выплачена, если:\r\n<br />\r\n&nbsp;<b>а)</b> Посетитель, пришедший с Вашего сайта не будет учтён нашей системой по техническим причинам (отключены \"Cookies\" и т.д.).\r\n<br />\r\n&nbsp;<b>б)</b> Посетитель перешёл в магазин по партнёрской ссылке другого партнёра.\r\n<br />\r\n&nbsp;<b>в)</b> Посетиитель, оформивший заказ через Вашу партнёрскую ссылку не оплатил его.\r\n<br />\r\n<br />\r\n<b>6. Условия.</b>\r\n<br />\r\nПокупатели, совершающие заказы через партнёров считаются нашими покупателями и подчиняются правилам нашего магазина. Правила работы магазина могут быть изменены нами без предварительного уведомления.\r\n<br />\r\n<br />\r\n<b>7. Разногласия</b>\r\n<br />\r\nВ случае возникновения разногласий, стороны будут стремиться урегулировать возникшие разногласия путем переговоров. В случае, если стороны не придут к соглашению, то спор подлежит рассмотрению в суде РФ.\r\n<br />\r\n<br />', '', 0, 2, '', 1, 9, 0, '', '', '', ''),
(10, 0, 0, '', 1, 'Информация', 'Информация о партнёрской программе', '<b>1. Участники партнёрской программы.</b>\r\n<br />\r\nУчастниками партнёрской программы могут быть физические лица. Под физическими лицами понимаются граждане РФ, иностранные граждане, лица без гражданства, а так же предприниматели без образования юридического лица.\r\n<br />\r\n<br />\r\n<b>2. Оплата услуг партнёра.</b>\r\n<br />\r\nМы будем выплачивать Вам комиссию, установленную в размере <b>15%</b> от стоимости <b>оплаченного</b> заказа.\r\n<br />\r\n<br />\r\n<b>3. Способы оплаты.</b>\r\n<br />\r\nВсе партнёрские выплаты производятся в доларах США через электронную платёжную систему <b>WebMoney</b>, Вы можете ознакомиться с данной системой по адресу <b><a href=\"http://www.webmoney.ru\" target=\"_blank\">http://www.webmoney.ru</a></b>\r\n<br />\r\n<br />\r\n<b>4. Минимальная сумма к оплате.</b>\r\n<br />\r\nМинимальная сумма к оплате установлена в размере <b>30$</b>. В случае, если заработанная Вами партнёрская комиссия не превышает <b>30$</b>, деньги остаются на Вашем аккаунте до тех пор, пока сумма комиссии не достигнет по крайней мере <b>30$</b>. Оплата партнёрских комиссий производится каждые <b>2 недели</b>.\r\n<br />\r\n<br />\r\n<b>5. Партнёрская комиссия.</b>\r\n<br />\r\nПартнёрская комиссия будет выплачена только если заказ оформлен и оплачен покупателем, которого привели Вы.\r\n<br /><br />\r\nПартнёрская комиссия начисляется только за <b>оплаченные заказы.</b>\r\n<br /><br />\r\nПартнёрская комиссия не будет выплачена, если:\r\n<br />\r\n&nbsp;<b>а)</b> Посетитель, пришедший с Вашего сайта не будет учтён нашей системой по техническим причинам (отключены \"Cookies\" и т.д.).\r\n<br />\r\n&nbsp;<b>б)</b> Посетитель перешёл в магазин по партнёрской ссылке другого партнёра.\r\n<br />\r\n&nbsp;<b>в)</b> Посетиитель, оформивший заказ через Вашу партнёрскую ссылку не оплатил его.\r\n<br />\r\n<br />\r\n<b>6. Условия.</b>\r\n<br />\r\nПокупатели, совершающие заказы через партнёров считаются нашими покупателями и подчиняются правилам нашего магазина. Правила работы магазина могут быть изменены нами без предварительного уведомления.\r\n<br />\r\n<br />\r\n<b>7. Разногласия</b>\r\n<br />\r\nВ случае возникновения разногласий, стороны будут стремиться урегулировать возникшие разногласия путем переговоров. В случае, если стороны не придут к соглашению, то спор подлежит рассмотрению в суде РФ.\r\n<br />\r\n<br />', '', 0, 2, '', 1, 10, 0, '', '', '', ''),
(11, 0, 0, '', 1, 'Вопросы и ответы', 'Вопросы и ответы', 'Список частозадаваемых вопросов по партнёрской программе.<br>\r\n<br>\r\n<ul>\r\n<li>Как мне получить заработанные у вас деньги?</a>\r\n<li>Как и в каком месте лучше всего рамещать партнёрские ссылки?</a>\r\n<li>Могу ли я изменять HTML-код, который мне нужно ставить на сайт?</a>\r\n<li>Что будет если покупатель, который пришёл с моего сайте не оплатит заказ?</a>\r\n</ul>\r\n<hr width=\"90%\">\r\n<BR>\r\n<FONT COLOR=\"#000000\" size=\"4\"><B><U>FAQ</U></B></FONT>\r\n<p style=\"line-height: 100%; word-spacing: 0; text-indent: 0; margin: 0\"><font color=\"maroon\">Как мне получить заработанные у вас деньги?</font><br>\r\nЧтобы получить выплату партнёрской комиссии, на Вашем аккаунте должно быть как минимум <b>30$</b>. В случае, если заработанная Вами партнёрская комиссия не превышает <b>30$</b>, деньги остаются на Вашем аккаунте до тех пор, пока сумма комиссии не достигнет по крайней мере <b>30$</b>. Оплата партнёрских комиссий производится каждые <b>2 недели</b>. Выплаты производятся на Ваш кошелёк в системе WebMoney.</p>\r\n<p align=\"right\" style=\"line-height: 100%; word-spacing: 0; text-indent: 0; margin: 0\"></p>\r\n<p align=\"right\" style=\"line-height: 100%; word-spacing: 0; text-indent: 0; margin: 0\">&nbsp;</p>\r\n<p style=\"line-height: 100%; word-spacing: 0; text-indent: 0; margin: 0\"><font color=\"maroon\">Как и в каком месте лучше всего рамещать партнёрские ссылки?</font><a name=\"2\"></a><br>\r\nЛучше всего размещать партнёрские ссылки сразу на всех страницах Вашего сайта, в ниболее заметных местах, используйте различные партнёрские ссылки: баннеры, ссылки на конкретные товары и т.д. Размещать рекламу в верхней части страниц всегда эффективнее, чем в нижней. Вы можете размещать партнёрские ссылки не только у себя на сайте, а так же в баннеробменных сетях, почтовых рассылках и т.д.</p>\r\n<p align=\"right\" style=\"line-height: 100%; word-spacing: 0; text-indent: 0; margin: 0\"></p>\r\n<p align=\"right\" style=\"line-height: 100%; word-spacing: 0; text-indent: 0; margin: 0\">&nbsp;</p>\r\n<p style=\"line-height: 100%; word-spacing: 0; text-indent: 0; margin: 0\"><font color=\"maroon\">Могу ли я изменять HTML-код, который мне нужно ставить на сайт?</font><a name=\"3\"></a><br>\r\nДа, Вы можете изменять HTML-код по своему усмотрению, можете создавать свои ссылки самостоятельно на разные страницы нашего магазина, главное чтобы в адресе ссылки был указан ваш Партнёрский ID. Например: <b>http://адресмагазина/?ref=yourid</b>, где <b>yourid</b> это Ваш партнёрский номер.</p>\r\n<p align=\"right\" style=\"line-height: 100%; word-spacing: 0; text-indent: 0; margin: 0\"></p>\r\n<p align=\"right\" style=\"line-height: 100%; word-spacing: 0; text-indent: 0; margin: 0\">&nbsp;</p>\r\n<p style=\"line-height: 100%; word-spacing: 0; text-indent: 0; margin: 0\"><font color=\"maroon\">Что будет если покупатель, который пришёл с моего сайта не оплатит заказ?</font><a name=\"4\"></a><br>\r\nВы не получите свою комиссию, т.к. комиссия начисляется только за <b>оплаченные</b> заказы.</p>\r\n<p align=\"right\" style=\"line-height: 100%; word-spacing: 0; text-indent: 0; margin: 0\"></p>\r\n<p align=\"right\" style=\"line-height: 100%; word-spacing: 0; text-indent: 0; margin: 0\">&nbsp;</p>', '', 0, 2, '', 1, 11, 0, '', '', '', '');

DROP table IF EXISTS `counter`;
CREATE TABLE `counter` (
  `startdate` char(8) DEFAULT NULL,
  `counter` int(12) DEFAULT NULL
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `counter_history`;
CREATE TABLE `counter_history` (
  `month` char(8) DEFAULT NULL,
  `counter` int(12) DEFAULT NULL
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `countries`;
CREATE TABLE `countries` (
  `countries_id` int(11) NOT NULL AUTO_INCREMENT,
  `countries_name` varchar(255) NOT NULL,
  `countries_iso_code_2` char(2) NOT NULL,
  `countries_iso_code_3` char(3) NOT NULL,
  `address_format_id` int(11) NOT NULL,
  `status` int(1) DEFAULT '1',
  PRIMARY KEY (`countries_id`),
  KEY `IDX_COUNTRIES_NAME` (`countries_name`)
) ENGINE=MyISAM AUTO_INCREMENT=240 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `countries` VALUES
(1, 'Afghanistan', 'AF', 'AFG', 1, 0),
(2, 'Albania', 'AL', 'ALB', 1, 0),
(3, 'Algeria', 'DZ', 'DZA', 1, 0),
(4, 'American Samoa', 'AS', 'ASM', 1, 0),
(5, 'Andorra', 'AD', 'AND', 1, 0),
(6, 'Angola', 'AO', 'AGO', 1, 0),
(7, 'Anguilla', 'AI', 'AIA', 1, 0),
(8, 'Antarctica', 'AQ', 'ATA', 1, 0),
(9, 'Antigua and Barbuda', 'AG', 'ATG', 1, 0),
(10, 'Argentina', 'AR', 'ARG', 1, 0),
(11, 'Армения', 'AM', 'ARM', 1, 1),
(12, 'Aruba', 'AW', 'ABW', 1, 0),
(13, 'Australia', 'AU', 'AUS', 1, 0),
(14, 'Austria', 'AT', 'AUT', 5, 0),
(15, 'Азербайджан', 'AZ', 'AZE', 1, 1),
(16, 'Bahamas', 'BS', 'BHS', 1, 0),
(17, 'Bahrain', 'BH', 'BHR', 1, 0),
(18, 'Bangladesh', 'BD', 'BGD', 1, 0),
(19, 'Barbados', 'BB', 'BRB', 1, 0),
(20, 'Белоруссия', 'BY', 'BLR', 1, 1),
(21, 'Belgium', 'BE', 'BEL', 1, 0),
(22, 'Belize', 'BZ', 'BLZ', 1, 0),
(23, 'Benin', 'BJ', 'BEN', 1, 0),
(24, 'Bermuda', 'BM', 'BMU', 1, 0),
(25, 'Bhutan', 'BT', 'BTN', 1, 0),
(26, 'Bolivia', 'BO', 'BOL', 1, 0),
(27, 'Bosnia and Herzegowina', 'BA', 'BIH', 1, 0),
(28, 'Botswana', 'BW', 'BWA', 1, 0),
(29, 'Bouvet Island', 'BV', 'BVT', 1, 0),
(30, 'Brazil', 'BR', 'BRA', 1, 0),
(31, 'British Indian Ocean Territory', 'IO', 'IOT', 1, 0),
(32, 'Brunei Darussalam', 'BN', 'BRN', 1, 0),
(33, 'Bulgaria', 'BG', 'BGR', 1, 0),
(34, 'Burkina Faso', 'BF', 'BFA', 1, 0),
(35, 'Burundi', 'BI', 'BDI', 1, 0),
(36, 'Cambodia', 'KH', 'KHM', 1, 0),
(37, 'Cameroon', 'CM', 'CMR', 1, 0),
(38, 'Canada', 'CA', 'CAN', 1, 0),
(39, 'Cape Verde', 'CV', 'CPV', 1, 0),
(40, 'Cayman Islands', 'KY', 'CYM', 1, 0),
(41, 'Central African Republic', 'CF', 'CAF', 1, 0),
(42, 'Chad', 'TD', 'TCD', 1, 0),
(43, 'Chile', 'CL', 'CHL', 1, 0),
(44, 'China', 'CN', 'CHN', 1, 0),
(45, 'Christmas Island', 'CX', 'CXR', 1, 0),
(46, 'Cocos (Keeling) Islands', 'CC', 'CCK', 1, 0),
(47, 'Colombia', 'CO', 'COL', 1, 0),
(48, 'Comoros', 'KM', 'COM', 1, 0),
(49, 'Congo', 'CG', 'COG', 1, 0),
(50, 'Cook Islands', 'CK', 'COK', 1, 0),
(51, 'Costa Rica', 'CR', 'CRI', 1, 0),
(52, 'Cote D\'Ivoire', 'CI', 'CIV', 1, 0),
(53, 'Croatia', 'HR', 'HRV', 1, 0),
(54, 'Cuba', 'CU', 'CUB', 1, 0),
(55, 'Cyprus', 'CY', 'CYP', 1, 0),
(56, 'Czech Republic', 'CZ', 'CZE', 1, 0),
(57, 'Denmark', 'DK', 'DNK', 1, 0),
(58, 'Djibouti', 'DJ', 'DJI', 1, 0),
(59, 'Dominica', 'DM', 'DMA', 1, 0),
(60, 'Dominican Republic', 'DO', 'DOM', 1, 0),
(61, 'East Timor', 'TP', 'TMP', 1, 0),
(62, 'Ecuador', 'EC', 'ECU', 1, 0),
(63, 'Egypt', 'EG', 'EGY', 1, 0),
(64, 'El Salvador', 'SV', 'SLV', 1, 0),
(65, 'Equatorial Guinea', 'GQ', 'GNQ', 1, 0),
(66, 'Eritrea', 'ER', 'ERI', 1, 0),
(67, 'Эстония', 'EE', 'EST', 1, 1),
(68, 'Ethiopia', 'ET', 'ETH', 1, 0),
(69, 'Falkland Islands (Malvinas)', 'FK', 'FLK', 1, 0),
(70, 'Faroe Islands', 'FO', 'FRO', 1, 0),
(71, 'Fiji', 'FJ', 'FJI', 1, 0),
(72, 'Finland', 'FI', 'FIN', 1, 0),
(73, 'France', 'FR', 'FRA', 1, 0),
(74, 'France, Metropolitan', 'FX', 'FXX', 1, 0),
(75, 'French Guiana', 'GF', 'GUF', 1, 0),
(76, 'French Polynesia', 'PF', 'PYF', 1, 0),
(77, 'French Southern Territories', 'TF', 'ATF', 1, 0),
(78, 'Gabon', 'GA', 'GAB', 1, 0),
(79, 'Gambia', 'GM', 'GMB', 1, 0),
(80, 'Грузия', 'GE', 'GEO', 1, 1),
(81, 'Germany', 'DE', 'DEU', 5, 0),
(82, 'Ghana', 'GH', 'GHA', 1, 0),
(83, 'Gibraltar', 'GI', 'GIB', 1, 0),
(84, 'Greece', 'GR', 'GRC', 1, 0),
(85, 'Greenland', 'GL', 'GRL', 1, 0),
(86, 'Grenada', 'GD', 'GRD', 1, 0),
(87, 'Guadeloupe', 'GP', 'GLP', 1, 0),
(88, 'Guam', 'GU', 'GUM', 1, 0),
(89, 'Guatemala', 'GT', 'GTM', 1, 0),
(90, 'Guinea', 'GN', 'GIN', 1, 0),
(91, 'Guinea-bissau', 'GW', 'GNB', 1, 0),
(92, 'Guyana', 'GY', 'GUY', 1, 0),
(93, 'Haiti', 'HT', 'HTI', 1, 0),
(94, 'Heard and Mc Donald Islands', 'HM', 'HMD', 1, 0),
(95, 'Honduras', 'HN', 'HND', 1, 0),
(96, 'Hong Kong', 'HK', 'HKG', 1, 0),
(97, 'Hungary', 'HU', 'HUN', 1, 0),
(98, 'Iceland', 'IS', 'ISL', 1, 0),
(99, 'India', 'IN', 'IND', 1, 0),
(100, 'Indonesia', 'ID', 'IDN', 1, 0),
(101, 'Iran (Islamic Republic of)', 'IR', 'IRN', 1, 0),
(102, 'Iraq', 'IQ', 'IRQ', 1, 0),
(103, 'Ireland', 'IE', 'IRL', 1, 0),
(104, 'Israel', 'IL', 'ISR', 1, 0),
(105, 'Italy', 'IT', 'ITA', 1, 0),
(106, 'Jamaica', 'JM', 'JAM', 1, 0),
(107, 'Japan', 'JP', 'JPN', 1, 0),
(108, 'Jordan', 'JO', 'JOR', 1, 0),
(109, 'Казахстан', 'KZ', 'KAZ', 1, 1),
(110, 'Kenya', 'KE', 'KEN', 1, 0),
(111, 'Kiribati', 'KI', 'KIR', 1, 0),
(112, 'Korea, Democratic People\'s Republic of', 'KP', 'PRK', 1, 0),
(113, 'Korea, Republic of', 'KR', 'KOR', 1, 0),
(114, 'Kuwait', 'KW', 'KWT', 1, 0),
(115, 'Кыргызстан', 'KG', 'KGZ', 1, 1),
(116, 'Lao People\'s Democratic Republic', 'LA', 'LAO', 1, 0),
(117, 'Латвия', 'LV', 'LVA', 1, 1),
(118, 'Lebanon', 'LB', 'LBN', 1, 0),
(119, 'Lesotho', 'LS', 'LSO', 1, 0),
(120, 'Liberia', 'LR', 'LBR', 1, 0),
(121, 'Libyan Arab Jamahiriya', 'LY', 'LBY', 1, 0),
(122, 'Liechtenstein', 'LI', 'LIE', 1, 0),
(123, 'Литва', 'LT', 'LTU', 1, 1),
(124, 'Luxembourg', 'LU', 'LUX', 1, 0),
(125, 'Macau', 'MO', 'MAC', 1, 0),
(126, 'Macedonia, The Former Yugoslav Republic of', 'MK', 'MKD', 1, 0),
(127, 'Madagascar', 'MG', 'MDG', 1, 0),
(128, 'Malawi', 'MW', 'MWI', 1, 0),
(129, 'Malaysia', 'MY', 'MYS', 1, 0),
(130, 'Maldives', 'MV', 'MDV', 1, 0),
(131, 'Mali', 'ML', 'MLI', 1, 0),
(132, 'Malta', 'MT', 'MLT', 1, 0),
(133, 'Marshall Islands', 'MH', 'MHL', 1, 0),
(134, 'Martinique', 'MQ', 'MTQ', 1, 0),
(135, 'Mauritania', 'MR', 'MRT', 1, 0),
(136, 'Mauritius', 'MU', 'MUS', 1, 0),
(137, 'Mayotte', 'YT', 'MYT', 1, 0),
(138, 'Mexico', 'MX', 'MEX', 1, 0),
(139, 'Micronesia, Federated States of', 'FM', 'FSM', 1, 0),
(140, 'Молдавия', 'MD', 'MDA', 1, 1),
(141, 'Monaco', 'MC', 'MCO', 1, 0),
(142, 'Mongolia', 'MN', 'MNG', 1, 0),
(143, 'Montserrat', 'MS', 'MSR', 1, 0),
(144, 'Morocco', 'MA', 'MAR', 1, 0),
(145, 'Mozambique', 'MZ', 'MOZ', 1, 0),
(146, 'Myanmar', 'MM', 'MMR', 1, 0),
(147, 'Namibia', 'NA', 'NAM', 1, 0),
(148, 'Nauru', 'NR', 'NRU', 1, 0),
(149, 'Nepal', 'NP', 'NPL', 1, 0),
(150, 'Netherlands', 'NL', 'NLD', 1, 0),
(151, 'Netherlands Antilles', 'AN', 'ANT', 1, 0),
(152, 'New Caledonia', 'NC', 'NCL', 1, 0),
(153, 'New Zealand', 'NZ', 'NZL', 1, 0),
(154, 'Nicaragua', 'NI', 'NIC', 1, 0),
(155, 'Niger', 'NE', 'NER', 1, 0),
(156, 'Nigeria', 'NG', 'NGA', 1, 0),
(157, 'Niue', 'NU', 'NIU', 1, 0),
(158, 'Norfolk Island', 'NF', 'NFK', 1, 0),
(159, 'Northern Mariana Islands', 'MP', 'MNP', 1, 0),
(160, 'Norway', 'NO', 'NOR', 1, 0),
(161, 'Oman', 'OM', 'OMN', 1, 0),
(162, 'Pakistan', 'PK', 'PAK', 1, 0),
(163, 'Palau', 'PW', 'PLW', 1, 0),
(164, 'Panama', 'PA', 'PAN', 1, 0),
(165, 'Papua New Guinea', 'PG', 'PNG', 1, 0),
(166, 'Paraguay', 'PY', 'PRY', 1, 0),
(167, 'Peru', 'PE', 'PER', 1, 0),
(168, 'Philippines', 'PH', 'PHL', 1, 0),
(169, 'Pitcairn', 'PN', 'PCN', 1, 0),
(170, 'Poland', 'PL', 'POL', 1, 0),
(171, 'Portugal', 'PT', 'PRT', 1, 0),
(172, 'Puerto Rico', 'PR', 'PRI', 1, 0),
(173, 'Qatar', 'QA', 'QAT', 1, 0),
(174, 'Reunion', 'RE', 'REU', 1, 0),
(175, 'Romania', 'RO', 'ROM', 1, 0),
(176, 'Российская Федерация', 'RU', 'RUS', 1, 1),
(177, 'Rwanda', 'RW', 'RWA', 1, 0),
(178, 'Saint Kitts and Nevis', 'KN', 'KNA', 1, 0),
(179, 'Saint Lucia', 'LC', 'LCA', 1, 0),
(180, 'Saint Vincent and the Grenadines', 'VC', 'VCT', 1, 0),
(181, 'Samoa', 'WS', 'WSM', 1, 0),
(182, 'San Marino', 'SM', 'SMR', 1, 0),
(183, 'Sao Tome and Principe', 'ST', 'STP', 1, 0),
(184, 'Saudi Arabia', 'SA', 'SAU', 1, 0),
(185, 'Senegal', 'SN', 'SEN', 1, 0),
(186, 'Seychelles', 'SC', 'SYC', 1, 0),
(187, 'Sierra Leone', 'SL', 'SLE', 1, 0),
(188, 'Singapore', 'SG', 'SGP', 4, 0),
(189, 'Slovakia (Slovak Republic)', 'SK', 'SVK', 1, 0),
(190, 'Slovenia', 'SI', 'SVN', 1, 0),
(191, 'Solomon Islands', 'SB', 'SLB', 1, 0),
(192, 'Somalia', 'SO', 'SOM', 1, 0),
(193, 'South Africa', 'ZA', 'ZAF', 1, 0),
(194, 'South Georgia and the South Sandwich Islands', 'GS', 'SGS', 1, 0),
(195, 'Spain', 'ES', 'ESP', 3, 0),
(196, 'Sri Lanka', 'LK', 'LKA', 1, 0),
(197, 'St. Helena', 'SH', 'SHN', 1, 0),
(198, 'St. Pierre and Miquelon', 'PM', 'SPM', 1, 0),
(199, 'Sudan', 'SD', 'SDN', 1, 0),
(200, 'Suriname', 'SR', 'SUR', 1, 0),
(201, 'Svalbard and Jan Mayen Islands', 'SJ', 'SJM', 1, 0),
(202, 'Swaziland', 'SZ', 'SWZ', 1, 0),
(203, 'Sweden', 'SE', 'SWE', 1, 0),
(204, 'Switzerland', 'CH', 'CHE', 1, 0),
(205, 'Syrian Arab Republic', 'SY', 'SYR', 1, 0),
(206, 'Taiwan', 'TW', 'TWN', 1, 0),
(207, 'Таджикистан', 'TJ', 'TJK', 1, 1),
(208, 'Tanzania, United Republic of', 'TZ', 'TZA', 1, 0),
(209, 'Thailand', 'TH', 'THA', 1, 0),
(210, 'Togo', 'TG', 'TGO', 1, 0),
(211, 'Tokelau', 'TK', 'TKL', 1, 0),
(212, 'Tonga', 'TO', 'TON', 1, 0),
(213, 'Trinidad and Tobago', 'TT', 'TTO', 1, 0),
(214, 'Tunisia', 'TN', 'TUN', 1, 0),
(215, 'Turkey', 'TR', 'TUR', 1, 0),
(216, 'Туркменистан', 'TM', 'TKM', 1, 1),
(217, 'Turks and Caicos Islands', 'TC', 'TCA', 1, 0),
(218, 'Tuvalu', 'TV', 'TUV', 1, 0),
(219, 'Uganda', 'UG', 'UGA', 1, 0),
(220, 'Украина', 'UA', 'UKR', 1, 1),
(221, 'United Arab Emirates', 'AE', 'ARE', 1, 0),
(222, 'United Kingdom', 'GB', 'GBR', 1, 0),
(223, 'United States', 'US', 'USA', 2, 0),
(224, 'United States Minor Outlying Islands', 'UM', 'UMI', 1, 0),
(225, 'Uruguay', 'UY', 'URY', 1, 0),
(226, 'Узбекистан', 'UZ', 'UZB', 1, 1),
(227, 'Vanuatu', 'VU', 'VUT', 1, 0),
(228, 'Vatican City State (Holy See)', 'VA', 'VAT', 1, 0),
(229, 'Venezuela', 'VE', 'VEN', 1, 0),
(230, 'Viet Nam', 'VN', 'VNM', 1, 0),
(231, 'Virgin Islands (British)', 'VG', 'VGB', 1, 0),
(232, 'Virgin Islands (U.S.)', 'VI', 'VIR', 1, 0),
(233, 'Wallis and Futuna Islands', 'WF', 'WLF', 1, 0),
(234, 'Western Sahara', 'EH', 'ESH', 1, 0),
(235, 'Yemen', 'YE', 'YEM', 1, 0),
(236, 'Yugoslavia', 'YU', 'YUG', 1, 0),
(237, 'Zaire', 'ZR', 'ZAR', 1, 0),
(238, 'Zambia', 'ZM', 'ZMB', 1, 0),
(239, 'Zimbabwe', 'ZW', 'ZWE', 1, 0);

DROP table IF EXISTS `coupon_email_track`;
CREATE TABLE `coupon_email_track` (
  `unique_id` int(11) NOT NULL AUTO_INCREMENT,
  `coupon_id` int(11) NOT NULL DEFAULT '0',
  `customer_id_sent` int(11) NOT NULL DEFAULT '0',
  `sent_firstname` varchar(255) DEFAULT NULL,
  `sent_lastname` varchar(255) DEFAULT NULL,
  `emailed_to` varchar(255) DEFAULT NULL,
  `date_sent` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`unique_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `coupon_gv_customer`;
CREATE TABLE `coupon_gv_customer` (
  `customer_id` int(5) NOT NULL DEFAULT '0',
  `amount` decimal(8,4) NOT NULL DEFAULT '0.0000',
  PRIMARY KEY (`customer_id`),
  KEY `customer_id` (`customer_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `coupon_gv_queue`;
CREATE TABLE `coupon_gv_queue` (
  `unique_id` int(5) NOT NULL AUTO_INCREMENT,
  `customer_id` int(5) NOT NULL DEFAULT '0',
  `order_id` int(5) NOT NULL DEFAULT '0',
  `amount` decimal(8,4) NOT NULL DEFAULT '0.0000',
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ipaddr` varchar(255) NOT NULL DEFAULT '',
  `release_flag` char(1) NOT NULL DEFAULT 'N',
  PRIMARY KEY (`unique_id`),
  KEY `uid` (`unique_id`,`customer_id`,`order_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `coupon_redeem_track`;
CREATE TABLE `coupon_redeem_track` (
  `unique_id` int(11) NOT NULL AUTO_INCREMENT,
  `coupon_id` int(11) NOT NULL DEFAULT '0',
  `customer_id` int(11) NOT NULL DEFAULT '0',
  `redeem_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `redeem_ip` varchar(255) NOT NULL DEFAULT '',
  `order_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`unique_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `coupons`;
CREATE TABLE `coupons` (
  `coupon_id` int(11) NOT NULL AUTO_INCREMENT,
  `coupon_type` char(1) NOT NULL DEFAULT 'F',
  `coupon_code` varchar(255) NOT NULL DEFAULT '',
  `coupon_amount` decimal(8,4) NOT NULL DEFAULT '0.0000',
  `coupon_minimum_order` decimal(8,4) NOT NULL DEFAULT '0.0000',
  `coupon_start_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `coupon_expire_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `uses_per_coupon` int(5) NOT NULL DEFAULT '1',
  `uses_per_user` int(5) NOT NULL DEFAULT '0',
  `restrict_to_products` varchar(255) DEFAULT NULL,
  `restrict_to_categories` varchar(255) DEFAULT NULL,
  `restrict_to_customers` text,
  `coupon_active` char(1) NOT NULL DEFAULT 'Y',
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`coupon_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `coupons_description`;
CREATE TABLE `coupons_description` (
  `coupon_id` int(11) NOT NULL DEFAULT '0',
  `language_id` int(11) NOT NULL DEFAULT '0',
  `coupon_name` varchar(255) NOT NULL DEFAULT '',
  `coupon_description` text,
  KEY `coupon_id` (`coupon_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `currencies`;
CREATE TABLE `currencies` (
  `currencies_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `code` char(3) NOT NULL,
  `symbol_left` varchar(12) DEFAULT NULL,
  `symbol_right` varchar(12) DEFAULT NULL,
  `decimal_point` char(1) DEFAULT NULL,
  `thousands_point` char(1) DEFAULT NULL,
  `decimal_places` char(1) DEFAULT NULL,
  `value` float(13,8) DEFAULT NULL,
  `last_updated` datetime DEFAULT NULL,
  PRIMARY KEY (`currencies_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `currencies` VALUES
(1, 'Рубль', 'RUR', '', 'руб.', ',', '.', '2', '1.00000000', '2012-03-10 22:55:53');

DROP table IF EXISTS `customers`;
CREATE TABLE `customers` (
  `customers_id` int(11) NOT NULL AUTO_INCREMENT,
  `customers_cid` varchar(255) DEFAULT NULL,
  `customers_vat_id` varchar(20) DEFAULT NULL,
  `customers_vat_id_status` int(2) NOT NULL DEFAULT '0',
  `customers_warning` varchar(255) DEFAULT NULL,
  `customers_status` int(5) NOT NULL DEFAULT '1',
  `customers_gender` char(1) NOT NULL,
  `customers_firstname` varchar(255) NOT NULL,
  `customers_secondname` varchar(255) NOT NULL,
  `customers_lastname` varchar(255) NOT NULL,
  `customers_dob` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `customers_email_address` varchar(96) NOT NULL,
  `customers_default_address_id` int(11) NOT NULL,
  `customers_telephone` varchar(255) NOT NULL,
  `customers_fax` varchar(255) DEFAULT NULL,
  `customers_password` varchar(40) NOT NULL,
  `customers_newsletter` char(1) DEFAULT NULL,
  `customers_newsletter_mode` char(1) NOT NULL DEFAULT '0',
  `member_flag` char(1) NOT NULL DEFAULT '0',
  `delete_user` char(1) NOT NULL DEFAULT '1',
  `account_type` int(1) NOT NULL DEFAULT '0',
  `password_request_key` varchar(255) NOT NULL,
  `payment_unallowed` varchar(255) NOT NULL,
  `shipping_unallowed` varchar(255) NOT NULL,
  `refferers_id` int(5) NOT NULL DEFAULT '0',
  `customers_date_added` datetime DEFAULT '0000-00-00 00:00:00',
  `customers_last_modified` datetime DEFAULT '0000-00-00 00:00:00',
  `orig_reference` text,
  `login_reference` text,
  `login_tries` char(2) NOT NULL DEFAULT '0',
  `login_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `customers_username` varchar(64) DEFAULT NULL,
  `customers_fid` int(5) DEFAULT NULL,
  `customers_sid` int(5) DEFAULT NULL,
  `customers_personal_discount` decimal(4,2) DEFAULT '0.00',
  PRIMARY KEY (`customers_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `customers` VALUES
(1, NULL, NULL, 0, NULL, 0, '', 'Admin', '', 'aDMIN', '0000-00-00 00:00:00', 'example@example.com', 1, '123456789', NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, '0', '0', '0', 0, '', '', '', 0, '2012-03-10 22:56:36', '2012-03-10 22:56:36', NULL, NULL, '0', '2012-03-12 09:58:01', NULL, NULL, NULL, '0.00');

DROP table IF EXISTS `customers_basket`;
CREATE TABLE `customers_basket` (
  `customers_basket_id` int(11) NOT NULL AUTO_INCREMENT,
  `customers_id` int(11) NOT NULL,
  `products_id` tinytext,
  `customers_basket_quantity` int(2) NOT NULL,
  `final_price` decimal(15,4) NOT NULL,
  `customers_basket_date_added` char(8) DEFAULT NULL,
  PRIMARY KEY (`customers_basket_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `customers_basket` VALUES
(1, 1, '1', 3, '0.0000', '20120312'),
(2, 1, '2', 1, '0.0000', '20120312');

DROP table IF EXISTS `customers_basket_attributes`;
CREATE TABLE `customers_basket_attributes` (
  `customers_basket_attributes_id` int(11) NOT NULL AUTO_INCREMENT,
  `customers_id` int(11) NOT NULL,
  `products_id` tinytext,
  `products_options_id` int(11) NOT NULL,
  `products_options_value_id` int(11) NOT NULL,
  `products_options_value_text` text,
  PRIMARY KEY (`customers_basket_attributes_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `customers_info`;
CREATE TABLE `customers_info` (
  `customers_info_id` int(11) NOT NULL,
  `customers_info_date_of_last_logon` datetime DEFAULT NULL,
  `customers_info_number_of_logons` int(5) DEFAULT NULL,
  `customers_info_date_account_created` datetime DEFAULT NULL,
  `customers_info_date_account_last_modified` datetime DEFAULT NULL,
  `global_product_notifications` int(1) DEFAULT '0',
  PRIMARY KEY (`customers_info_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `customers_info` VALUES
(1, '2012-03-12 09:58:01', 2, '2012-03-10 22:56:36', '2012-03-10 22:56:36', 0);

DROP table IF EXISTS `customers_ip`;
CREATE TABLE `customers_ip` (
  `customers_ip_id` int(11) NOT NULL AUTO_INCREMENT,
  `customers_id` int(11) NOT NULL DEFAULT '0',
  `customers_ip` varchar(15) NOT NULL DEFAULT '',
  `customers_ip_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `customers_host` varchar(255) NOT NULL DEFAULT '',
  `customers_advertiser` varchar(30) DEFAULT NULL,
  `customers_referer_url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`customers_ip_id`),
  KEY `customers_id` (`customers_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `customers_ip` VALUES
(1, 1, '127.0.0.1', '2012-03-12 09:32:42', 'peru', '', 'peru/'),
(2, 1, '127.0.0.1', '2012-03-12 09:58:01', '', '', '');

DROP table IF EXISTS `customers_memo`;
CREATE TABLE `customers_memo` (
  `memo_id` int(11) NOT NULL AUTO_INCREMENT,
  `customers_id` int(11) NOT NULL DEFAULT '0',
  `memo_date` date NOT NULL DEFAULT '0000-00-00',
  `memo_title` text,
  `memo_text` text,
  `poster_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`memo_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `customers_status`;
CREATE TABLE `customers_status` (
  `customers_status_id` int(11) NOT NULL DEFAULT '0',
  `language_id` int(11) NOT NULL DEFAULT '1',
  `customers_status_name` varchar(255) NOT NULL DEFAULT '',
  `customers_status_public` int(1) NOT NULL DEFAULT '1',
  `customers_status_min_order` int(7) DEFAULT NULL,
  `customers_status_max_order` int(7) DEFAULT NULL,
  `customers_status_image` varchar(255) DEFAULT NULL,
  `customers_status_discount` decimal(4,2) DEFAULT '0.00',
  `customers_status_ot_discount_flag` char(1) NOT NULL DEFAULT '0',
  `customers_status_ot_discount` decimal(4,2) DEFAULT '0.00',
  `customers_status_graduated_prices` varchar(1) NOT NULL DEFAULT '0',
  `customers_status_show_price` int(1) NOT NULL DEFAULT '1',
  `customers_status_show_price_tax` int(1) NOT NULL DEFAULT '1',
  `customers_status_add_tax_ot` int(1) NOT NULL DEFAULT '0',
  `customers_status_payment_unallowed` varchar(255) NOT NULL,
  `customers_status_shipping_unallowed` varchar(255) NOT NULL,
  `customers_status_discount_attributes` int(1) NOT NULL DEFAULT '0',
  `customers_fsk18` int(1) NOT NULL DEFAULT '1',
  `customers_fsk18_display` int(1) NOT NULL DEFAULT '1',
  `customers_status_write_reviews` int(1) NOT NULL DEFAULT '1',
  `customers_status_read_reviews` int(1) NOT NULL DEFAULT '1',
  `customers_status_accumulated_limit` decimal(15,4) DEFAULT '0.0000',
  PRIMARY KEY (`customers_status_id`,`language_id`),
  KEY `idx_orders_status_name` (`customers_status_name`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `customers_status` VALUES
(0, 1, 'Админ', 1, NULL, NULL, 'admin_status.gif', '0.00', '1', '0.00', '1', 1, 1, 0, '', '', 0, 1, 1, 1, 1, '0.0000'),
(1, 1, 'Посетитель', 1, NULL, NULL, 'guest_status.gif', '0.00', '0', '0.00', '0', 1, 1, 0, '', '', 0, 1, 1, 1, 1, '0.0000'),
(2, 1, 'Покупатель', 1, NULL, NULL, 'customer_status.gif', '0.00', '0', '0.00', '1', 1, 1, 0, '', '', 0, 1, 1, 1, 1, '0.0000'),
(3, 1, 'Оптовый покупатель', 1, NULL, NULL, 'merchant_status.gif', '0.00', '0', '0.00', '1', 1, 0, 0, '', '', 0, 1, 1, 1, 1, '0.0000');

DROP table IF EXISTS `customers_status_history`;
CREATE TABLE `customers_status_history` (
  `customers_status_history_id` int(11) NOT NULL AUTO_INCREMENT,
  `customers_id` int(11) NOT NULL DEFAULT '0',
  `new_value` int(5) NOT NULL DEFAULT '0',
  `old_value` int(5) DEFAULT NULL,
  `date_added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `customer_notified` int(1) DEFAULT '0',
  PRIMARY KEY (`customers_status_history_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `customers_status_orders_status`;
CREATE TABLE `customers_status_orders_status` (
  `customers_status_id` int(11) NOT NULL DEFAULT '0',
  `orders_status_id` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `customers_to_extra_fields`;
CREATE TABLE `customers_to_extra_fields` (
  `customers_id` int(11) NOT NULL DEFAULT '0',
  `fields_id` int(11) NOT NULL DEFAULT '0',
  `value` text
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `customers_to_manufacturers_discount`;
CREATE TABLE `customers_to_manufacturers_discount` (
  `discount_id` int(11) NOT NULL AUTO_INCREMENT,
  `customers_id` int(11) DEFAULT NULL,
  `manufacturers_id` int(11) DEFAULT NULL,
  `discount` decimal(4,2) DEFAULT NULL,
  PRIMARY KEY (`discount_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `database_version`;
CREATE TABLE `database_version` (
  `version` varchar(255) NOT NULL
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `database_version` VALUES
('1.63');

DROP table IF EXISTS `extra_fields`;
CREATE TABLE `extra_fields` (
  `fields_id` int(11) NOT NULL AUTO_INCREMENT,
  `fields_input_type` int(11) NOT NULL DEFAULT '0',
  `fields_input_value` text,
  `fields_status` tinyint(2) NOT NULL DEFAULT '0',
  `fields_required_status` tinyint(2) NOT NULL DEFAULT '0',
  `fields_size` int(5) NOT NULL DEFAULT '0',
  `fields_required_email` tinyint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`fields_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `extra_fields_info`;
CREATE TABLE `extra_fields_info` (
  `fields_id` int(11) NOT NULL DEFAULT '0',
  `languages_id` int(11) NOT NULL DEFAULT '0',
  `fields_name` varchar(255) NOT NULL DEFAULT ''
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `faq`;
CREATE TABLE `faq` (
  `faq_id` int(11) NOT NULL AUTO_INCREMENT,
  `question` varchar(255) NOT NULL,
  `answer` text,
  `date_added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `language` int(11) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `faq_page_url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`faq_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `featured`;
CREATE TABLE `featured` (
  `featured_id` int(11) NOT NULL AUTO_INCREMENT,
  `products_id` int(11) NOT NULL,
  `featured_quantity` int(4) NOT NULL,
  `featured_date_added` datetime DEFAULT NULL,
  `featured_last_modified` datetime DEFAULT NULL,
  `expires_date` datetime DEFAULT NULL,
  `date_status_change` datetime DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`featured_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `geo_zones`;
CREATE TABLE `geo_zones` (
  `geo_zone_id` int(11) NOT NULL AUTO_INCREMENT,
  `geo_zone_name` varchar(255) NOT NULL,
  `geo_zone_description` varchar(255) NOT NULL,
  `last_modified` datetime DEFAULT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`geo_zone_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `languages`;
CREATE TABLE `languages` (
  `languages_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `code` char(2) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `directory` varchar(255) DEFAULT NULL,
  `sort_order` int(3) DEFAULT NULL,
  `language_charset` text,
  PRIMARY KEY (`languages_id`),
  KEY `IDX_LANGUAGES_NAME` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `languages` VALUES
(1, 'Русский', 'ru', 'icon.gif', 'russian', 1, 'utf-8');

DROP table IF EXISTS `latest_news`;
CREATE TABLE `latest_news` (
  `news_id` int(11) NOT NULL AUTO_INCREMENT,
  `headline` varchar(255) NOT NULL,
  `content` text,
  `date_added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `language` int(11) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `news_page_url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`news_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `manufacturers`;
CREATE TABLE `manufacturers` (
  `manufacturers_id` int(11) NOT NULL AUTO_INCREMENT,
  `manufacturers_name` varchar(255) NOT NULL,
  `manufacturers_image` varchar(255) DEFAULT NULL,
  `date_added` datetime DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`manufacturers_id`),
  KEY `IDX_MANUFACTURERS_NAME` (`manufacturers_name`)
) ENGINE=MyISAM AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `manufacturers` VALUES
(1, 'PeruArt', '', '2012-03-12 15:22:20', '2012-03-12 15:22:20');

DROP table IF EXISTS `manufacturers_info`;
CREATE TABLE `manufacturers_info` (
  `manufacturers_id` int(11) NOT NULL,
  `languages_id` int(11) NOT NULL,
  `manufacturers_meta_title` varchar(255) NOT NULL,
  `manufacturers_meta_description` varchar(255) NOT NULL,
  `manufacturers_meta_keywords` varchar(255) NOT NULL,
  `manufacturers_url` varchar(255) NOT NULL,
  `manufacturers_description` varchar(255) NOT NULL,
  `url_clicked` int(5) NOT NULL DEFAULT '0',
  `date_last_click` datetime DEFAULT NULL,
  PRIMARY KEY (`manufacturers_id`,`languages_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `manufacturers_info` VALUES
(1, 1, '', '', '', '', '', 0, NULL);

DROP table IF EXISTS `media_content`;
CREATE TABLE `media_content` (
  `file_id` int(11) NOT NULL AUTO_INCREMENT,
  `old_filename` text,
  `new_filename` text,
  `file_comment` text,
  PRIMARY KEY (`file_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `module_newsletter`;
CREATE TABLE `module_newsletter` (
  `newsletter_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text,
  `bc` text,
  `cc` text,
  `date` datetime DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '0',
  `body` text,
  PRIMARY KEY (`newsletter_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `newsletter_recipients`;
CREATE TABLE `newsletter_recipients` (
  `mail_id` int(11) NOT NULL AUTO_INCREMENT,
  `customers_email_address` varchar(96) NOT NULL DEFAULT '',
  `customers_id` int(11) NOT NULL DEFAULT '0',
  `customers_status` int(5) NOT NULL DEFAULT '0',
  `customers_firstname` varchar(255) NOT NULL DEFAULT '',
  `customers_lastname` varchar(255) NOT NULL DEFAULT '',
  `mail_status` int(1) NOT NULL DEFAULT '0',
  `mail_key` varchar(255) NOT NULL DEFAULT '',
  `date_added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`mail_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `newsletters`;
CREATE TABLE `newsletters` (
  `newsletters_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` text,
  `module` varchar(255) NOT NULL,
  `date_added` datetime NOT NULL,
  `date_sent` datetime DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  `locked` int(1) DEFAULT '0',
  PRIMARY KEY (`newsletters_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `newsletters_history`;
CREATE TABLE `newsletters_history` (
  `news_hist_id` int(11) NOT NULL DEFAULT '0',
  `news_hist_cs` int(11) NOT NULL DEFAULT '0',
  `news_hist_cs_date_sent` date DEFAULT NULL,
  PRIMARY KEY (`news_hist_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `orders`;
CREATE TABLE `orders` (
  `orders_id` int(11) NOT NULL AUTO_INCREMENT,
  `customers_id` int(11) NOT NULL,
  `customers_cid` varchar(255) DEFAULT NULL,
  `customers_vat_id` varchar(20) DEFAULT NULL,
  `customers_status` int(11) DEFAULT NULL,
  `customers_status_name` varchar(255) NOT NULL,
  `customers_status_image` varchar(64) DEFAULT NULL,
  `customers_status_discount` decimal(4,2) DEFAULT NULL,
  `customers_name` varchar(255) NOT NULL,
  `customers_firstname` varchar(255) NOT NULL,
  `customers_secondname` varchar(255) NOT NULL,
  `customers_lastname` varchar(255) NOT NULL,
  `customers_company` varchar(255) DEFAULT NULL,
  `customers_street_address` varchar(255) NOT NULL,
  `customers_suburb` varchar(255) DEFAULT NULL,
  `customers_city` varchar(255) NOT NULL,
  `customers_postcode` varchar(10) NOT NULL,
  `customers_state` varchar(255) DEFAULT NULL,
  `customers_country` varchar(255) NOT NULL,
  `customers_telephone` varchar(255) NOT NULL,
  `customers_email_address` varchar(96) NOT NULL,
  `customers_address_format_id` int(5) NOT NULL,
  `delivery_name` varchar(255) NOT NULL,
  `delivery_firstname` varchar(255) NOT NULL,
  `delivery_secondname` varchar(255) NOT NULL,
  `delivery_lastname` varchar(255) NOT NULL,
  `delivery_company` varchar(255) DEFAULT NULL,
  `delivery_street_address` varchar(255) NOT NULL,
  `delivery_suburb` varchar(255) DEFAULT NULL,
  `delivery_city` varchar(255) NOT NULL,
  `delivery_postcode` varchar(10) NOT NULL,
  `delivery_state` varchar(255) DEFAULT NULL,
  `delivery_country` varchar(255) NOT NULL,
  `delivery_country_iso_code_2` char(2) NOT NULL,
  `delivery_address_format_id` int(5) NOT NULL,
  `billing_name` varchar(255) NOT NULL,
  `billing_firstname` varchar(255) NOT NULL,
  `billing_secondname` varchar(255) NOT NULL,
  `billing_lastname` varchar(255) NOT NULL,
  `billing_company` varchar(255) DEFAULT NULL,
  `billing_street_address` varchar(255) NOT NULL,
  `billing_suburb` varchar(255) DEFAULT NULL,
  `billing_city` varchar(255) NOT NULL,
  `billing_postcode` varchar(10) NOT NULL,
  `billing_state` varchar(255) DEFAULT NULL,
  `billing_country` varchar(255) NOT NULL,
  `billing_country_iso_code_2` char(2) NOT NULL,
  `billing_address_format_id` int(5) NOT NULL,
  `payment_method` varchar(255) NOT NULL,
  `cc_type` varchar(20) DEFAULT NULL,
  `cc_owner` varchar(255) DEFAULT NULL,
  `cc_number` varchar(255) DEFAULT NULL,
  `cc_expires` varchar(4) DEFAULT NULL,
  `cc_start` varchar(4) DEFAULT NULL,
  `cc_issue` varchar(3) DEFAULT NULL,
  `cc_cvv` varchar(4) DEFAULT NULL,
  `comments` varchar(255) DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  `date_purchased` datetime DEFAULT NULL,
  `orders_status` int(5) NOT NULL,
  `orders_date_finished` datetime DEFAULT NULL,
  `currency` char(3) DEFAULT NULL,
  `currency_value` decimal(14,6) DEFAULT NULL,
  `account_type` int(1) NOT NULL DEFAULT '0',
  `payment_class` varchar(255) NOT NULL,
  `shipping_method` varchar(255) NOT NULL,
  `shipping_class` varchar(255) NOT NULL,
  `customers_ip` varchar(255) NOT NULL,
  `language` varchar(255) NOT NULL,
  `afterbuy_success` int(1) NOT NULL DEFAULT '0',
  `afterbuy_id` int(32) NOT NULL DEFAULT '0',
  `refferers_id` varchar(255) NOT NULL,
  `conversion_type` int(1) NOT NULL DEFAULT '0',
  `orders_ident_key` varchar(255) DEFAULT NULL,
  `orig_reference` text,
  `login_reference` text,
  PRIMARY KEY (`orders_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `orders_products`;
CREATE TABLE `orders_products` (
  `orders_products_id` int(11) NOT NULL AUTO_INCREMENT,
  `orders_id` int(11) NOT NULL,
  `products_id` int(11) NOT NULL,
  `products_model` varchar(255) DEFAULT NULL,
  `products_name` varchar(255) NOT NULL,
  `products_price` decimal(15,4) NOT NULL,
  `products_discount_made` decimal(4,2) DEFAULT NULL,
  `products_shipping_time` varchar(255) DEFAULT NULL,
  `final_price` decimal(15,4) NOT NULL,
  `products_tax` decimal(7,4) NOT NULL,
  `products_quantity` int(2) NOT NULL,
  `allow_tax` int(1) NOT NULL,
  PRIMARY KEY (`orders_products_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `orders_products_attributes`;
CREATE TABLE `orders_products_attributes` (
  `orders_products_attributes_id` int(11) NOT NULL AUTO_INCREMENT,
  `orders_id` int(11) NOT NULL,
  `orders_products_id` int(11) NOT NULL,
  `products_options` varchar(255) NOT NULL,
  `products_options_values` varchar(255) NOT NULL,
  `options_values_price` decimal(15,4) NOT NULL,
  `price_prefix` char(1) NOT NULL,
  PRIMARY KEY (`orders_products_attributes_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `orders_products_download`;
CREATE TABLE `orders_products_download` (
  `orders_products_download_id` int(11) NOT NULL AUTO_INCREMENT,
  `orders_id` int(11) NOT NULL DEFAULT '0',
  `orders_products_id` int(11) NOT NULL DEFAULT '0',
  `orders_products_filename` varchar(255) NOT NULL DEFAULT '',
  `download_maxdays` int(2) NOT NULL DEFAULT '0',
  `download_count` int(2) NOT NULL DEFAULT '0',
  `download_is_pin` tinyint(1) NOT NULL DEFAULT '0',
  `download_pin_code` varchar(255) NOT NULL,
  PRIMARY KEY (`orders_products_download_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `orders_recalculate`;
CREATE TABLE `orders_recalculate` (
  `orders_recalculate_id` int(11) NOT NULL AUTO_INCREMENT,
  `orders_id` int(11) NOT NULL DEFAULT '0',
  `n_price` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `b_price` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `tax` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `tax_rate` decimal(7,4) NOT NULL DEFAULT '0.0000',
  `class` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`orders_recalculate_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `orders_status`;
CREATE TABLE `orders_status` (
  `orders_status_id` int(11) NOT NULL DEFAULT '0',
  `language_id` int(11) NOT NULL DEFAULT '1',
  `orders_status_name` varchar(255) NOT NULL,
  PRIMARY KEY (`orders_status_id`,`language_id`),
  KEY `idx_orders_status_name` (`orders_status_name`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `orders_status` VALUES
(1, 1, 'Ожидает проверки'),
(2, 1, 'Ждём оплаты'),
(3, 1, 'Отменён'),
(4, 1, 'Выполняется'),
(5, 1, 'Доставляется'),
(6, 1, 'Доставлен');

DROP table IF EXISTS `orders_status_history`;
CREATE TABLE `orders_status_history` (
  `orders_status_history_id` int(11) NOT NULL AUTO_INCREMENT,
  `orders_id` int(11) NOT NULL,
  `orders_status_id` int(5) NOT NULL,
  `date_added` datetime NOT NULL,
  `customer_notified` int(1) DEFAULT '0',
  `comments` text,
  PRIMARY KEY (`orders_status_history_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `orders_total`;
CREATE TABLE `orders_total` (
  `orders_total_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `orders_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `text` varchar(255) NOT NULL,
  `value` decimal(15,4) NOT NULL,
  `class` varchar(255) NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`orders_total_id`),
  KEY `idx_orders_total_orders_id` (`orders_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `payment_moneybookers`;
CREATE TABLE `payment_moneybookers` (
  `mb_TRID` varchar(255) NOT NULL DEFAULT '',
  `mb_ERRNO` smallint(3) unsigned NOT NULL DEFAULT '0',
  `mb_ERRTXT` varchar(255) NOT NULL DEFAULT '',
  `mb_DATE` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `mb_MBTID` bigint(18) unsigned NOT NULL DEFAULT '0',
  `mb_STATUS` tinyint(1) NOT NULL DEFAULT '0',
  `mb_ORDERID` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`mb_TRID`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `payment_moneybookers_countries`;
CREATE TABLE `payment_moneybookers_countries` (
  `osc_cID` int(11) NOT NULL DEFAULT '0',
  `mb_cID` char(3) NOT NULL DEFAULT '',
  PRIMARY KEY (`osc_cID`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `payment_moneybookers_countries` VALUES
(2, 'ALB'),
(3, 'ALG'),
(4, 'AME'),
(5, 'AND'),
(6, 'AGL'),
(7, 'ANG'),
(9, 'ANT'),
(10, 'ARG'),
(11, 'ARM'),
(12, 'ARU'),
(13, 'AUS'),
(14, 'AUT'),
(15, 'AZE'),
(16, 'BMS'),
(17, 'BAH'),
(18, 'BAN'),
(19, 'BAR'),
(20, 'BLR'),
(21, 'BGM'),
(22, 'BEL'),
(23, 'BEN'),
(24, 'BER'),
(26, 'BOL'),
(27, 'BOS'),
(28, 'BOT'),
(30, 'BRA'),
(32, 'BRU'),
(33, 'BUL'),
(34, 'BKF'),
(35, 'BUR'),
(36, 'CAM'),
(37, 'CMR'),
(38, 'CAN'),
(39, 'CAP'),
(40, 'CAY'),
(41, 'CEN'),
(42, 'CHA'),
(43, 'CHL'),
(44, 'CHN'),
(47, 'COL'),
(49, 'CON'),
(51, 'COS'),
(52, 'COT'),
(53, 'CRO'),
(54, 'CUB'),
(55, 'CYP'),
(56, 'CZE'),
(57, 'DEN'),
(58, 'DJI'),
(59, 'DOM'),
(60, 'DRP'),
(62, 'ECU'),
(64, 'EL_'),
(65, 'EQU'),
(66, 'ERI'),
(67, 'EST'),
(68, 'ETH'),
(70, 'FAR'),
(71, 'FIJ'),
(72, 'FIN'),
(73, 'FRA'),
(75, 'FRE'),
(78, 'GAB'),
(79, 'GAM'),
(80, 'GEO'),
(81, 'GER'),
(82, 'GHA'),
(83, 'GIB'),
(84, 'GRC'),
(85, 'GRL'),
(87, 'GDL'),
(88, 'GUM'),
(89, 'GUA'),
(90, 'GUI'),
(91, 'GBS'),
(92, 'GUY'),
(93, 'HAI'),
(95, 'HON'),
(96, 'HKG'),
(97, 'HUN'),
(98, 'ICE'),
(99, 'IND'),
(101, 'IRN'),
(102, 'IRA'),
(103, 'IRE'),
(104, 'ISR'),
(105, 'ITA'),
(106, 'JAM'),
(107, 'JAP'),
(108, 'JOR'),
(109, 'KAZ'),
(110, 'KEN'),
(112, 'SKO'),
(113, 'KOR'),
(114, 'KUW'),
(115, 'KYR'),
(116, 'LAO'),
(117, 'LAT'),
(141, 'MCO'),
(119, 'LES'),
(120, 'LIB'),
(121, 'LBY'),
(122, 'LIE'),
(123, 'LIT'),
(124, 'LUX'),
(125, 'MAC'),
(126, 'F.Y'),
(127, 'MAD'),
(128, 'MLW'),
(129, 'MLS'),
(130, 'MAL'),
(131, 'MLI'),
(132, 'MLT'),
(134, 'MAR'),
(135, 'MRT'),
(136, 'MAU'),
(138, 'MEX'),
(140, 'MOL'),
(142, 'MON'),
(143, 'MTT'),
(144, 'MOR'),
(145, 'MOZ'),
(76, 'PYF'),
(147, 'NAM'),
(149, 'NEP'),
(150, 'NED'),
(151, 'NET'),
(152, 'CDN'),
(153, 'NEW'),
(154, 'NIC'),
(155, 'NIG'),
(69, 'FLK'),
(160, 'NWY'),
(161, 'OMA'),
(162, 'PAK'),
(164, 'PAN'),
(165, 'PAP'),
(166, 'PAR'),
(167, 'PER'),
(168, 'PHI'),
(170, 'POL'),
(171, 'POR'),
(172, 'PUE'),
(173, 'QAT'),
(175, 'ROM'),
(176, 'RUS'),
(177, 'RWA'),
(178, 'SKN'),
(179, 'SLU'),
(180, 'ST.'),
(181, 'WES'),
(182, 'SAN'),
(183, 'SAO'),
(184, 'SAU'),
(185, 'SEN'),
(186, 'SEY'),
(187, 'SIE'),
(188, 'SIN'),
(189, 'SLO'),
(190, 'SLV'),
(191, 'SOL'),
(192, 'SOM'),
(193, 'SOU'),
(195, 'SPA'),
(196, 'SRI'),
(199, 'SUD'),
(200, 'SUR'),
(202, 'SWA'),
(203, 'SWE'),
(204, 'SWI'),
(205, 'SYR'),
(206, 'TWN'),
(207, 'TAJ'),
(208, 'TAN'),
(209, 'THA'),
(210, 'TOG'),
(212, 'TON'),
(213, 'TRI'),
(214, 'TUN'),
(215, 'TUR'),
(216, 'TKM'),
(217, 'TCI'),
(219, 'UGA'),
(231, 'BRI'),
(221, 'UAE'),
(222, 'GBR'),
(223, 'UNI'),
(225, 'URU'),
(226, 'UZB'),
(227, 'VAN'),
(229, 'VEN'),
(230, 'VIE'),
(232, 'US_'),
(235, 'YEM'),
(236, 'YUG'),
(238, 'ZAM'),
(239, 'ZIM');

DROP table IF EXISTS `payment_moneybookers_currencies`;
CREATE TABLE `payment_moneybookers_currencies` (
  `mb_currID` char(3) NOT NULL DEFAULT '',
  `mb_currName` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`mb_currID`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `payment_moneybookers_currencies` VALUES
('AUD', 'Australian Dollar'),
('BGN', 'Bulgarian Lev'),
('CAD', 'Canadian Dollar'),
('CHF', 'Swiss Franc'),
('CZK', 'Czech Koruna'),
('DKK', 'Danish Krone'),
('EEK', 'Estonian Koruna'),
('EUR', 'Euro'),
('GBP', 'Pound Sterling'),
('HKD', 'Hong Kong Dollar'),
('HUF', 'Forint'),
('ILS', 'Shekel'),
('ISK', 'Iceland Krona'),
('JPY', 'Yen'),
('KRW', 'South-Korean Won'),
('LVL', 'Latvian Lat'),
('MYR', 'Malaysian Ringgit'),
('NOK', 'Norwegian Krone'),
('NZD', 'New Zealand Dollar'),
('PLN', 'Zloty'),
('SEK', 'Swedish Krona'),
('SGD', 'Singapore Dollar'),
('SKK', 'Slovak Koruna'),
('THB', 'Baht'),
('TWD', 'New Taiwan Dollar'),
('USD', 'US Dollar'),
('ZAR', 'South-African Rand');

DROP table IF EXISTS `payment_qenta`;
CREATE TABLE `payment_qenta` (
  `q_TRID` varchar(255) NOT NULL DEFAULT '',
  `q_DATE` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `q_QTID` bigint(18) unsigned NOT NULL DEFAULT '0',
  `q_ORDERDESC` varchar(255) NOT NULL DEFAULT '',
  `q_STATUS` tinyint(1) NOT NULL DEFAULT '0',
  `q_ORDERID` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`q_TRID`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `personal_offers_by_customers_status_0`;
CREATE TABLE `personal_offers_by_customers_status_0` (
  `price_id` int(11) NOT NULL AUTO_INCREMENT,
  `products_id` int(11) NOT NULL,
  `quantity` int(11) DEFAULT NULL,
  `personal_offer` decimal(15,4) DEFAULT NULL,
  PRIMARY KEY (`price_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `personal_offers_by_customers_status_1`;
CREATE TABLE `personal_offers_by_customers_status_1` (
  `price_id` int(11) NOT NULL AUTO_INCREMENT,
  `products_id` int(11) NOT NULL,
  `quantity` int(11) DEFAULT NULL,
  `personal_offer` decimal(15,4) DEFAULT NULL,
  PRIMARY KEY (`price_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `personal_offers_by_customers_status_1` VALUES
(1, 0, 1, '0.0000'),
(2, 1, 1, '0.0000'),
(3, 2, 1, '0.0000');

DROP table IF EXISTS `personal_offers_by_customers_status_2`;
CREATE TABLE `personal_offers_by_customers_status_2` (
  `price_id` int(11) NOT NULL AUTO_INCREMENT,
  `products_id` int(11) NOT NULL,
  `quantity` int(11) DEFAULT NULL,
  `personal_offer` decimal(15,4) DEFAULT NULL,
  PRIMARY KEY (`price_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `personal_offers_by_customers_status_2` VALUES
(1, 0, 1, '0.0000'),
(2, 1, 1, '0.0000'),
(3, 2, 1, '0.0000');

DROP table IF EXISTS `personal_offers_by_customers_status_3`;
CREATE TABLE `personal_offers_by_customers_status_3` (
  `price_id` int(11) NOT NULL AUTO_INCREMENT,
  `products_id` int(11) NOT NULL,
  `quantity` int(11) DEFAULT NULL,
  `personal_offer` decimal(15,4) DEFAULT NULL,
  PRIMARY KEY (`price_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `personal_offers_by_customers_status_3` VALUES
(1, 0, 1, '0.0000'),
(2, 1, 1, '0.0000'),
(3, 2, 1, '0.0000');

DROP table IF EXISTS `persons`;
CREATE TABLE `persons` (
  `orders_id` int(11) NOT NULL DEFAULT '0',
  `customers_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  KEY `orders_id` (`orders_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `products`;
CREATE TABLE `products` (
  `products_id` int(11) NOT NULL AUTO_INCREMENT,
  `products_ean` varchar(255) DEFAULT NULL,
  `products_quantity` int(4) NOT NULL,
  `products_quantity_min` int(4) NOT NULL DEFAULT '1',
  `products_quantity_max` int(4) NOT NULL DEFAULT '1000',
  `products_shippingtime` int(4) NOT NULL,
  `products_model` varchar(255) DEFAULT NULL,
  `group_permission_0` tinyint(1) NOT NULL,
  `group_permission_1` tinyint(1) NOT NULL,
  `group_permission_2` tinyint(1) NOT NULL,
  `group_permission_3` tinyint(1) NOT NULL,
  `products_sort` int(4) NOT NULL DEFAULT '0',
  `products_image` varchar(255) DEFAULT NULL,
  `products_price` decimal(15,4) NOT NULL,
  `products_discount_allowed` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `products_date_added` datetime NOT NULL,
  `products_last_modified` datetime DEFAULT NULL,
  `products_date_available` datetime DEFAULT NULL,
  `products_weight` decimal(5,2) NOT NULL,
  `products_status` tinyint(1) NOT NULL,
  `products_tax_class_id` int(11) NOT NULL,
  `product_template` varchar(64) DEFAULT NULL,
  `options_template` varchar(64) DEFAULT NULL,
  `manufacturers_id` int(11) DEFAULT NULL,
  `products_ordered` int(11) NOT NULL DEFAULT '0',
  `products_fsk18` int(1) NOT NULL DEFAULT '0',
  `products_vpe` int(11) NOT NULL,
  `products_vpe_status` int(1) NOT NULL DEFAULT '0',
  `products_vpe_value` decimal(15,4) NOT NULL,
  `products_startpage` int(1) NOT NULL DEFAULT '0',
  `products_startpage_sort` int(4) NOT NULL DEFAULT '0',
  `products_to_xml` tinyint(1) NOT NULL DEFAULT '1',
  `yml_bid` varchar(4) NOT NULL DEFAULT '0',
  `yml_cbid` varchar(4) NOT NULL DEFAULT '0',
  `products_page_url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`products_id`),
  KEY `idx_products_date_added` (`products_date_added`)
) ENGINE=MyISAM AUTO_INCREMENT=3 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `products` VALUES
(1, '', 0, 1, 1000, 1, '', 0, 0, 0, 0, 0, NULL, '10000.0000', '100.0000', '2012-03-12 09:33:44', '2012-03-12 09:58:35', '0000-00-00 00:00:00', '0.00', 1, 0, 'default', 'default', 0, 0, 0, 0, 0, '0.0000', 1, 0, 1, '', '', ''),
(2, '', 0, 1, 1000, 1, '', 0, 0, 0, 0, 0, NULL, '300.0000', '100.0000', '2012-03-12 11:35:06', NULL, '0000-00-00 00:00:00', '0.00', 1, 0, 'default', 'default', 0, 0, 0, 0, 0, '0.0000', 0, 0, 1, '', '', '');

DROP table IF EXISTS `products_attributes`;
CREATE TABLE `products_attributes` (
  `products_attributes_id` int(11) NOT NULL AUTO_INCREMENT,
  `products_id` int(11) NOT NULL,
  `options_id` int(11) NOT NULL,
  `options_values_id` int(11) NOT NULL,
  `options_values_price` decimal(15,4) NOT NULL,
  `price_prefix` char(1) NOT NULL,
  `attributes_model` varchar(255) DEFAULT NULL,
  `attributes_stock` int(4) DEFAULT NULL,
  `options_values_weight` decimal(15,4) NOT NULL,
  `weight_prefix` char(1) NOT NULL,
  `sortorder` int(11) DEFAULT NULL,
  PRIMARY KEY (`products_attributes_id`),
  KEY `PRODUCTS_ID_INDEX` (`products_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `products_attributes_download`;
CREATE TABLE `products_attributes_download` (
  `products_attributes_id` int(11) NOT NULL,
  `products_attributes_filename` varchar(255) NOT NULL DEFAULT '',
  `products_attributes_maxdays` int(2) DEFAULT '0',
  `products_attributes_maxcount` int(2) DEFAULT '0',
  `products_attributes_is_pin` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`products_attributes_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `products_content`;
CREATE TABLE `products_content` (
  `content_id` int(11) NOT NULL AUTO_INCREMENT,
  `products_id` int(11) NOT NULL DEFAULT '0',
  `group_ids` text,
  `content_name` varchar(255) NOT NULL DEFAULT '',
  `content_file` varchar(255) NOT NULL,
  `content_link` text,
  `languages_id` int(11) NOT NULL DEFAULT '0',
  `content_read` int(11) NOT NULL DEFAULT '0',
  `file_comment` text,
  PRIMARY KEY (`content_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `products_description`;
CREATE TABLE `products_description` (
  `products_id` int(11) NOT NULL AUTO_INCREMENT,
  `language_id` int(11) NOT NULL DEFAULT '1',
  `products_name` varchar(255) NOT NULL DEFAULT '',
  `products_description` text,
  `products_short_description` text,
  `products_keywords` varchar(255) DEFAULT NULL,
  `products_meta_title` text,
  `products_meta_description` text,
  `products_meta_keywords` text,
  `products_url` varchar(255) DEFAULT NULL,
  `products_viewed` int(5) DEFAULT '0',
  PRIMARY KEY (`products_id`,`language_id`),
  KEY `products_name` (`products_name`)
) ENGINE=MyISAM AUTO_INCREMENT=3 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `products_description` VALUES
(1, 1, 'fgrt er fg df', 'dyt thhg', 'dfhgg ghfg fy fh', '', '', '', '', '', 4),
(2, 1, 'куекуцекуеку', 'екцуе пар пвопор поап', '', '', '', '', '', '', 6);

DROP table IF EXISTS `products_extra_fields`;
CREATE TABLE `products_extra_fields` (
  `products_extra_fields_id` int(11) NOT NULL AUTO_INCREMENT,
  `products_extra_fields_name` varchar(255) NOT NULL,
  `products_extra_fields_order` int(3) NOT NULL DEFAULT '0',
  `products_extra_fields_status` tinyint(1) NOT NULL DEFAULT '1',
  `languages_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`products_extra_fields_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `products_graduated_prices`;
CREATE TABLE `products_graduated_prices` (
  `products_id` int(11) NOT NULL DEFAULT '0',
  `quantity` int(11) NOT NULL DEFAULT '0',
  `unitprice` decimal(15,4) NOT NULL DEFAULT '0.0000',
  KEY `products_id` (`products_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `products_images`;
CREATE TABLE `products_images` (
  `image_id` int(11) NOT NULL AUTO_INCREMENT,
  `products_id` int(11) NOT NULL,
  `image_nr` smallint(6) NOT NULL,
  `image_name` varchar(254) NOT NULL,
  PRIMARY KEY (`image_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `products_notifications`;
CREATE TABLE `products_notifications` (
  `products_id` int(11) NOT NULL,
  `customers_id` int(11) NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`products_id`,`customers_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `products_options`;
CREATE TABLE `products_options` (
  `products_options_id` int(11) NOT NULL DEFAULT '0',
  `language_id` int(11) NOT NULL DEFAULT '1',
  `products_options_name` varchar(255) NOT NULL DEFAULT '',
  `products_options_length` int(11) NOT NULL DEFAULT '32',
  `products_options_size` int(11) NOT NULL DEFAULT '32',
  `products_options_rows` int(11) NOT NULL DEFAULT '4',
  `products_options_type` int(11) NOT NULL,
  PRIMARY KEY (`products_options_id`,`language_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `products_options_values`;
CREATE TABLE `products_options_values` (
  `products_options_values_id` int(11) NOT NULL DEFAULT '0',
  `language_id` int(11) NOT NULL DEFAULT '1',
  `products_options_values_name` varchar(255) NOT NULL DEFAULT '',
  `products_options_values_description` text,
  `products_options_values_text` varchar(255) NOT NULL DEFAULT '',
  `products_options_values_image` varchar(255) NOT NULL DEFAULT '',
  `products_options_values_link` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`products_options_values_id`,`language_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `products_options_values_to_products_options`;
CREATE TABLE `products_options_values_to_products_options` (
  `products_options_values_to_products_options_id` int(11) NOT NULL AUTO_INCREMENT,
  `products_options_id` int(11) NOT NULL,
  `products_options_values_id` int(11) NOT NULL,
  PRIMARY KEY (`products_options_values_to_products_options_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `products_parameters`;
CREATE TABLE `products_parameters` (
  `products_parameters_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `products_parameters_name` varchar(255) NOT NULL DEFAULT '',
  `products_parameters_title` varchar(255) NOT NULL DEFAULT '',
  `products_parameters_order` int(11) NOT NULL DEFAULT '0',
  `categories_id` int(11) NOT NULL DEFAULT '0',
  `products_parameters_type` enum('p','g') NOT NULL DEFAULT 'p',
  `products_parameters_group` int(11) NOT NULL DEFAULT '0',
  `products_parameters_useinsearch` tinyint(1) NOT NULL DEFAULT '0',
  `products_parameters_intervals` text,
  `products_parameters_titlename` varchar(255) NOT NULL DEFAULT '',
  `products_parameters_titlesuff` varchar(10) NOT NULL DEFAULT '',
  `products_parameters_useinsdesc` tinyint(1) NOT NULL DEFAULT '0',
  `products_parameters_maxopened` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`products_parameters_id`),
  KEY `category_id` (`categories_id`),
  KEY `products_parameters_group` (`products_parameters_group`),
  KEY `products_parameters_useinsearch` (`products_parameters_useinsearch`),
  KEY `products_parameters_useinsdesc` (`products_parameters_useinsdesc`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `products_parameters2products`;
CREATE TABLE `products_parameters2products` (
  `products_parameters_id` int(10) unsigned NOT NULL DEFAULT '0',
  `products_id` int(10) unsigned NOT NULL DEFAULT '0',
  `products_parameters_values_id` int(8) NOT NULL,
  `products_parameters2products_value` varchar(255) NOT NULL DEFAULT '',
  `products_parameters2products_md5` varchar(32) NOT NULL DEFAULT '',
  `products_parameters2products_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`products_parameters_id`,`products_id`),
  KEY `products_id` (`products_id`),
  KEY `products_parameters2products_md5` (`products_parameters2products_md5`),
  KEY `products_parameters_values_id` (`products_parameters_values_id`),
  KEY `products_parameters_id` (`products_parameters_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `products_parameters_values`;
CREATE TABLE `products_parameters_values` (
  `products_parameters_values_id` int(8) NOT NULL AUTO_INCREMENT,
  `products_parameters_id` int(8) NOT NULL,
  `parameters_value` varchar(255) NOT NULL,
  PRIMARY KEY (`products_parameters_values_id`),
  KEY `products_parameters_values_id` (`products_parameters_values_id`),
  KEY `products_parameters_id` (`products_parameters_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `products_pins`;
CREATE TABLE `products_pins` (
  `products_pin_id` int(11) NOT NULL AUTO_INCREMENT,
  `products_id` int(11) NOT NULL,
  `products_pin_code` char(250) NOT NULL,
  `products_pin_used` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`products_pin_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `products_specifications`;
CREATE TABLE `products_specifications` (
  `products_specification_id` int(11) NOT NULL AUTO_INCREMENT,
  `products_id` int(11) NOT NULL DEFAULT '0',
  `specifications_id` int(11) NOT NULL DEFAULT '0',
  `language_id` int(11) NOT NULL DEFAULT '1',
  `specification` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`products_specification_id`),
  KEY `products_id` (`products_id`,`specifications_id`,`language_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `products_to_categories`;
CREATE TABLE `products_to_categories` (
  `products_id` int(11) NOT NULL,
  `categories_id` int(11) NOT NULL,
  PRIMARY KEY (`products_id`,`categories_id`),
  KEY `idx_categories_id` (`categories_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `products_to_categories` VALUES
(1, 1),
(2, 1);

DROP table IF EXISTS `products_to_products_extra_fields`;
CREATE TABLE `products_to_products_extra_fields` (
  `products_id` int(11) NOT NULL DEFAULT '0',
  `products_extra_fields_id` int(11) NOT NULL DEFAULT '0',
  `products_extra_fields_value` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`products_id`,`products_extra_fields_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `products_vpe`;
CREATE TABLE `products_vpe` (
  `products_vpe_id` int(11) NOT NULL DEFAULT '0',
  `language_id` int(11) NOT NULL DEFAULT '0',
  `products_vpe_name` varchar(255) NOT NULL DEFAULT ''
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `products_xsell`;
CREATE TABLE `products_xsell` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `products_id` int(10) unsigned NOT NULL DEFAULT '1',
  `products_xsell_grp_name_id` int(10) unsigned NOT NULL DEFAULT '1',
  `xsell_id` int(10) unsigned NOT NULL DEFAULT '1',
  `sort_order` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `products_xsell_grp_name`;
CREATE TABLE `products_xsell_grp_name` (
  `products_xsell_grp_name_id` int(10) NOT NULL,
  `xsell_sort_order` int(10) NOT NULL DEFAULT '0',
  `language_id` smallint(6) NOT NULL DEFAULT '0',
  `groupname` varchar(255) NOT NULL DEFAULT ''
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `reviews`;
CREATE TABLE `reviews` (
  `reviews_id` int(11) NOT NULL AUTO_INCREMENT,
  `products_id` int(11) NOT NULL,
  `customers_id` int(11) DEFAULT NULL,
  `customers_name` varchar(255) NOT NULL,
  `reviews_rating` int(1) DEFAULT NULL,
  `date_added` datetime DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  `reviews_read` int(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`reviews_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `reviews_description`;
CREATE TABLE `reviews_description` (
  `reviews_id` int(11) NOT NULL,
  `languages_id` int(11) NOT NULL,
  `reviews_text` text,
  PRIMARY KEY (`reviews_id`,`languages_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `scart`;
CREATE TABLE `scart` (
  `scartid` int(11) NOT NULL AUTO_INCREMENT,
  `customers_id` int(11) NOT NULL,
  `dateadded` varchar(8) NOT NULL,
  PRIMARY KEY (`scartid`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `sessions`;
CREATE TABLE `sessions` (
  `sesskey` varchar(255) NOT NULL,
  `expiry` int(11) unsigned NOT NULL,
  `value` text,
  PRIMARY KEY (`sesskey`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `ship2pay`;
CREATE TABLE `ship2pay` (
  `s2p_id` int(11) NOT NULL AUTO_INCREMENT,
  `shipment` varchar(100) NOT NULL,
  `payments_allowed` varchar(250) NOT NULL,
  `zones_id` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`s2p_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `shipping_status`;
CREATE TABLE `shipping_status` (
  `shipping_status_id` int(11) NOT NULL DEFAULT '0',
  `language_id` int(11) NOT NULL DEFAULT '1',
  `shipping_status_name` varchar(255) NOT NULL,
  `shipping_status_image` varchar(255) NOT NULL,
  PRIMARY KEY (`shipping_status_id`,`language_id`),
  KEY `idx_shipping_status_name` (`shipping_status_name`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `shipping_status` VALUES
(1, 1, '3-4 дня', ''),
(2, 1, '1 неделя', ''),
(3, 1, '2 недели', '');

DROP table IF EXISTS `special_category`;
CREATE TABLE `special_category` (
  `special_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `categ_id` int(11) unsigned NOT NULL DEFAULT '0',
  `discount` decimal(5,2) NOT NULL DEFAULT '0.00',
  `discount_type` enum('p','f') NOT NULL DEFAULT 'f',
  `special_date_added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `special_last_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `expire_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_status_change` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`special_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `special_product`;
CREATE TABLE `special_product` (
  `special_product_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `special_id` int(11) unsigned NOT NULL DEFAULT '0',
  `product_id` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`special_product_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `specials`;
CREATE TABLE `specials` (
  `specials_id` int(11) NOT NULL AUTO_INCREMENT,
  `products_id` int(11) NOT NULL,
  `specials_quantity` int(4) NOT NULL,
  `specials_new_products_price` decimal(15,4) NOT NULL,
  `specials_date_added` datetime DEFAULT NULL,
  `specials_last_modified` datetime DEFAULT NULL,
  `expires_date` datetime DEFAULT NULL,
  `date_status_change` datetime DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`specials_id`),
  KEY `idx_products_id` (`products_id`),
  KEY `PRODUCTS_ID_INDEX` (`products_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `specification_description`;
CREATE TABLE `specification_description` (
  `specification_description_id` int(11) NOT NULL AUTO_INCREMENT,
  `specifications_id` int(11) NOT NULL DEFAULT '0',
  `language_id` int(11) NOT NULL DEFAULT '1',
  `specification_name` varchar(32) NOT NULL DEFAULT '',
  `specification_description` varchar(128) NOT NULL,
  `specification_prefix` varchar(128) NOT NULL DEFAULT '',
  `specification_suffix` varchar(128) NOT NULL DEFAULT '',
  PRIMARY KEY (`specification_description_id`,`language_id`),
  KEY `specifications_id` (`specifications_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `specification_filters`;
CREATE TABLE `specification_filters` (
  `specification_filters_id` int(11) NOT NULL AUTO_INCREMENT,
  `specifications_id` int(11) NOT NULL DEFAULT '0',
  `filter_sort_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`specification_filters_id`),
  KEY `specifications_id` (`specifications_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `specification_filters_description`;
CREATE TABLE `specification_filters_description` (
  `specification_filters_description_id` int(11) NOT NULL AUTO_INCREMENT,
  `specification_filters_id` int(11) NOT NULL DEFAULT '0',
  `language_id` int(11) NOT NULL DEFAULT '1',
  `filter` varchar(128) NOT NULL,
  PRIMARY KEY (`specification_filters_description_id`),
  KEY `language_id` (`language_id`),
  KEY `specification_filters_id` (`specification_filters_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `specification_groups`;
CREATE TABLE `specification_groups` (
  `specification_group_id` int(11) NOT NULL AUTO_INCREMENT,
  `specification_group_name` varchar(64) NOT NULL,
  `show_comparison` set('True','False') NOT NULL DEFAULT 'True',
  `show_products` set('True','False') NOT NULL DEFAULT 'True',
  `show_filter` set('True','False') NOT NULL DEFAULT 'True',
  PRIMARY KEY (`specification_group_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `specification_groups_to_categories`;
CREATE TABLE `specification_groups_to_categories` (
  `specification_group_id` int(11) NOT NULL DEFAULT '0',
  `categories_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`specification_group_id`,`categories_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `specification_values`;
CREATE TABLE `specification_values` (
  `specification_values_id` int(11) NOT NULL AUTO_INCREMENT,
  `specifications_id` int(11) NOT NULL DEFAULT '0',
  `value_sort_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`specification_values_id`),
  KEY `specifications_id` (`specifications_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `specification_values_description`;
CREATE TABLE `specification_values_description` (
  `specification_values_description_id` int(11) NOT NULL AUTO_INCREMENT,
  `specification_values_id` int(11) NOT NULL DEFAULT '0',
  `language_id` int(11) NOT NULL DEFAULT '1',
  `specification_value` varchar(128) NOT NULL,
  PRIMARY KEY (`specification_values_description_id`),
  KEY `specification_values_id` (`specification_values_id`),
  KEY `language_id` (`language_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `specifications`;
CREATE TABLE `specifications` (
  `specifications_id` int(11) NOT NULL AUTO_INCREMENT,
  `specification_group_id` int(11) NOT NULL DEFAULT '0',
  `specification_sort_order` int(11) NOT NULL DEFAULT '0',
  `show_comparison` set('True','False') NOT NULL DEFAULT 'True',
  `show_products` set('True','False') NOT NULL DEFAULT 'True',
  `show_filter` set('True','False') NOT NULL DEFAULT 'True',
  `products_column_name` varchar(32) NOT NULL,
  `column_justify` set('Left','Center','Right') NOT NULL DEFAULT 'Left',
  `filter_class` set('none','exact','multiple','range','reverse','start','partial','like') NOT NULL DEFAULT 'none',
  `filter_display` set('pulldown','multi','checkbox','radio','links','text','image','multiimage') NOT NULL DEFAULT 'pulldown',
  `filter_show_all` set('True','False') NOT NULL DEFAULT 'True',
  `enter_values` set('pulldown','multi','checkbox','radio','links','text','image','multiimage') NOT NULL DEFAULT 'text',
  PRIMARY KEY (`specifications_id`),
  KEY `specification_group_id` (`specification_group_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `spsr_zones`;
CREATE TABLE `spsr_zones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `zone_id` int(11) NOT NULL DEFAULT '0',
  `spsr_zone_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=82 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `spsr_zones` VALUES
(1, 22, 53),
(2, 23, 55),
(3, 24, 56),
(4, 25, 54),
(5, 26, 57),
(6, 27, 101),
(7, 28, 19),
(8, 29, 58),
(9, 30, 24),
(10, 31, 59),
(11, 32, 60),
(12, 33, 61),
(13, 34, 62),
(14, 35, 63),
(15, 36, 64),
(16, 37, 65),
(17, 38, 66),
(18, 39, 84),
(19, 40, 67),
(20, 41, 92),
(21, 42, 94),
(22, 43, 3),
(23, 44, 30),
(24, 45, 31),
(25, 46, 51),
(26, 47, 75),
(27, 48, 89),
(28, 49, 4),
(29, 50, 6),
(30, 51, 7),
(31, 52, 8),
(32, 53, 10),
(33, 54, 11),
(34, 55, 12),
(35, 56, 13),
(36, 57, 14),
(37, 58, 17),
(38, 59, 18),
(39, 60, 21),
(40, 61, 22),
(41, 62, 23),
(42, 63, 25),
(43, 64, 27),
(44, 65, 29),
(45, 66, 32),
(46, 67, 33),
(47, 68, 35),
(48, 69, 36),
(49, 70, 38),
(50, 71, 40),
(51, 72, 41),
(52, 73, 43),
(53, 74, 44),
(54, 75, 45),
(55, 76, 46),
(56, 77, 47),
(57, 78, 48),
(58, 79, 49),
(59, 80, 50),
(60, 81, 52),
(61, 82, 68),
(62, 83, 69),
(63, 84, 70),
(64, 85, 71),
(65, 86, 72),
(66, 87, 73),
(67, 88, 74),
(68, 89, 78),
(69, 90, 79),
(70, 91, 80),
(71, 92, 81),
(72, 93, 83),
(73, 94, 87),
(74, 95, 91),
(75, 97, 100),
(76, 100, 16),
(77, 104, 42),
(78, 106, 88),
(79, 107, 90),
(80, 108, 95),
(81, 109, 97);

DROP table IF EXISTS `tax_class`;
CREATE TABLE `tax_class` (
  `tax_class_id` int(11) NOT NULL AUTO_INCREMENT,
  `tax_class_title` varchar(255) NOT NULL,
  `tax_class_description` varchar(255) NOT NULL,
  `last_modified` datetime DEFAULT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`tax_class_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `tax_rates`;
CREATE TABLE `tax_rates` (
  `tax_rates_id` int(11) NOT NULL AUTO_INCREMENT,
  `tax_zone_id` int(11) NOT NULL,
  `tax_class_id` int(11) NOT NULL,
  `tax_priority` int(5) DEFAULT '1',
  `tax_rate` decimal(7,4) NOT NULL,
  `tax_description` varchar(255) NOT NULL,
  `last_modified` datetime DEFAULT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`tax_rates_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `topics`;
CREATE TABLE `topics` (
  `topics_id` int(11) NOT NULL AUTO_INCREMENT,
  `topics_image` varchar(64) DEFAULT NULL,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `sort_order` int(3) DEFAULT NULL,
  `date_added` datetime DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  `topics_page_url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`topics_id`),
  KEY `idx_topics_parent_id` (`parent_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `topics_description`;
CREATE TABLE `topics_description` (
  `topics_id` int(11) NOT NULL DEFAULT '0',
  `language_id` int(11) NOT NULL DEFAULT '1',
  `topics_name` varchar(255) NOT NULL DEFAULT '',
  `topics_heading_title` varchar(255) DEFAULT NULL,
  `topics_description` text,
  PRIMARY KEY (`topics_id`,`language_id`),
  KEY `idx_topics_name` (`topics_name`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP table IF EXISTS `whos_online`;
CREATE TABLE `whos_online` (
  `customer_id` int(11) DEFAULT NULL,
  `full_name` varchar(255) NOT NULL,
  `session_id` varchar(255) NOT NULL,
  `ip_address` varchar(15) NOT NULL,
  `time_entry` varchar(14) NOT NULL,
  `time_last_click` varchar(14) NOT NULL,
  `last_page_url` varchar(255) NOT NULL
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `whos_online` VALUES
(0, 'Посетитель', '', '127.0.0.1', '1331549051', '1331549051', '/captcha.php'),
(1, 'Admin aDMIN', 'shbg1sjhotukt2ak9mo9v5c840', '127.0.0.1', '1331548115', '1331549072', '/advanced_search.php');

DROP table IF EXISTS `zones`;
CREATE TABLE `zones` (
  `zone_id` int(11) NOT NULL AUTO_INCREMENT,
  `zone_country_id` int(11) NOT NULL,
  `zone_code` varchar(255) NOT NULL,
  `zone_name` varchar(255) NOT NULL,
  PRIMARY KEY (`zone_id`)
) ENGINE=MyISAM AUTO_INCREMENT=387 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `zones` VALUES
(1, 109, 'Акмолинская область', 'Акмолинская область'),
(2, 109, 'Актюбинская область', 'Актюбинская область'),
(3, 109, 'Алматинская область', 'Алматинская область'),
(4, 109, 'Атырауская область', 'Атырауская область'),
(5, 109, 'Восточно-Казахстанская область', 'Восточно-Казахстанская область'),
(6, 109, 'Жамбылская область', 'Жамбылская область'),
(7, 109, 'Западно-Казахстанская область', 'Западно-Казахстанская область'),
(8, 109, 'Карагандинская область', 'Карагандинская область'),
(9, 109, 'Кзылординская область', 'Кзылординская область'),
(10, 109, 'Костанайская область', 'Костанайская область'),
(11, 109, 'Мангистауская область', 'Мангистауская область'),
(12, 109, 'Павлодарская область', 'Павлодарская область'),
(13, 109, 'Северо-Казахстанская область', 'Северо-Казахстанская область'),
(14, 109, 'Южно-Казахстанская область', 'Южно-Казахстанская область'),
(15, 115, 'Баткенская область', 'Баткенская область'),
(16, 115, 'Джалал-Абадская область', 'Джалал-Абадская область'),
(17, 115, 'Иссык-Кульская область', 'Иссык-Кульская область'),
(18, 115, 'Таласская область', 'Таласская область'),
(19, 115, 'Нарынская область', 'Нарынская область'),
(20, 115, 'Ошская область', 'Ошская область'),
(21, 115, 'Чуйская область', 'Чуйская область'),
(22, 176, 'Адыгея', 'Адыгея'),
(23, 176, 'Башкирия', 'Башкирия'),
(24, 176, 'Бурятия', 'Бурятия'),
(25, 176, 'Горный Алтай', 'Горный Алтай'),
(26, 176, 'Дагестан', 'Дагестан'),
(27, 176, 'Ингушетия', 'Ингушетия'),
(28, 176, 'Кабардино-Балкария', 'Кабардино-Балкария'),
(29, 176, 'Калмыкия', 'Калмыкия'),
(30, 176, 'Карачаево-Черкесия', 'Карачаево-Черкесия'),
(31, 176, 'Карелия', 'Карелия'),
(32, 176, 'Коми', 'Коми'),
(33, 176, 'Марийская Республика', 'Марийская Республика'),
(34, 176, 'Мордовская Республика', 'Мордовская Республика'),
(35, 176, 'Якутия', 'Якутия'),
(36, 176, 'Северная Осетия', 'Северная Осетия'),
(37, 176, 'Татарстан', 'Татарстан'),
(38, 176, 'Тува', 'Тува'),
(39, 176, 'Удмуртия', 'Удмуртия'),
(40, 176, 'Хакасия', 'Хакасия'),
(41, 176, 'Чечня', 'Чечня'),
(42, 176, 'Чувашия', 'Чувашия'),
(43, 176, 'Алтайский край', 'Алтайский край'),
(44, 176, 'Краснодарский край', 'Краснодарский край'),
(45, 176, 'Красноярский край', 'Красноярский край'),
(46, 176, 'Приморский край', 'Приморский край'),
(47, 176, 'Ставропольский край', 'Ставропольский край'),
(48, 176, 'Хабаровский край', 'Хабаровский край'),
(49, 176, 'Амурская область', 'Амурская область'),
(50, 176, 'Архангельская область', 'Архангельская область'),
(51, 176, 'Астраханская область', 'Астраханская область'),
(52, 176, 'Белгородская область', 'Белгородская область'),
(53, 176, 'Брянская область', 'Брянская область'),
(54, 176, 'Владимирская область', 'Владимирская область'),
(55, 176, 'Волгоградская область', 'Волгоградская область'),
(56, 176, 'Вологодская область', 'Вологодская область'),
(57, 176, 'Воронежская область', 'Воронежская область'),
(58, 176, 'Ивановская область', 'Ивановская область'),
(59, 176, 'Иркутская область', 'Иркутская область'),
(60, 176, 'Калининградская область', 'Калининградская область'),
(61, 176, 'Калужская область', 'Калужская область'),
(62, 176, 'Камчатский край', 'Камчатский край'),
(63, 176, 'Кемеровская область', 'Кемеровская область'),
(64, 176, 'Кировская область', 'Кировская область'),
(65, 176, 'Костромская область', 'Костромская область'),
(66, 176, 'Курганская область', 'Курганская область'),
(67, 176, 'Курская область', 'Курская область'),
(68, 176, 'Ленинградская область', 'Ленинградская область'),
(69, 176, 'Липецкая область', 'Липецкая область'),
(70, 176, 'Магаданская область', 'Магаданская область'),
(71, 176, 'Московская область', 'Московская область'),
(72, 176, 'Мурманская область', 'Мурманская область'),
(73, 176, 'Нижегородская область', 'Нижегородская область'),
(74, 176, 'Новгородская область', 'Новгородская область'),
(75, 176, 'Новосибирская область', 'Новосибирская область'),
(76, 176, 'Омская область', 'Омская область'),
(77, 176, 'Оренбургская область', 'Оренбургская область'),
(78, 176, 'Орловская область', 'Орловская область'),
(79, 176, 'Пензенская область', 'Пензенская область'),
(80, 176, 'Пермский край', 'Пермский край'),
(81, 176, 'Псковская область', 'Псковская область'),
(82, 176, 'Ростовская область', 'Ростовская область'),
(83, 176, 'Рязанская область', 'Рязанская область'),
(84, 176, 'Самарская область', 'Самарская область'),
(85, 176, 'Саратовская область', 'Саратовская область'),
(86, 176, 'Сахалинская область', 'Сахалинская область'),
(87, 176, 'Свердловская область', 'Свердловская область'),
(88, 176, 'Смоленская область', 'Смоленская область'),
(89, 176, 'Тамбовская область', 'Тамбовская область'),
(90, 176, 'Тверская область', 'Тверская область'),
(91, 176, 'Томская область', 'Томская область'),
(92, 176, 'Тульская область', 'Тульская область'),
(93, 176, 'Тюменская область', 'Тюменская область'),
(94, 176, 'Ульяновская область', 'Ульяновская область'),
(95, 176, 'Челябинская область', 'Челябинская область'),
(96, 176, 'Читинская область', 'Читинская область'),
(97, 176, 'Ярославская область', 'Ярославская область'),
(98, 176, 'Москва', 'Москва'),
(99, 176, 'Санкт-Петербург', 'Санкт-Петербург'),
(100, 176, 'Еврейская автономная область', 'Еврейская автономная область'),
(101, 176, 'Агинский Бурятский АО', 'Агинский Бурятский АО'),
(104, 176, 'Ненецкий АО', 'Ненецкий АО'),
(105, 176, 'Таймырский АО', 'Таймырский АО'),
(106, 176, 'Усть-Ордынский Бурятский АО', 'Усть-Ордынский Бурятский АО'),
(107, 176, 'Ханты-Мансийский АО', 'Ханты-Мансийский АО'),
(108, 176, 'Чукотский АО', 'Чукотский АО'),
(109, 176, 'Эвенкийский АО', 'Эвенкийский АО'),
(110, 176, 'Ямало-Ненецкий АО', 'Ямало-Ненецкий АО'),
(111, 207, 'Мухтори-Кухистони-Бадахшони', 'Мухтори-Кухистони-Бадахшони'),
(112, 207, 'Хатлонская область', 'Хатлонская область'),
(113, 207, 'Ленинабадская область', 'Ленинабадская область'),
(114, 216, 'Ахал', 'Ахал'),
(115, 216, 'Балкан', 'Балкан'),
(116, 216, 'Дашховуз', 'Дашховуз'),
(117, 216, 'Лебап', 'Лебап'),
(118, 216, 'Мары', 'Мары'),
(119, 220, 'Республика Крым', 'Республика Крым'),
(120, 220, 'Винницкая область', 'Винницкая область'),
(121, 220, 'Волынская область', 'Волынская область'),
(122, 220, 'Днепропетровская область', 'Днепропетровская область'),
(123, 220, 'Донецкая область', 'Донецкая область'),
(124, 220, 'Житомирская область', 'Житомирская область'),
(125, 220, 'Закарпатская область', 'Закарпатская область'),
(126, 220, 'Запорожская область', 'Запорожская область'),
(127, 220, 'Ивано-Франковская область', 'Ивано-Франковская область'),
(128, 220, 'Киевская область', 'Киевская область'),
(129, 220, 'Кировоградская область', 'Кировоградская область'),
(130, 220, 'Луганская область', 'Луганская область'),
(131, 220, 'Львовская область', 'Львовская область'),
(132, 220, 'Николаевская область', 'Николаевская область'),
(133, 220, 'Одесская область', 'Одесская область'),
(134, 220, 'Полтавская область', 'Полтавская область'),
(135, 220, 'Ровенская область', 'Ровенская область'),
(136, 220, 'Сумская область', 'Сумская область'),
(137, 220, 'Тернопольская область', 'Тернопольская область'),
(138, 220, 'Харьковская область', 'Харьковская область'),
(139, 220, 'Херсонская область', 'Херсонская область'),
(140, 220, 'Хмельницкая область', 'Хмельницкая область'),
(141, 220, 'Черкасская область', 'Черкасская область'),
(142, 220, 'Черниговская область', 'Черниговская область'),
(143, 220, 'Черновицкая область', 'Черновицкая область'),
(144, 226, 'Андижанский', 'Андижанский'),
(145, 226, 'Бухарский', 'Бухарский'),
(146, 226, 'Джизакский', 'Джизакский'),
(147, 226, 'Каракалпакия', 'Каракалпакия'),
(148, 226, 'Кашкадарьинский', 'Кашкадарьинский'),
(149, 226, 'Навоийский', 'Навоийский'),
(150, 226, 'Наманганский', 'Наманганский'),
(151, 226, 'Самаркандский', 'Самаркандский'),
(152, 226, 'Сурхандарьинский', 'Сурхандарьинский'),
(153, 226, 'Сырдарьинский', 'Сырдарьинский'),
(154, 226, 'Ташкентский', 'Ташкентский'),
(155, 226, 'Ферганский', 'Ферганский'),
(156, 226, 'Хорезмский', 'Хорезмский'),
(157, 15, 'Апшеронский район', 'Апшеронский район'),
(158, 15, 'Агдамский район', 'Агдамский район'),
(159, 15, 'Агдашский район', 'Агдашский район'),
(160, 15, 'Агджабединский район', 'Агджабединский район'),
(161, 15, 'Акстафинский район', 'Акстафинский район'),
(162, 15, 'Агсуинский район', 'Агсуинский район'),
(163, 15, 'Астаринский район', 'Астаринский район'),
(164, 15, 'Балакенский район', 'Балакенский район'),
(165, 15, 'Бейлаганский район', 'Бейлаганский район'),
(166, 15, 'Бардинский район', 'Бардинский район'),
(167, 15, 'Билясуварский район', 'Билясуварский район'),
(168, 15, 'Джебраильский район', 'Джебраильский район'),
(169, 15, 'Джалилабадский район', 'Джалилабадский район'),
(170, 15, 'Дашкесанский район', 'Дашкесанский район'),
(171, 15, 'Дивичинский район', 'Дивичинский район'),
(172, 15, 'Физулинский район', 'Физулинский район'),
(173, 15, 'Кедабекский район', 'Кедабекский район'),
(174, 15, 'Геранбойский район', 'Геранбойский район'),
(175, 15, 'Геокчайский район', 'Геокчайский район'),
(176, 15, 'Гаджигабульский район', 'Гаджигабульский район'),
(177, 15, 'Хачмазский район', 'Хачмазский район'),
(178, 15, 'Ханларский район', 'Ханларский район'),
(179, 15, 'Хызынский район', 'Хызынский район'),
(180, 15, 'Ходжавендский район', 'Ходжавендский район'),
(181, 15, 'Ходжалинский район', 'Ходжалинский район'),
(182, 15, 'Имишлинский район', 'Имишлинский район'),
(183, 15, 'Исмаиллинский район', 'Исмаиллинский район'),
(184, 15, 'Кельбаджарский район', 'Кельбаджарский район'),
(185, 15, 'Кюрдамирский район', 'Кюрдамирский район'),
(186, 15, 'Гахский район', 'Гахский район'),
(187, 15, 'Газахский район', 'Газахский район'),
(188, 15, 'Габалинский район', 'Габалинский район'),
(189, 15, 'Гобустанский район', 'Гобустанский район'),
(190, 15, 'Губинский район', 'Губинский район'),
(191, 15, 'Губадлинский район', 'Губадлинский район'),
(192, 15, 'Гусарский район', 'Гусарский район'),
(193, 15, 'Лачинский район', 'Лачинский район'),
(194, 15, 'Ленкоранский район', 'Ленкоранский район'),
(195, 15, 'Лерикский район', 'Лерикский район'),
(196, 15, 'Масаллинский район', 'Масаллинский район'),
(197, 15, 'Нефтчалинский район', 'Нефтчалинский район'),
(198, 15, 'Огузский район', 'Огузский район'),
(199, 15, 'Саатлинский район', 'Саатлинский район'),
(200, 15, 'Сабирабадский район', 'Сабирабадский район'),
(201, 15, 'Сальянский район', 'Сальянский район'),
(202, 15, 'Самухский район', 'Самухский район'),
(203, 15, 'Сиязаньский район', 'Сиязаньский район'),
(204, 15, 'Шемахинский район', 'Шемахинский район'),
(205, 15, 'Шемкирский район', 'Шемкирский район'),
(206, 15, 'Шекинский район', 'Шекинский район'),
(207, 15, 'Шушинский район', 'Шушинский район'),
(208, 15, 'Тертерский район', 'Тертерский район'),
(209, 15, 'Товузский район', 'Товузский район'),
(210, 15, 'Уджарский район', 'Уджарский район'),
(211, 15, 'Ярдымлинский район', 'Ярдымлинский район'),
(212, 15, 'Евлахский район', 'Евлахский район'),
(213, 15, 'Закатальский район', 'Закатальский район'),
(214, 15, 'Зангеланский район', 'Зангеланский район'),
(215, 15, 'Зардабский район', 'Зардабский район'),
(216, 15, 'Нахичеванская Автономная Республика', 'Нахичеванская Автономная Республика'),
(217, 15, 'Бабекский район', 'Бабекский район'),
(218, 15, 'Джульфинский район', 'Джульфинский район'),
(219, 15, 'Ордубадский район', 'Ордубадский район'),
(220, 15, 'Садаракский район', 'Садаракский район'),
(221, 15, 'Шахбузский район', 'Шахбузский район'),
(222, 15, 'Шарурский район', 'Шарурский район'),
(223, 67, 'Харьюский уезд', 'Харьюский уезд'),
(224, 67, 'Хийумааский уезд', 'Хийумааский уезд'),
(225, 67, 'Ида-Вирумааский уезд', 'Ида-Вирумааский уезд'),
(226, 67, 'Ярвамаамааский уезд', 'Ярвамаамааский уезд'),
(227, 67, 'Йыгевамааский уезд', 'Йыгевамааский уезд'),
(228, 67, 'Ляэнемааский уезд', 'Ляэнемааский уезд'),
(229, 67, 'Ляэне-Вирумааский уезд', 'Ляэне-Вирумааский уезд'),
(230, 67, 'Пылвамааский уезд', 'Пылвамааский уезд'),
(231, 67, 'Пярнумааский уезд', 'Пярнумааский уезд'),
(232, 67, 'Рапламааский уезд', 'Рапламааский уезд'),
(233, 67, 'Сааремааский уезд', 'Сааремааский уезд'),
(234, 67, 'Тартумааский уезд', 'Тартумааский уезд'),
(235, 67, 'Валгамааский уезд', 'Валгамааский уезд'),
(236, 67, 'Вильяндимааский уезд', 'Вильяндимааский уезд'),
(237, 67, 'Вырумааский уезд', 'Вырумааский уезд'),
(238, 20, 'Витебская область', 'Витебская область'),
(239, 20, 'Могилевская область', 'Могилевская область'),
(240, 20, 'Минская область', 'Минская область'),
(241, 20, 'Гродненская область', 'Гродненская область'),
(242, 20, 'Гомельская область', 'Гомельская область'),
(243, 20, 'Брестская область', 'Брестская область'),
(244, 11, 'Область Арагацотн', 'Область Арагацотн'),
(245, 11, 'Араратская область', 'Араратская область'),
(246, 11, 'Армавирская область', 'Армавирская область'),
(247, 11, 'Гегаркуникская область', 'Гегаркуникская область'),
(248, 11, 'Ереван', 'Ереван'),
(249, 11, 'Лорийская область', 'Лорийская область'),
(250, 11, 'Котайкская область', 'Котайкская область'),
(251, 11, 'Ширакская область', 'Ширакская область'),
(252, 11, 'Сюникская область', 'Сюникская область'),
(253, 11, 'Область Вайоц Дзор', 'Область Вайоц Дзор'),
(254, 11, 'Тавушская область', 'Тавушская область'),
(255, 80, 'Гурия', 'Гурия'),
(256, 80, 'Имерети', 'Имерети'),
(257, 80, 'Кахети', 'Кахети'),
(258, 80, 'Квемо-Картли', 'Квемо-Картли'),
(259, 80, 'Мцхета-Тианети', 'Мцхета-Тианети'),
(260, 80, 'Рача-Лечхуми - Квемо Сванети', 'Рача-Лечхуми - Квемо Сванети'),
(261, 80, 'Самегрело - Земо-Сванети', 'Самегрело - Земо-Сванети'),
(262, 80, 'Самцхе-Джавахети', 'Самцхе-Джавахети'),
(263, 80, 'Тбилиси', 'Тбилиси'),
(264, 80, 'Шида - Картли', 'Шида - Картли'),
(265, 80, 'Аджарская автономная республика', 'Аджарская автономная республика'),
(266, 80, 'Абхазская автономная республика', 'Абхазская автономная республика'),
(267, 80, 'Республика Южная Осетия', 'Республика Южная Осетия'),
(268, 140, 'Балти', 'Балти'),
(269, 140, 'Единет', 'Единет'),
(270, 140, 'Кагул', 'Кагул'),
(271, 140, 'Кишенёв', 'Кишенёв'),
(272, 140, 'Лапушна', 'Лапушна'),
(273, 140, 'Оргей', 'Оргей'),
(274, 140, 'Сорока', 'Сорока'),
(275, 140, 'Тараклия', 'Тараклия'),
(276, 140, 'Тигина', 'Тигина'),
(277, 140, 'Унгены', 'Унгены'),
(278, 123, 'Алитусский уезд', 'Алитусский уезд'),
(279, 123, 'Каунасский уезд', 'Каунасский уезд'),
(280, 123, 'Kлайпедский уезд', 'Kлайпедский уезд'),
(281, 123, 'Maриямпольский уезд', 'Maриямпольский уезд'),
(282, 123, 'Панявежский уезд', 'Панявежский уезд'),
(283, 123, 'Шяуляйский уезд', 'Шяуляйский уезд'),
(284, 123, 'Таурагский уезд', 'Таурагский уезд'),
(285, 123, 'Tяльшяйский уезд', 'Tяльшяйский уезд'),
(286, 123, 'Утянский уезд', 'Утянский уезд'),
(287, 123, 'Вильнюсский уезд', 'Вильнюсский уезд'),
(288, 117, 'Аизкраукленский', 'Аизкраукленский'),
(289, 117, 'Алуксненский', 'Алуксненский'),
(290, 117, 'Балвский', 'Балвский'),
(291, 117, 'Бауский', 'Бауский'),
(292, 117, 'Валкский', 'Валкский'),
(293, 117, 'Валмиерский', 'Валмиерский'),
(294, 117, 'Вентспилсский', 'Вентспилсский'),
(295, 117, 'Гулбенский', 'Гулбенский'),
(296, 117, 'Давгавпилский', 'Давгавпилский'),
(297, 117, 'Добелский', 'Добелский'),
(298, 117, 'Екабпилский', 'Екабпилский'),
(299, 117, 'Елгавский', 'Елгавский'),
(300, 117, 'Краславский', 'Краславский'),
(301, 117, 'Кулдигский', 'Кулдигский'),
(302, 117, 'Лепайский', 'Лепайский'),
(303, 117, 'Лимбажский', 'Лимбажский'),
(304, 117, 'Ледзенский', 'Ледзенский'),
(305, 117, 'Мадонский', 'Мадонский'),
(306, 117, 'Огрский', 'Огрский'),
(307, 117, 'Прейльский', 'Прейльский'),
(308, 117, 'Резекненский', 'Резекненский'),
(309, 117, 'Рижский', 'Рижский'),
(310, 117, 'Салдуский', 'Салдуский'),
(311, 117, 'Талсинский', 'Талсинский'),
(312, 117, 'Тукумский', 'Тукумский'),
(313, 117, 'Цесиский', 'Цесиский'),
(314, 117, 'Вентспилс', 'Вентспилс'),
(315, 117, 'Даугавпилс', 'Даугавпилс'),
(316, 117, 'Елгава', 'Елгава'),
(317, 117, 'Лиепая', 'Лиепая'),
(318, 117, 'Резекне', 'Резекне'),
(319, 117, 'Рига', 'Рига'),
(320, 117, 'Юрмала', 'Юрмала'),
(321, 223, 'AL', 'Alabama'),
(322, 223, 'AK', 'Alaska'),
(323, 223, 'AS', 'American Samoa'),
(324, 223, 'AZ', 'Arizona'),
(325, 223, 'AR', 'Arkansas'),
(326, 223, 'AF', 'Armed Forces Africa'),
(327, 223, 'AA', 'Armed Forces Americas'),
(328, 223, 'AC', 'Armed Forces Canada'),
(329, 223, 'AE', 'Armed Forces Europe'),
(330, 223, 'AM', 'Armed Forces Middle East'),
(331, 223, 'AP', 'Armed Forces Pacific'),
(332, 223, 'CA', 'California'),
(333, 223, 'CO', 'Colorado'),
(334, 223, 'CT', 'Connecticut'),
(335, 223, 'DE', 'Delaware'),
(336, 223, 'DC', 'District of Columbia'),
(337, 223, 'FM', 'Federated States Of Micronesia'),
(338, 223, 'FL', 'Florida'),
(339, 223, 'GA', 'Georgia'),
(340, 223, 'GU', 'Guam'),
(341, 223, 'HI', 'Hawaii'),
(342, 223, 'ID', 'Idaho'),
(343, 223, 'IL', 'Illinois'),
(344, 223, 'IN', 'Indiana'),
(345, 223, 'IA', 'Iowa'),
(346, 223, 'KS', 'Kansas'),
(347, 223, 'KY', 'Kentucky'),
(348, 223, 'LA', 'Louisiana'),
(349, 223, 'ME', 'Maine'),
(350, 223, 'MH', 'Marshall Islands'),
(351, 223, 'MD', 'Maryland'),
(352, 223, 'MA', 'Massachusetts'),
(353, 223, 'MI', 'Michigan'),
(354, 223, 'MN', 'Minnesota'),
(355, 223, 'MS', 'Mississippi'),
(356, 223, 'MO', 'Missouri'),
(357, 223, 'MT', 'Montana'),
(358, 223, 'NE', 'Nebraska'),
(359, 223, 'NV', 'Nevada'),
(360, 223, 'NH', 'New Hampshire'),
(361, 223, 'NJ', 'New Jersey'),
(362, 223, 'NM', 'New Mexico'),
(363, 223, 'NY', 'New York'),
(364, 223, 'NC', 'North Carolina'),
(365, 223, 'ND', 'North Dakota'),
(366, 223, 'MP', 'Northern Mariana Islands'),
(367, 223, 'OH', 'Ohio'),
(368, 223, 'OK', 'Oklahoma'),
(369, 223, 'OR', 'Oregon'),
(370, 223, 'PW', 'Palau'),
(371, 223, 'PA', 'Pennsylvania'),
(372, 223, 'PR', 'Puerto Rico'),
(373, 223, 'RI', 'Rhode Island'),
(374, 223, 'SC', 'South Carolina'),
(375, 223, 'SD', 'South Dakota'),
(376, 223, 'TN', 'Tennessee'),
(377, 223, 'TX', 'Texas'),
(378, 223, 'UT', 'Utah'),
(379, 223, 'VT', 'Vermont'),
(380, 223, 'VI', 'Virgin Islands'),
(381, 223, 'VA', 'Virginia'),
(382, 223, 'WA', 'Washington'),
(383, 223, 'WV', 'West Virginia'),
(384, 223, 'WI', 'Wisconsin'),
(385, 223, 'WY', 'Wyoming'),
(386, 115, 'Бишкек', 'Бишкек');

DROP table IF EXISTS `zones_to_geo_zones`;
CREATE TABLE `zones_to_geo_zones` (
  `association_id` int(11) NOT NULL AUTO_INCREMENT,
  `zone_country_id` int(11) NOT NULL,
  `zone_id` int(11) DEFAULT NULL,
  `geo_zone_id` int(11) DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`association_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

